module alu16 (C,
    N,
    V,
    Z,
    clk,
    A,
    B,
    Y,
    opcode);
 output C;
 output N;
 output V;
 output Z;
 input clk;
 input [15:0] A;
 input [15:0] B;
 output [15:0] Y;
 input [2:0] opcode;

 wire \A_reg[0] ;
 wire \A_reg[10] ;
 wire \A_reg[11] ;
 wire \A_reg[12] ;
 wire \A_reg[13] ;
 wire \A_reg[14] ;
 wire \A_reg[15] ;
 wire \A_reg[1] ;
 wire \A_reg[2] ;
 wire \A_reg[3] ;
 wire \A_reg[4] ;
 wire \A_reg[5] ;
 wire \A_reg[6] ;
 wire \A_reg[7] ;
 wire \A_reg[8] ;
 wire \A_reg[9] ;
 wire \Beff_reg[0] ;
 wire \Beff_reg[10] ;
 wire \Beff_reg[11] ;
 wire \Beff_reg[12] ;
 wire \Beff_reg[13] ;
 wire \Beff_reg[14] ;
 wire \Beff_reg[15] ;
 wire \Beff_reg[1] ;
 wire \Beff_reg[2] ;
 wire \Beff_reg[3] ;
 wire \Beff_reg[4] ;
 wire \Beff_reg[5] ;
 wire \Beff_reg[6] ;
 wire \Beff_reg[7] ;
 wire \Beff_reg[8] ;
 wire \Beff_reg[9] ;
 wire \T[3] ;
 wire _0000_;
 wire _0001_;
 wire _0002_;
 wire _0003_;
 wire _0004_;
 wire _0005_;
 wire _0006_;
 wire _0007_;
 wire _0008_;
 wire _0009_;
 wire _0010_;
 wire _0011_;
 wire _0012_;
 wire _0013_;
 wire _0014_;
 wire _0015_;
 wire _0016_;
 wire _0017_;
 wire _0018_;
 wire _0019_;
 wire _0020_;
 wire _0021_;
 wire _0022_;
 wire _0023_;
 wire _0024_;
 wire _0025_;
 wire _0026_;
 wire _0027_;
 wire _0028_;
 wire _0029_;
 wire _0030_;
 wire _0031_;
 wire _0032_;
 wire _0033_;
 wire _0034_;
 wire _0035_;
 wire _0036_;
 wire _0037_;
 wire _0038_;
 wire _0039_;
 wire _0040_;
 wire _0041_;
 wire _0042_;
 wire _0043_;
 wire _0044_;
 wire _0045_;
 wire _0046_;
 wire _0047_;
 wire _0048_;
 wire _0049_;
 wire _0050_;
 wire _0051_;
 wire _0052_;
 wire _0053_;
 wire _0054_;
 wire _0055_;
 wire _0056_;
 wire _0057_;
 wire _0058_;
 wire _0059_;
 wire _0060_;
 wire _0061_;
 wire _0062_;
 wire _0063_;
 wire _0064_;
 wire _0065_;
 wire _0066_;
 wire _0067_;
 wire _0068_;
 wire _0069_;
 wire _0070_;
 wire _0071_;
 wire _0072_;
 wire _0073_;
 wire _0074_;
 wire _0075_;
 wire _0076_;
 wire _0077_;
 wire _0078_;
 wire _0079_;
 wire _0080_;
 wire _0081_;
 wire _0082_;
 wire _0083_;
 wire _0084_;
 wire _0085_;
 wire _0086_;
 wire _0087_;
 wire _0088_;
 wire _0089_;
 wire _0090_;
 wire _0091_;
 wire _0092_;
 wire _0093_;
 wire _0094_;
 wire _0095_;
 wire _0096_;
 wire _0097_;
 wire _0098_;
 wire _0099_;
 wire _0100_;
 wire _0101_;
 wire _0102_;
 wire _0103_;
 wire _0104_;
 wire _0105_;
 wire _0106_;
 wire _0107_;
 wire _0108_;
 wire _0109_;
 wire _0110_;
 wire _0111_;
 wire _0112_;
 wire _0113_;
 wire _0114_;
 wire _0115_;
 wire _0116_;
 wire _0117_;
 wire _0118_;
 wire _0119_;
 wire _0120_;
 wire _0121_;
 wire _0122_;
 wire _0123_;
 wire _0124_;
 wire _0125_;
 wire _0126_;
 wire _0127_;
 wire _0128_;
 wire _0129_;
 wire _0130_;
 wire _0131_;
 wire _0132_;
 wire _0133_;
 wire _0134_;
 wire _0135_;
 wire _0136_;
 wire _0137_;
 wire _0138_;
 wire _0139_;
 wire _0140_;
 wire _0141_;
 wire _0142_;
 wire _0143_;
 wire _0144_;
 wire _0145_;
 wire _0146_;
 wire _0147_;
 wire _0148_;
 wire _0149_;
 wire _0150_;
 wire _0151_;
 wire _0152_;
 wire _0153_;
 wire _0154_;
 wire _0155_;
 wire _0156_;
 wire _0157_;
 wire _0158_;
 wire _0159_;
 wire _0160_;
 wire _0161_;
 wire _0162_;
 wire _0163_;
 wire _0164_;
 wire _0165_;
 wire _0166_;
 wire _0167_;
 wire _0168_;
 wire _0169_;
 wire _0170_;
 wire _0171_;
 wire _0172_;
 wire _0173_;
 wire _0174_;
 wire _0175_;
 wire _0176_;
 wire _0177_;
 wire _0178_;
 wire _0179_;
 wire _0180_;
 wire _0181_;
 wire _0182_;
 wire _0183_;
 wire _0184_;
 wire _0185_;
 wire _0186_;
 wire _0187_;
 wire _0188_;
 wire _0189_;
 wire _0190_;
 wire _0191_;
 wire _0192_;
 wire _0193_;
 wire _0194_;
 wire _0195_;
 wire _0196_;
 wire _0197_;
 wire _0198_;
 wire _0199_;
 wire _0200_;
 wire _0201_;
 wire _0202_;
 wire _0203_;
 wire _0204_;
 wire _0205_;
 wire _0206_;
 wire _0207_;
 wire _0208_;
 wire _0209_;
 wire _0210_;
 wire _0211_;
 wire _0212_;
 wire _0213_;
 wire _0214_;
 wire _0215_;
 wire _0216_;
 wire _0217_;
 wire _0218_;
 wire _0219_;
 wire _0220_;
 wire _0221_;
 wire _0222_;
 wire _0223_;
 wire _0224_;
 wire _0225_;
 wire _0226_;
 wire _0227_;
 wire _0228_;
 wire _0229_;
 wire _0230_;
 wire _0231_;
 wire _0232_;
 wire _0233_;
 wire _0234_;
 wire _0235_;
 wire _0236_;
 wire _0237_;
 wire _0238_;
 wire _0239_;
 wire _0240_;
 wire _0241_;
 wire _0242_;
 wire _0243_;
 wire _0244_;
 wire _0245_;
 wire _0246_;
 wire _0247_;
 wire _0248_;
 wire _0249_;
 wire _0250_;
 wire _0251_;
 wire _0252_;
 wire _0253_;
 wire _0254_;
 wire _0255_;
 wire _0256_;
 wire _0257_;
 wire _0258_;
 wire _0259_;
 wire _0260_;
 wire _0261_;
 wire _0262_;
 wire _0263_;
 wire _0264_;
 wire _0265_;
 wire _0266_;
 wire _0267_;
 wire _0268_;
 wire _0269_;
 wire _0270_;
 wire _0271_;
 wire _0272_;
 wire _0273_;
 wire _0274_;
 wire _0275_;
 wire _0276_;
 wire _0277_;
 wire _0278_;
 wire _0279_;
 wire _0280_;
 wire _0281_;
 wire _0282_;
 wire _0283_;
 wire _0284_;
 wire _0285_;
 wire _0286_;
 wire _0287_;
 wire _0288_;
 wire _0289_;
 wire _0290_;
 wire _0291_;
 wire _0292_;
 wire _0293_;
 wire _0294_;
 wire _0295_;
 wire _0296_;
 wire _0297_;
 wire _0298_;
 wire _0299_;
 wire _0300_;
 wire _0301_;
 wire _0302_;
 wire _0303_;
 wire _0304_;
 wire _0305_;
 wire _0306_;
 wire _0307_;
 wire _0308_;
 wire _0309_;
 wire _0310_;
 wire _0311_;
 wire _0312_;
 wire _0313_;
 wire _0314_;
 wire _0315_;
 wire _0316_;
 wire _0317_;
 wire _0318_;
 wire _0319_;
 wire _0320_;
 wire _0321_;
 wire _0322_;
 wire _0323_;
 wire _0324_;
 wire _0325_;
 wire _0326_;
 wire _0327_;
 wire _0328_;
 wire _0329_;
 wire _0330_;
 wire _0331_;
 wire _0332_;
 wire _0333_;
 wire _0334_;
 wire _0335_;
 wire _0336_;
 wire _0337_;
 wire _0338_;
 wire _0339_;
 wire _0340_;
 wire _0341_;
 wire _0342_;
 wire _0343_;
 wire _0344_;
 wire _0345_;
 wire _0346_;
 wire _0347_;
 wire _0348_;
 wire _0349_;
 wire _0350_;
 wire _0351_;
 wire _0352_;
 wire _0353_;
 wire _0354_;
 wire _0355_;
 wire _0356_;
 wire _0357_;
 wire _0358_;
 wire _0359_;
 wire _0360_;
 wire _0361_;
 wire _0362_;
 wire _0363_;
 wire _0364_;
 wire _0365_;
 wire _0366_;
 wire _0367_;
 wire _0368_;
 wire _0369_;
 wire _0370_;
 wire _0371_;
 wire _0372_;
 wire _0373_;
 wire _0374_;
 wire _0375_;
 wire _0376_;
 wire _0377_;
 wire _0378_;
 wire _0379_;
 wire _0380_;
 wire _0381_;
 wire _0382_;
 wire _0383_;
 wire _0384_;
 wire _0385_;
 wire _0386_;
 wire _0387_;
 wire _0388_;
 wire _0389_;
 wire _0390_;
 wire _0391_;
 wire _0392_;
 wire _0393_;
 wire _0394_;
 wire _0395_;
 wire _0396_;
 wire _0397_;
 wire _0398_;
 wire _0399_;
 wire _0400_;
 wire _0401_;
 wire _0402_;
 wire _0403_;
 wire _0404_;
 wire _0405_;
 wire _0406_;
 wire _0407_;
 wire _0408_;
 wire _0409_;
 wire _0410_;
 wire _0411_;
 wire _0412_;
 wire _0413_;
 wire _0414_;
 wire _0415_;
 wire _0416_;
 wire _0417_;
 wire _0418_;
 wire _0419_;
 wire _0420_;
 wire _0421_;
 wire _0422_;
 wire _0423_;
 wire _0424_;
 wire _0425_;
 wire _0426_;
 wire _0427_;
 wire _0428_;
 wire _0429_;
 wire _0430_;
 wire _0431_;
 wire _0432_;
 wire _0433_;
 wire _0434_;
 wire _0435_;
 wire _0436_;
 wire _0437_;
 wire _0438_;
 wire _0439_;
 wire _0440_;
 wire _0441_;
 wire _0442_;
 wire _0443_;
 wire _0444_;
 wire _0445_;
 wire _0446_;
 wire _0447_;
 wire _0448_;
 wire _0449_;
 wire _0450_;
 wire _0451_;
 wire _0452_;
 wire _0453_;
 wire _0454_;
 wire _0455_;
 wire _0456_;
 wire _0457_;
 wire carry_comb;
 wire in_sub;
 wire \lo_le[0] ;
 wire overflow_comb;
 wire \result_comb[0] ;
 wire \result_comb[10] ;
 wire \result_comb[11] ;
 wire \result_comb[12] ;
 wire \result_comb[13] ;
 wire \result_comb[14] ;
 wire \result_comb[15] ;
 wire \result_comb[1] ;
 wire \result_comb[2] ;
 wire \result_comb[3] ;
 wire \result_comb[4] ;
 wire \result_comb[5] ;
 wire \result_comb[6] ;
 wire \result_comb[7] ;
 wire \result_comb[8] ;
 wire \result_comb[9] ;
 wire sel_addsub;
 wire sel_and;
 wire sel_logic;
 wire sel_not;
 wire sel_or;
 wire sel_shl;
 wire sel_shr;
 wire sel_xor;
 wire \sh_hi[1] ;
 wire \sh_hi[2] ;
 wire \sh_hi[3] ;
 wire \sh_lo[1] ;
 wire \sh_lo[2] ;
 wire \sh_lo[3] ;
 wire sub_reg;
 wire zero_comb;
 wire net1;
 wire net2;
 wire net3;
 wire net4;
 wire net5;
 wire net6;
 wire net7;
 wire net8;
 wire net9;
 wire net10;
 wire net11;
 wire net12;
 wire net13;
 wire net14;
 wire net15;
 wire net16;
 wire net17;
 wire net18;
 wire net19;
 wire net20;
 wire net21;
 wire net22;
 wire net23;
 wire net24;
 wire net25;
 wire net26;
 wire net27;
 wire net28;
 wire net29;
 wire net30;
 wire net31;
 wire net32;
 wire net33;
 wire net34;
 wire net35;
 wire net36;
 wire net37;
 wire net38;
 wire net39;
 wire net40;
 wire net41;
 wire net42;
 wire net43;
 wire net44;
 wire net45;
 wire net46;
 wire net47;
 wire net48;
 wire net49;
 wire net50;
 wire net51;
 wire net52;
 wire net53;
 wire net54;
 wire net55;
 wire net56;
 wire net57;
 wire net58;
 wire net59;
 wire net60;
 wire net61;
 wire net62;
 wire net63;
 wire net64;
 wire net65;
 wire net66;
 wire net67;
 wire net68;
 wire net69;
 wire net70;
 wire net71;
 wire net72;
 wire net73;
 wire net74;
 wire net75;
 wire net76;
 wire net77;
 wire net78;
 wire net79;
 wire net80;
 wire net81;
 wire net82;
 wire net83;
 wire net84;
 wire net85;
 wire net86;
 wire net87;
 wire net88;
 wire net89;
 wire net90;
 wire net91;
 wire net92;
 wire net93;
 wire net94;
 wire net95;
 wire net96;
 wire net97;
 wire net98;
 wire net99;
 wire net100;
 wire net101;
 wire net102;
 wire net103;
 wire net104;
 wire net105;
 wire net106;
 wire net107;
 wire net108;
 wire net109;
 wire net110;
 wire net111;
 wire net112;
 wire net113;
 wire net114;
 wire net115;
 wire net116;
 wire clknet_0_clk;
 wire clknet_3_0__leaf_clk;
 wire clknet_3_1__leaf_clk;
 wire clknet_3_2__leaf_clk;
 wire clknet_3_3__leaf_clk;
 wire clknet_3_4__leaf_clk;
 wire clknet_3_5__leaf_clk;
 wire clknet_3_6__leaf_clk;
 wire clknet_3_7__leaf_clk;

 sky130_fd_sc_hd__inv_2 _0458_ (.A(net89),
    .Y(_0032_));
 sky130_fd_sc_hd__inv_2 _0459_ (.A(net84),
    .Y(_0033_));
 sky130_fd_sc_hd__inv_2 _0460_ (.A(net82),
    .Y(_0034_));
 sky130_fd_sc_hd__inv_2 _0461_ (.A(sel_xor),
    .Y(_0035_));
 sky130_fd_sc_hd__inv_2 _0462_ (.A(sel_not),
    .Y(_0036_));
 sky130_fd_sc_hd__inv_2 _0463_ (.A(\T[3] ),
    .Y(_0037_));
 sky130_fd_sc_hd__inv_2 _0464_ (.A(net86),
    .Y(_0038_));
 sky130_fd_sc_hd__inv_2 _0465_ (.A(net114),
    .Y(_0039_));
 sky130_fd_sc_hd__inv_2 _0466_ (.A(net78),
    .Y(_0040_));
 sky130_fd_sc_hd__inv_2 _0467_ (.A(net74),
    .Y(_0041_));
 sky130_fd_sc_hd__inv_2 _0468_ (.A(\A_reg[10] ),
    .Y(_0042_));
 sky130_fd_sc_hd__inv_2 _0469_ (.A(net75),
    .Y(_0043_));
 sky130_fd_sc_hd__inv_2 _0470_ (.A(net95),
    .Y(_0044_));
 sky130_fd_sc_hd__inv_2 _0471_ (.A(net85),
    .Y(_0045_));
 sky130_fd_sc_hd__nor2_1 _0472_ (.A(net34),
    .B(net35),
    .Y(_0016_));
 sky130_fd_sc_hd__nand2_1 _0473_ (.A(net33),
    .B(_0016_),
    .Y(_0046_));
 sky130_fd_sc_hd__inv_2 _0474_ (.A(net56),
    .Y(in_sub));
 sky130_fd_sc_hd__nand2b_1 _0475_ (.A_N(net34),
    .B(net35),
    .Y(_0047_));
 sky130_fd_sc_hd__nor2_1 _0476_ (.A(net33),
    .B(_0047_),
    .Y(_0023_));
 sky130_fd_sc_hd__and3b_1 _0477_ (.A_N(net34),
    .B(net33),
    .C(net35),
    .X(_0019_));
 sky130_fd_sc_hd__nand2b_1 _0478_ (.A_N(net35),
    .B(net34),
    .Y(_0048_));
 sky130_fd_sc_hd__nor2_1 _0479_ (.A(net33),
    .B(_0048_),
    .Y(_0017_));
 sky130_fd_sc_hd__and3b_1 _0480_ (.A_N(net35),
    .B(net33),
    .C(net34),
    .X(_0020_));
 sky130_fd_sc_hd__and3b_1 _0481_ (.A_N(net33),
    .B(net35),
    .C(net34),
    .X(_0021_));
 sky130_fd_sc_hd__and3_1 _0482_ (.A(net34),
    .B(net33),
    .C(net35),
    .X(_0022_));
 sky130_fd_sc_hd__a22o_1 _0483_ (.A1(net63),
    .A2(net107),
    .B1(net105),
    .B2(net68),
    .X(_0049_));
 sky130_fd_sc_hd__and2_1 _0484_ (.A(net77),
    .B(net103),
    .X(_0050_));
 sky130_fd_sc_hd__a211o_1 _0485_ (.A1(net60),
    .A2(net109),
    .B1(_0049_),
    .C1(_0050_),
    .X(_0051_));
 sky130_fd_sc_hd__a22o_1 _0486_ (.A1(net63),
    .A2(net99),
    .B1(net96),
    .B2(net77),
    .X(_0052_));
 sky130_fd_sc_hd__a22o_1 _0487_ (.A1(net59),
    .A2(net101),
    .B1(net98),
    .B2(net67),
    .X(_0053_));
 sky130_fd_sc_hd__nor2_1 _0488_ (.A(_0052_),
    .B(_0053_),
    .Y(_0054_));
 sky130_fd_sc_hd__and2_1 _0489_ (.A(net59),
    .B(net95),
    .X(_0055_));
 sky130_fd_sc_hd__a22o_1 _0490_ (.A1(net63),
    .A2(net94),
    .B1(net92),
    .B2(net67),
    .X(_0056_));
 sky130_fd_sc_hd__a211o_1 _0491_ (.A1(net77),
    .A2(net91),
    .B1(_0055_),
    .C1(_0056_),
    .X(_0057_));
 sky130_fd_sc_hd__and2_2 _0492_ (.A(net116),
    .B(net62),
    .X(_0058_));
 sky130_fd_sc_hd__a22o_1 _0493_ (.A1(net65),
    .A2(net115),
    .B1(net69),
    .B2(net113),
    .X(_0059_));
 sky130_fd_sc_hd__a211o_1 _0494_ (.A1(net78),
    .A2(net111),
    .B1(_0058_),
    .C1(_0059_),
    .X(_0060_));
 sky130_fd_sc_hd__a22o_1 _0495_ (.A1(net74),
    .A2(_0051_),
    .B1(_0057_),
    .B2(net80),
    .X(_0061_));
 sky130_fd_sc_hd__a2bb2o_1 _0496_ (.A1_N(_0043_),
    .A2_N(_0054_),
    .B1(_0060_),
    .B2(net72),
    .X(_0062_));
 sky130_fd_sc_hd__o21a_1 _0497_ (.A1(_0061_),
    .A2(_0062_),
    .B1(net85),
    .X(_0063_));
 sky130_fd_sc_hd__nor2_4 _0498_ (.A(_0037_),
    .B(_0038_),
    .Y(_0064_));
 sky130_fd_sc_hd__nand2_1 _0499_ (.A(net72),
    .B(net86),
    .Y(_0065_));
 sky130_fd_sc_hd__nand2_1 _0500_ (.A(\Beff_reg[0] ),
    .B(net116),
    .Y(_0066_));
 sky130_fd_sc_hd__or2_1 _0501_ (.A(\Beff_reg[0] ),
    .B(net116),
    .X(_0067_));
 sky130_fd_sc_hd__xor2_2 _0502_ (.A(\Beff_reg[0] ),
    .B(net116),
    .X(_0068_));
 sky130_fd_sc_hd__or2_1 _0503_ (.A(sub_reg),
    .B(_0068_),
    .X(_0069_));
 sky130_fd_sc_hd__nand2_2 _0504_ (.A(sub_reg),
    .B(_0068_),
    .Y(_0070_));
 sky130_fd_sc_hd__nand2_1 _0505_ (.A(net83),
    .B(_0067_),
    .Y(_0071_));
 sky130_fd_sc_hd__o221a_1 _0506_ (.A1(\A_reg[0] ),
    .A2(_0036_),
    .B1(_0066_),
    .B2(_0033_),
    .C1(_0071_),
    .X(_0072_));
 sky130_fd_sc_hd__a21bo_1 _0507_ (.A1(sel_xor),
    .A2(_0068_),
    .B1_N(_0072_),
    .X(_0073_));
 sky130_fd_sc_hd__a221o_1 _0508_ (.A1(_0058_),
    .A2(_0064_),
    .B1(_0073_),
    .B2(net88),
    .C1(_0063_),
    .X(_0074_));
 sky130_fd_sc_hd__a31o_1 _0509_ (.A1(net90),
    .A2(_0069_),
    .A3(_0070_),
    .B1(_0074_),
    .X(\result_comb[0] ));
 sky130_fd_sc_hd__nand2_1 _0510_ (.A(net68),
    .B(net103),
    .Y(_0075_));
 sky130_fd_sc_hd__nand2_1 _0511_ (.A(net65),
    .B(net105),
    .Y(_0076_));
 sky130_fd_sc_hd__nand2_1 _0512_ (.A(net61),
    .B(net107),
    .Y(_0077_));
 sky130_fd_sc_hd__nand2_1 _0513_ (.A(net78),
    .B(net101),
    .Y(_0078_));
 sky130_fd_sc_hd__nand4_1 _0514_ (.A(_0075_),
    .B(_0076_),
    .C(_0077_),
    .D(_0078_),
    .Y(_0079_));
 sky130_fd_sc_hd__and2_1 _0515_ (.A(net63),
    .B(net92),
    .X(_0080_));
 sky130_fd_sc_hd__a221o_2 _0516_ (.A1(net60),
    .A2(net94),
    .B1(net91),
    .B2(net67),
    .C1(_0080_),
    .X(_0081_));
 sky130_fd_sc_hd__a22o_1 _0517_ (.A1(net73),
    .A2(_0079_),
    .B1(_0081_),
    .B2(net80),
    .X(_0082_));
 sky130_fd_sc_hd__nand2_1 _0518_ (.A(net79),
    .B(net109),
    .Y(_0083_));
 sky130_fd_sc_hd__a22o_1 _0519_ (.A1(net61),
    .A2(net115),
    .B1(net69),
    .B2(net111),
    .X(_0084_));
 sky130_fd_sc_hd__a21oi_1 _0520_ (.A1(net65),
    .A2(net113),
    .B1(_0084_),
    .Y(_0085_));
 sky130_fd_sc_hd__a21oi_1 _0521_ (.A1(_0083_),
    .A2(_0085_),
    .B1(_0037_),
    .Y(_0086_));
 sky130_fd_sc_hd__a22oi_1 _0522_ (.A1(net64),
    .A2(net98),
    .B1(net96),
    .B2(net68),
    .Y(_0087_));
 sky130_fd_sc_hd__nand2_1 _0523_ (.A(net59),
    .B(net99),
    .Y(_0088_));
 sky130_fd_sc_hd__o211a_1 _0524_ (.A1(_0040_),
    .A2(_0044_),
    .B1(_0087_),
    .C1(_0088_),
    .X(_0089_));
 sky130_fd_sc_hd__nor2_1 _0525_ (.A(_0043_),
    .B(_0089_),
    .Y(_0090_));
 sky130_fd_sc_hd__o31a_1 _0526_ (.A1(_0082_),
    .A2(_0086_),
    .A3(_0090_),
    .B1(sel_shr),
    .X(_0091_));
 sky130_fd_sc_hd__nand2_1 _0527_ (.A(net115),
    .B(\Beff_reg[1] ),
    .Y(_0092_));
 sky130_fd_sc_hd__or2_1 _0528_ (.A(\A_reg[1] ),
    .B(\Beff_reg[1] ),
    .X(_0093_));
 sky130_fd_sc_hd__and2_1 _0529_ (.A(_0092_),
    .B(_0093_),
    .X(_0094_));
 sky130_fd_sc_hd__xnor2_2 _0530_ (.A(net115),
    .B(\Beff_reg[1] ),
    .Y(_0095_));
 sky130_fd_sc_hd__nand3_1 _0531_ (.A(_0066_),
    .B(_0070_),
    .C(_0095_),
    .Y(_0096_));
 sky130_fd_sc_hd__a21o_1 _0532_ (.A1(_0066_),
    .A2(_0070_),
    .B1(_0095_),
    .X(_0097_));
 sky130_fd_sc_hd__o22ai_1 _0533_ (.A1(net58),
    .A2(\A_reg[1] ),
    .B1(_0092_),
    .B2(_0033_),
    .Y(_0098_));
 sky130_fd_sc_hd__a221o_1 _0534_ (.A1(net83),
    .A2(_0093_),
    .B1(_0094_),
    .B2(net81),
    .C1(_0098_),
    .X(_0099_));
 sky130_fd_sc_hd__a22o_1 _0535_ (.A1(net116),
    .A2(net66),
    .B1(net115),
    .B2(net61),
    .X(_0100_));
 sky130_fd_sc_hd__a221o_1 _0536_ (.A1(net88),
    .A2(_0099_),
    .B1(_0100_),
    .B2(_0064_),
    .C1(_0091_),
    .X(_0101_));
 sky130_fd_sc_hd__a31o_1 _0537_ (.A1(net90),
    .A2(_0096_),
    .A3(_0097_),
    .B1(_0101_),
    .X(\result_comb[1] ));
 sky130_fd_sc_hd__nand2_1 _0538_ (.A(net113),
    .B(\Beff_reg[2] ),
    .Y(_0102_));
 sky130_fd_sc_hd__or2_1 _0539_ (.A(net113),
    .B(\Beff_reg[2] ),
    .X(_0103_));
 sky130_fd_sc_hd__xnor2_4 _0540_ (.A(net113),
    .B(\Beff_reg[2] ),
    .Y(_0104_));
 sky130_fd_sc_hd__nand3_1 _0541_ (.A(_0092_),
    .B(_0097_),
    .C(_0104_),
    .Y(_0105_));
 sky130_fd_sc_hd__a21o_1 _0542_ (.A1(_0092_),
    .A2(_0097_),
    .B1(_0104_),
    .X(_0106_));
 sky130_fd_sc_hd__a22o_1 _0543_ (.A1(net61),
    .A2(net113),
    .B1(net78),
    .B2(net107),
    .X(_0107_));
 sky130_fd_sc_hd__and2_1 _0544_ (.A(net66),
    .B(net111),
    .X(_0108_));
 sky130_fd_sc_hd__a211o_1 _0545_ (.A1(net70),
    .A2(net109),
    .B1(_0107_),
    .C1(_0108_),
    .X(_0109_));
 sky130_fd_sc_hd__a22o_1 _0546_ (.A1(net60),
    .A2(net92),
    .B1(net91),
    .B2(net63),
    .X(_0110_));
 sky130_fd_sc_hd__a22o_1 _0547_ (.A1(net72),
    .A2(_0109_),
    .B1(_0110_),
    .B2(net80),
    .X(_0111_));
 sky130_fd_sc_hd__a22o_1 _0548_ (.A1(net65),
    .A2(net103),
    .B1(net101),
    .B2(net69),
    .X(_0112_));
 sky130_fd_sc_hd__a22o_1 _0549_ (.A1(net62),
    .A2(net105),
    .B1(net99),
    .B2(net79),
    .X(_0113_));
 sky130_fd_sc_hd__or2_1 _0550_ (.A(_0112_),
    .B(_0113_),
    .X(_0114_));
 sky130_fd_sc_hd__a22o_1 _0551_ (.A1(net64),
    .A2(net96),
    .B1(\A_reg[12] ),
    .B2(net68),
    .X(_0115_));
 sky130_fd_sc_hd__and2_1 _0552_ (.A(net60),
    .B(net98),
    .X(_0116_));
 sky130_fd_sc_hd__a211o_1 _0553_ (.A1(net79),
    .A2(\A_reg[13] ),
    .B1(_0115_),
    .C1(_0116_),
    .X(_0117_));
 sky130_fd_sc_hd__a221o_1 _0554_ (.A1(net73),
    .A2(_0114_),
    .B1(_0117_),
    .B2(net76),
    .C1(_0111_),
    .X(_0118_));
 sky130_fd_sc_hd__a22o_1 _0555_ (.A1(net65),
    .A2(net115),
    .B1(net113),
    .B2(net61),
    .X(_0119_));
 sky130_fd_sc_hd__a21o_1 _0556_ (.A1(net116),
    .A2(net70),
    .B1(_0119_),
    .X(_0120_));
 sky130_fd_sc_hd__nor2_1 _0557_ (.A(_0035_),
    .B(_0104_),
    .Y(_0121_));
 sky130_fd_sc_hd__nor2_1 _0558_ (.A(_0033_),
    .B(_0102_),
    .Y(_0122_));
 sky130_fd_sc_hd__a221o_1 _0559_ (.A1(sel_not),
    .A2(_0039_),
    .B1(_0103_),
    .B2(net83),
    .C1(_0122_),
    .X(_0123_));
 sky130_fd_sc_hd__o21a_1 _0560_ (.A1(_0121_),
    .A2(_0123_),
    .B1(net87),
    .X(_0124_));
 sky130_fd_sc_hd__a221o_1 _0561_ (.A1(net85),
    .A2(_0118_),
    .B1(_0120_),
    .B2(_0064_),
    .C1(_0124_),
    .X(_0125_));
 sky130_fd_sc_hd__a31o_1 _0562_ (.A1(net90),
    .A2(_0105_),
    .A3(_0106_),
    .B1(_0125_),
    .X(\result_comb[2] ));
 sky130_fd_sc_hd__nor2_1 _0563_ (.A(net111),
    .B(\Beff_reg[3] ),
    .Y(_0126_));
 sky130_fd_sc_hd__xnor2_4 _0564_ (.A(net111),
    .B(\Beff_reg[3] ),
    .Y(_0127_));
 sky130_fd_sc_hd__nand3_1 _0565_ (.A(_0102_),
    .B(_0106_),
    .C(_0127_),
    .Y(_0128_));
 sky130_fd_sc_hd__a21o_1 _0566_ (.A1(_0102_),
    .A2(_0106_),
    .B1(_0127_),
    .X(_0129_));
 sky130_fd_sc_hd__nand3_1 _0567_ (.A(net84),
    .B(net111),
    .C(\Beff_reg[3] ),
    .Y(_0130_));
 sky130_fd_sc_hd__o221a_1 _0568_ (.A1(_0036_),
    .A2(net111),
    .B1(_0126_),
    .B2(_0034_),
    .C1(_0130_),
    .X(_0131_));
 sky130_fd_sc_hd__o21ai_1 _0569_ (.A1(_0035_),
    .A2(_0127_),
    .B1(_0131_),
    .Y(_0132_));
 sky130_fd_sc_hd__a22o_1 _0570_ (.A1(net65),
    .A2(net114),
    .B1(net112),
    .B2(net62),
    .X(_0133_));
 sky130_fd_sc_hd__a221o_2 _0571_ (.A1(\A_reg[1] ),
    .A2(net69),
    .B1(net78),
    .B2(net116),
    .C1(_0133_),
    .X(_0134_));
 sky130_fd_sc_hd__a22o_1 _0572_ (.A1(net88),
    .A2(_0132_),
    .B1(_0134_),
    .B2(_0064_),
    .X(_0135_));
 sky130_fd_sc_hd__a22o_1 _0573_ (.A1(net65),
    .A2(net101),
    .B1(net99),
    .B2(net68),
    .X(_0136_));
 sky130_fd_sc_hd__nand2_1 _0574_ (.A(net60),
    .B(net103),
    .Y(_0137_));
 sky130_fd_sc_hd__nand2_1 _0575_ (.A(net77),
    .B(net98),
    .Y(_0138_));
 sky130_fd_sc_hd__nand3b_2 _0576_ (.A_N(_0136_),
    .B(_0137_),
    .C(_0138_),
    .Y(_0139_));
 sky130_fd_sc_hd__and2_2 _0577_ (.A(net59),
    .B(net91),
    .X(_0140_));
 sky130_fd_sc_hd__and2_1 _0578_ (.A(net63),
    .B(net95),
    .X(_0141_));
 sky130_fd_sc_hd__a22o_1 _0579_ (.A1(net59),
    .A2(net96),
    .B1(net94),
    .B2(net67),
    .X(_0142_));
 sky130_fd_sc_hd__a211o_2 _0580_ (.A1(net77),
    .A2(\A_reg[14] ),
    .B1(_0141_),
    .C1(_0142_),
    .X(_0143_));
 sky130_fd_sc_hd__a22o_1 _0581_ (.A1(net65),
    .A2(net109),
    .B1(net105),
    .B2(net78),
    .X(_0144_));
 sky130_fd_sc_hd__nand2_1 _0582_ (.A(net69),
    .B(net107),
    .Y(_0145_));
 sky130_fd_sc_hd__a221o_1 _0583_ (.A1(net61),
    .A2(net112),
    .B1(net107),
    .B2(net69),
    .C1(_0144_),
    .X(_0146_));
 sky130_fd_sc_hd__a22o_1 _0584_ (.A1(net75),
    .A2(_0143_),
    .B1(_0146_),
    .B2(net71),
    .X(_0147_));
 sky130_fd_sc_hd__a221o_1 _0585_ (.A1(net73),
    .A2(_0139_),
    .B1(_0140_),
    .B2(net80),
    .C1(_0147_),
    .X(_0148_));
 sky130_fd_sc_hd__a21o_1 _0586_ (.A1(net85),
    .A2(_0148_),
    .B1(_0135_),
    .X(_0149_));
 sky130_fd_sc_hd__a31o_1 _0587_ (.A1(net90),
    .A2(_0128_),
    .A3(_0129_),
    .B1(_0149_),
    .X(\result_comb[3] ));
 sky130_fd_sc_hd__and2_1 _0588_ (.A(net110),
    .B(\Beff_reg[4] ),
    .X(_0150_));
 sky130_fd_sc_hd__nand2_1 _0589_ (.A(net110),
    .B(\Beff_reg[4] ),
    .Y(_0151_));
 sky130_fd_sc_hd__or2_1 _0590_ (.A(net110),
    .B(\Beff_reg[4] ),
    .X(_0152_));
 sky130_fd_sc_hd__xor2_4 _0591_ (.A(net110),
    .B(\Beff_reg[4] ),
    .X(_0153_));
 sky130_fd_sc_hd__or3_1 _0592_ (.A(_0095_),
    .B(_0104_),
    .C(_0127_),
    .X(_0154_));
 sky130_fd_sc_hd__or4_1 _0593_ (.A(_0066_),
    .B(_0095_),
    .C(_0104_),
    .D(_0127_),
    .X(_0155_));
 sky130_fd_sc_hd__a22oi_2 _0594_ (.A1(net113),
    .A2(\Beff_reg[2] ),
    .B1(\Beff_reg[3] ),
    .B2(net111),
    .Y(_0156_));
 sky130_fd_sc_hd__o32a_1 _0595_ (.A1(_0092_),
    .A2(_0104_),
    .A3(_0127_),
    .B1(_0156_),
    .B2(_0126_),
    .X(_0157_));
 sky130_fd_sc_hd__o211ai_2 _0596_ (.A1(_0070_),
    .A2(_0154_),
    .B1(_0155_),
    .C1(_0157_),
    .Y(_0158_));
 sky130_fd_sc_hd__nand2_1 _0597_ (.A(_0153_),
    .B(_0158_),
    .Y(_0159_));
 sky130_fd_sc_hd__or2_1 _0598_ (.A(_0153_),
    .B(_0158_),
    .X(_0160_));
 sky130_fd_sc_hd__nor2_2 _0599_ (.A(_0041_),
    .B(_0045_),
    .Y(_0161_));
 sky130_fd_sc_hd__nand2_1 _0600_ (.A(net74),
    .B(net85),
    .Y(_0162_));
 sky130_fd_sc_hd__nor2_1 _0601_ (.A(_0054_),
    .B(_0162_),
    .Y(_0163_));
 sky130_fd_sc_hd__nand2_1 _0602_ (.A(net86),
    .B(net74),
    .Y(_0164_));
 sky130_fd_sc_hd__inv_2 _0603_ (.A(_0164_),
    .Y(_0165_));
 sky130_fd_sc_hd__a22o_1 _0604_ (.A1(net69),
    .A2(net113),
    .B1(net109),
    .B2(net61),
    .X(_0166_));
 sky130_fd_sc_hd__a211o_2 _0605_ (.A1(net115),
    .A2(net78),
    .B1(_0108_),
    .C1(_0166_),
    .X(_0167_));
 sky130_fd_sc_hd__and3_1 _0606_ (.A(net76),
    .B(net85),
    .C(_0057_),
    .X(_0168_));
 sky130_fd_sc_hd__nor2_2 _0607_ (.A(_0037_),
    .B(_0045_),
    .Y(_0169_));
 sky130_fd_sc_hd__nand2_1 _0608_ (.A(net72),
    .B(net85),
    .Y(_0170_));
 sky130_fd_sc_hd__a221o_1 _0609_ (.A1(_0064_),
    .A2(_0167_),
    .B1(_0169_),
    .B2(_0051_),
    .C1(_0168_),
    .X(_0171_));
 sky130_fd_sc_hd__a211o_1 _0610_ (.A1(_0058_),
    .A2(_0165_),
    .B1(_0171_),
    .C1(_0163_),
    .X(_0172_));
 sky130_fd_sc_hd__a2bb2o_1 _0611_ (.A1_N(net58),
    .A2_N(net110),
    .B1(_0150_),
    .B2(sel_and),
    .X(_0173_));
 sky130_fd_sc_hd__a22o_1 _0612_ (.A1(net83),
    .A2(_0152_),
    .B1(_0153_),
    .B2(net81),
    .X(_0174_));
 sky130_fd_sc_hd__o21a_1 _0613_ (.A1(_0173_),
    .A2(_0174_),
    .B1(net88),
    .X(_0175_));
 sky130_fd_sc_hd__a311o_1 _0614_ (.A1(net90),
    .A2(_0159_),
    .A3(_0160_),
    .B1(_0172_),
    .C1(_0175_),
    .X(\result_comb[4] ));
 sky130_fd_sc_hd__or2_1 _0615_ (.A(net108),
    .B(\Beff_reg[5] ),
    .X(_0176_));
 sky130_fd_sc_hd__and2_1 _0616_ (.A(net108),
    .B(\Beff_reg[5] ),
    .X(_0177_));
 sky130_fd_sc_hd__nand2_1 _0617_ (.A(net108),
    .B(\Beff_reg[5] ),
    .Y(_0178_));
 sky130_fd_sc_hd__xor2_2 _0618_ (.A(net108),
    .B(\Beff_reg[5] ),
    .X(_0179_));
 sky130_fd_sc_hd__xnor2_1 _0619_ (.A(net108),
    .B(\Beff_reg[5] ),
    .Y(_0180_));
 sky130_fd_sc_hd__a21o_1 _0620_ (.A1(_0153_),
    .A2(_0158_),
    .B1(_0150_),
    .X(_0181_));
 sky130_fd_sc_hd__nand2_1 _0621_ (.A(_0179_),
    .B(_0181_),
    .Y(_0182_));
 sky130_fd_sc_hd__o21a_1 _0622_ (.A1(_0179_),
    .A2(_0181_),
    .B1(net89),
    .X(_0183_));
 sky130_fd_sc_hd__a2bb2o_1 _0623_ (.A1_N(_0089_),
    .A2_N(_0162_),
    .B1(_0165_),
    .B2(_0100_),
    .X(_0184_));
 sky130_fd_sc_hd__a22oi_1 _0624_ (.A1(net69),
    .A2(net112),
    .B1(net109),
    .B2(net65),
    .Y(_0185_));
 sky130_fd_sc_hd__o211a_1 _0625_ (.A1(_0039_),
    .A2(_0040_),
    .B1(_0077_),
    .C1(_0185_),
    .X(_0186_));
 sky130_fd_sc_hd__inv_2 _0626_ (.A(_0186_),
    .Y(_0187_));
 sky130_fd_sc_hd__a22o_1 _0627_ (.A1(_0079_),
    .A2(_0169_),
    .B1(_0187_),
    .B2(_0064_),
    .X(_0188_));
 sky130_fd_sc_hd__a31o_1 _0628_ (.A1(net76),
    .A2(sel_shr),
    .A3(_0081_),
    .B1(_0188_),
    .X(_0189_));
 sky130_fd_sc_hd__a2bb2o_1 _0629_ (.A1_N(net58),
    .A2_N(net108),
    .B1(_0176_),
    .B2(net83),
    .X(_0190_));
 sky130_fd_sc_hd__a221o_1 _0630_ (.A1(net84),
    .A2(_0177_),
    .B1(_0179_),
    .B2(net81),
    .C1(_0190_),
    .X(_0191_));
 sky130_fd_sc_hd__a22o_1 _0631_ (.A1(_0182_),
    .A2(_0183_),
    .B1(_0191_),
    .B2(net88),
    .X(_0192_));
 sky130_fd_sc_hd__or3_1 _0632_ (.A(_0184_),
    .B(_0189_),
    .C(_0192_),
    .X(\result_comb[5] ));
 sky130_fd_sc_hd__nand2_1 _0633_ (.A(net105),
    .B(\Beff_reg[6] ),
    .Y(_0193_));
 sky130_fd_sc_hd__or2_2 _0634_ (.A(net106),
    .B(\Beff_reg[6] ),
    .X(_0194_));
 sky130_fd_sc_hd__inv_2 _0635_ (.A(_0194_),
    .Y(_0195_));
 sky130_fd_sc_hd__xor2_2 _0636_ (.A(net106),
    .B(\Beff_reg[6] ),
    .X(_0196_));
 sky130_fd_sc_hd__xnor2_1 _0637_ (.A(net106),
    .B(\Beff_reg[6] ),
    .Y(_0197_));
 sky130_fd_sc_hd__a21oi_1 _0638_ (.A1(_0179_),
    .A2(_0181_),
    .B1(_0177_),
    .Y(_0198_));
 sky130_fd_sc_hd__xnor2_1 _0639_ (.A(_0196_),
    .B(_0198_),
    .Y(_0199_));
 sky130_fd_sc_hd__o22ai_1 _0640_ (.A1(_0036_),
    .A2(net106),
    .B1(_0193_),
    .B2(_0033_),
    .Y(_0200_));
 sky130_fd_sc_hd__a221o_1 _0641_ (.A1(net83),
    .A2(_0194_),
    .B1(_0196_),
    .B2(sel_xor),
    .C1(_0200_),
    .X(_0201_));
 sky130_fd_sc_hd__a22o_1 _0642_ (.A1(net78),
    .A2(net111),
    .B1(net107),
    .B2(net66),
    .X(_0202_));
 sky130_fd_sc_hd__a22o_1 _0643_ (.A1(net70),
    .A2(net109),
    .B1(net105),
    .B2(net61),
    .X(_0203_));
 sky130_fd_sc_hd__nor2_1 _0644_ (.A(_0202_),
    .B(_0203_),
    .Y(_0204_));
 sky130_fd_sc_hd__nor2_1 _0645_ (.A(_0065_),
    .B(_0204_),
    .Y(_0205_));
 sky130_fd_sc_hd__a31o_1 _0646_ (.A1(net76),
    .A2(sel_shr),
    .A3(_0110_),
    .B1(_0205_),
    .X(_0206_));
 sky130_fd_sc_hd__a22o_1 _0647_ (.A1(_0120_),
    .A2(_0165_),
    .B1(_0201_),
    .B2(net88),
    .X(_0207_));
 sky130_fd_sc_hd__a22o_1 _0648_ (.A1(net72),
    .A2(_0114_),
    .B1(_0117_),
    .B2(net73),
    .X(_0208_));
 sky130_fd_sc_hd__a211o_1 _0649_ (.A1(net85),
    .A2(_0208_),
    .B1(_0207_),
    .C1(_0206_),
    .X(_0209_));
 sky130_fd_sc_hd__a21o_1 _0650_ (.A1(net90),
    .A2(_0199_),
    .B1(_0209_),
    .X(\result_comb[6] ));
 sky130_fd_sc_hd__nor2_1 _0651_ (.A(net104),
    .B(\Beff_reg[7] ),
    .Y(_0210_));
 sky130_fd_sc_hd__or2_1 _0652_ (.A(net104),
    .B(\Beff_reg[7] ),
    .X(_0211_));
 sky130_fd_sc_hd__xor2_1 _0653_ (.A(net104),
    .B(\Beff_reg[7] ),
    .X(_0212_));
 sky130_fd_sc_hd__xnor2_2 _0654_ (.A(net104),
    .B(\Beff_reg[7] ),
    .Y(_0213_));
 sky130_fd_sc_hd__o211ai_1 _0655_ (.A1(_0195_),
    .A2(_0198_),
    .B1(_0213_),
    .C1(_0193_),
    .Y(_0214_));
 sky130_fd_sc_hd__a311o_1 _0656_ (.A1(_0178_),
    .A2(_0182_),
    .A3(_0193_),
    .B1(_0195_),
    .C1(_0213_),
    .X(_0215_));
 sky130_fd_sc_hd__and4_1 _0657_ (.A(_0076_),
    .B(_0083_),
    .C(_0137_),
    .D(_0145_),
    .X(_0216_));
 sky130_fd_sc_hd__nor2_1 _0658_ (.A(_0065_),
    .B(_0216_),
    .Y(_0217_));
 sky130_fd_sc_hd__a32o_1 _0659_ (.A1(net75),
    .A2(net85),
    .A3(_0140_),
    .B1(_0143_),
    .B2(_0161_),
    .X(_0218_));
 sky130_fd_sc_hd__nor2_1 _0660_ (.A(_0036_),
    .B(net104),
    .Y(_0219_));
 sky130_fd_sc_hd__a31o_1 _0661_ (.A1(net84),
    .A2(net103),
    .A3(\Beff_reg[7] ),
    .B1(_0219_),
    .X(_0220_));
 sky130_fd_sc_hd__a221o_1 _0662_ (.A1(net82),
    .A2(_0211_),
    .B1(_0212_),
    .B2(net81),
    .C1(_0220_),
    .X(_0221_));
 sky130_fd_sc_hd__a221o_1 _0663_ (.A1(_0139_),
    .A2(_0169_),
    .B1(_0221_),
    .B2(net87),
    .C1(_0217_),
    .X(_0222_));
 sky130_fd_sc_hd__a211o_1 _0664_ (.A1(_0134_),
    .A2(_0165_),
    .B1(_0218_),
    .C1(_0222_),
    .X(_0223_));
 sky130_fd_sc_hd__a31o_1 _0665_ (.A1(net90),
    .A2(_0214_),
    .A3(_0215_),
    .B1(_0223_),
    .X(\result_comb[7] ));
 sky130_fd_sc_hd__and2_1 _0666_ (.A(net102),
    .B(\Beff_reg[8] ),
    .X(_0224_));
 sky130_fd_sc_hd__nand4_1 _0667_ (.A(_0153_),
    .B(_0179_),
    .C(_0196_),
    .D(_0212_),
    .Y(_0225_));
 sky130_fd_sc_hd__nor3_1 _0668_ (.A(_0070_),
    .B(_0154_),
    .C(_0225_),
    .Y(_0226_));
 sky130_fd_sc_hd__or3_1 _0669_ (.A(_0070_),
    .B(_0154_),
    .C(_0225_),
    .X(_0227_));
 sky130_fd_sc_hd__a21o_1 _0670_ (.A1(_0155_),
    .A2(_0157_),
    .B1(_0225_),
    .X(_0228_));
 sky130_fd_sc_hd__or4_1 _0671_ (.A(_0151_),
    .B(_0180_),
    .C(_0197_),
    .D(_0213_),
    .X(_0229_));
 sky130_fd_sc_hd__a22oi_2 _0672_ (.A1(net106),
    .A2(\Beff_reg[6] ),
    .B1(\Beff_reg[7] ),
    .B2(net103),
    .Y(_0230_));
 sky130_fd_sc_hd__or3_1 _0673_ (.A(_0178_),
    .B(_0197_),
    .C(_0213_),
    .X(_0231_));
 sky130_fd_sc_hd__o211a_1 _0674_ (.A1(_0210_),
    .A2(_0230_),
    .B1(_0231_),
    .C1(_0229_),
    .X(_0232_));
 sky130_fd_sc_hd__nand3_2 _0675_ (.A(_0227_),
    .B(_0228_),
    .C(_0232_),
    .Y(_0233_));
 sky130_fd_sc_hd__or2_1 _0676_ (.A(net102),
    .B(\Beff_reg[8] ),
    .X(_0234_));
 sky130_fd_sc_hd__and2b_2 _0677_ (.A_N(_0224_),
    .B(_0234_),
    .X(_0235_));
 sky130_fd_sc_hd__xor2_1 _0678_ (.A(_0233_),
    .B(_0235_),
    .X(_0236_));
 sky130_fd_sc_hd__a2bb2o_1 _0679_ (.A1_N(net58),
    .A2_N(net102),
    .B1(_0224_),
    .B2(net84),
    .X(_0237_));
 sky130_fd_sc_hd__a221o_1 _0680_ (.A1(net82),
    .A2(_0234_),
    .B1(_0235_),
    .B2(net81),
    .C1(_0237_),
    .X(_0238_));
 sky130_fd_sc_hd__a32o_1 _0681_ (.A1(sel_shl),
    .A2(net75),
    .A3(_0058_),
    .B1(_0161_),
    .B2(_0057_),
    .X(_0239_));
 sky130_fd_sc_hd__nor2_1 _0682_ (.A(_0054_),
    .B(_0170_),
    .Y(_0240_));
 sky130_fd_sc_hd__a22o_1 _0683_ (.A1(net68),
    .A2(net105),
    .B1(net101),
    .B2(net60),
    .X(_0241_));
 sky130_fd_sc_hd__a22o_1 _0684_ (.A1(net77),
    .A2(net107),
    .B1(net103),
    .B2(net64),
    .X(_0242_));
 sky130_fd_sc_hd__nor2_1 _0685_ (.A(_0241_),
    .B(_0242_),
    .Y(_0243_));
 sky130_fd_sc_hd__nor2_1 _0686_ (.A(_0065_),
    .B(_0243_),
    .Y(_0244_));
 sky130_fd_sc_hd__a221o_1 _0687_ (.A1(_0165_),
    .A2(_0167_),
    .B1(_0238_),
    .B2(net87),
    .C1(_0244_),
    .X(_0245_));
 sky130_fd_sc_hd__a2111o_1 _0688_ (.A1(net89),
    .A2(_0236_),
    .B1(_0239_),
    .C1(_0240_),
    .D1(_0245_),
    .X(\result_comb[8] ));
 sky130_fd_sc_hd__or2_1 _0689_ (.A(net100),
    .B(\Beff_reg[9] ),
    .X(_0246_));
 sky130_fd_sc_hd__xor2_4 _0690_ (.A(net100),
    .B(\Beff_reg[9] ),
    .X(_0247_));
 sky130_fd_sc_hd__a21o_1 _0691_ (.A1(_0233_),
    .A2(_0234_),
    .B1(_0224_),
    .X(_0248_));
 sky130_fd_sc_hd__xor2_1 _0692_ (.A(_0247_),
    .B(_0248_),
    .X(_0249_));
 sky130_fd_sc_hd__a32o_1 _0693_ (.A1(net86),
    .A2(net75),
    .A3(_0100_),
    .B1(_0161_),
    .B2(_0081_),
    .X(_0250_));
 sky130_fd_sc_hd__a22o_1 _0694_ (.A1(net77),
    .A2(net105),
    .B1(net101),
    .B2(net64),
    .X(_0251_));
 sky130_fd_sc_hd__nand3b_1 _0695_ (.A_N(_0251_),
    .B(_0088_),
    .C(_0075_),
    .Y(_0252_));
 sky130_fd_sc_hd__a2bb2o_1 _0696_ (.A1_N(_0089_),
    .A2_N(_0170_),
    .B1(_0187_),
    .B2(_0165_),
    .X(_0253_));
 sky130_fd_sc_hd__a21oi_1 _0697_ (.A1(_0064_),
    .A2(_0252_),
    .B1(_0253_),
    .Y(_0254_));
 sky130_fd_sc_hd__nor2_1 _0698_ (.A(net58),
    .B(net100),
    .Y(_0255_));
 sky130_fd_sc_hd__a31o_1 _0699_ (.A1(net84),
    .A2(net100),
    .A3(\Beff_reg[9] ),
    .B1(_0255_),
    .X(_0256_));
 sky130_fd_sc_hd__a22o_1 _0700_ (.A1(net82),
    .A2(_0246_),
    .B1(_0247_),
    .B2(net81),
    .X(_0257_));
 sky130_fd_sc_hd__o21a_1 _0701_ (.A1(_0256_),
    .A2(_0257_),
    .B1(net87),
    .X(_0258_));
 sky130_fd_sc_hd__or3b_1 _0702_ (.A(_0250_),
    .B(_0258_),
    .C_N(_0254_),
    .X(_0259_));
 sky130_fd_sc_hd__a21o_1 _0703_ (.A1(net89),
    .A2(_0249_),
    .B1(_0259_),
    .X(\result_comb[9] ));
 sky130_fd_sc_hd__a22oi_1 _0704_ (.A1(net102),
    .A2(\Beff_reg[8] ),
    .B1(\Beff_reg[9] ),
    .B2(net100),
    .Y(_0260_));
 sky130_fd_sc_hd__or2_1 _0705_ (.A(\A_reg[10] ),
    .B(\Beff_reg[10] ),
    .X(_0261_));
 sky130_fd_sc_hd__and2_1 _0706_ (.A(net98),
    .B(\Beff_reg[10] ),
    .X(_0262_));
 sky130_fd_sc_hd__xor2_2 _0707_ (.A(net98),
    .B(\Beff_reg[10] ),
    .X(_0263_));
 sky130_fd_sc_hd__o21ba_1 _0708_ (.A1(net100),
    .A2(\Beff_reg[9] ),
    .B1_N(_0260_),
    .X(_0264_));
 sky130_fd_sc_hd__a31o_1 _0709_ (.A1(_0233_),
    .A2(_0235_),
    .A3(_0247_),
    .B1(_0264_),
    .X(_0265_));
 sky130_fd_sc_hd__xor2_1 _0710_ (.A(_0263_),
    .B(_0265_),
    .X(_0266_));
 sky130_fd_sc_hd__a21o_1 _0711_ (.A1(net64),
    .A2(net99),
    .B1(_0050_),
    .X(_0267_));
 sky130_fd_sc_hd__a211o_1 _0712_ (.A1(net68),
    .A2(net101),
    .B1(_0116_),
    .C1(_0267_),
    .X(_0268_));
 sky130_fd_sc_hd__nor2_1 _0713_ (.A(_0164_),
    .B(_0204_),
    .Y(_0269_));
 sky130_fd_sc_hd__a22o_1 _0714_ (.A1(sel_not),
    .A2(_0042_),
    .B1(_0262_),
    .B2(net84),
    .X(_0270_));
 sky130_fd_sc_hd__a221o_1 _0715_ (.A1(net82),
    .A2(_0261_),
    .B1(_0263_),
    .B2(net81),
    .C1(_0270_),
    .X(_0271_));
 sky130_fd_sc_hd__a32o_1 _0716_ (.A1(net86),
    .A2(net75),
    .A3(_0120_),
    .B1(_0161_),
    .B2(_0110_),
    .X(_0272_));
 sky130_fd_sc_hd__a221o_1 _0717_ (.A1(_0064_),
    .A2(_0268_),
    .B1(_0271_),
    .B2(net87),
    .C1(_0269_),
    .X(_0273_));
 sky130_fd_sc_hd__a211o_1 _0718_ (.A1(_0117_),
    .A2(_0169_),
    .B1(_0272_),
    .C1(_0273_),
    .X(_0274_));
 sky130_fd_sc_hd__a21o_1 _0719_ (.A1(net89),
    .A2(_0266_),
    .B1(_0274_),
    .X(\result_comb[10] ));
 sky130_fd_sc_hd__nor2_1 _0720_ (.A(net97),
    .B(\Beff_reg[11] ),
    .Y(_0275_));
 sky130_fd_sc_hd__or2_1 _0721_ (.A(net97),
    .B(\Beff_reg[11] ),
    .X(_0276_));
 sky130_fd_sc_hd__and2_1 _0722_ (.A(net97),
    .B(\Beff_reg[11] ),
    .X(_0277_));
 sky130_fd_sc_hd__nor2_2 _0723_ (.A(_0275_),
    .B(_0277_),
    .Y(_0278_));
 sky130_fd_sc_hd__and2_1 _0724_ (.A(_0247_),
    .B(_0263_),
    .X(_0279_));
 sky130_fd_sc_hd__a31o_1 _0725_ (.A1(net100),
    .A2(\Beff_reg[9] ),
    .A3(_0261_),
    .B1(_0262_),
    .X(_0280_));
 sky130_fd_sc_hd__a21o_1 _0726_ (.A1(_0224_),
    .A2(_0279_),
    .B1(_0280_),
    .X(_0281_));
 sky130_fd_sc_hd__a31o_1 _0727_ (.A1(_0233_),
    .A2(_0235_),
    .A3(_0279_),
    .B1(_0281_),
    .X(_0282_));
 sky130_fd_sc_hd__xor2_1 _0728_ (.A(_0278_),
    .B(_0282_),
    .X(_0283_));
 sky130_fd_sc_hd__a22o_1 _0729_ (.A1(net67),
    .A2(net99),
    .B1(net98),
    .B2(net63),
    .X(_0284_));
 sky130_fd_sc_hd__a22o_1 _0730_ (.A1(net79),
    .A2(net101),
    .B1(net96),
    .B2(net60),
    .X(_0285_));
 sky130_fd_sc_hd__o21a_1 _0731_ (.A1(_0284_),
    .A2(_0285_),
    .B1(_0064_),
    .X(_0286_));
 sky130_fd_sc_hd__a21o_1 _0732_ (.A1(_0140_),
    .A2(_0161_),
    .B1(_0286_),
    .X(_0287_));
 sky130_fd_sc_hd__nor2_1 _0733_ (.A(_0164_),
    .B(_0216_),
    .Y(_0288_));
 sky130_fd_sc_hd__a31o_1 _0734_ (.A1(sel_shl),
    .A2(net75),
    .A3(_0134_),
    .B1(_0287_),
    .X(_0289_));
 sky130_fd_sc_hd__a211o_1 _0735_ (.A1(_0143_),
    .A2(_0169_),
    .B1(_0288_),
    .C1(_0289_),
    .X(_0290_));
 sky130_fd_sc_hd__a2bb2o_1 _0736_ (.A1_N(net58),
    .A2_N(net97),
    .B1(_0277_),
    .B2(net84),
    .X(_0291_));
 sky130_fd_sc_hd__a22o_1 _0737_ (.A1(net82),
    .A2(_0276_),
    .B1(_0278_),
    .B2(net81),
    .X(_0292_));
 sky130_fd_sc_hd__o21a_1 _0738_ (.A1(_0291_),
    .A2(_0292_),
    .B1(net87),
    .X(_0293_));
 sky130_fd_sc_hd__a211o_1 _0739_ (.A1(net89),
    .A2(_0283_),
    .B1(_0290_),
    .C1(_0293_),
    .X(\result_comb[11] ));
 sky130_fd_sc_hd__nor2_1 _0740_ (.A(\A_reg[12] ),
    .B(\Beff_reg[12] ),
    .Y(_0294_));
 sky130_fd_sc_hd__nand2_2 _0741_ (.A(net95),
    .B(\Beff_reg[12] ),
    .Y(_0295_));
 sky130_fd_sc_hd__inv_2 _0742_ (.A(_0295_),
    .Y(_0296_));
 sky130_fd_sc_hd__nand2b_2 _0743_ (.A_N(_0294_),
    .B(_0295_),
    .Y(_0297_));
 sky130_fd_sc_hd__o21ai_2 _0744_ (.A1(_0277_),
    .A2(_0281_),
    .B1(_0276_),
    .Y(_0298_));
 sky130_fd_sc_hd__nand3_1 _0745_ (.A(_0235_),
    .B(_0278_),
    .C(_0279_),
    .Y(_0299_));
 sky130_fd_sc_hd__a31o_1 _0746_ (.A1(_0227_),
    .A2(_0228_),
    .A3(_0232_),
    .B1(_0299_),
    .X(_0300_));
 sky130_fd_sc_hd__a21oi_2 _0747_ (.A1(_0298_),
    .A2(_0300_),
    .B1(_0297_),
    .Y(_0301_));
 sky130_fd_sc_hd__a31o_1 _0748_ (.A1(_0297_),
    .A2(_0298_),
    .A3(_0300_),
    .B1(_0032_),
    .X(_0302_));
 sky130_fd_sc_hd__nor2_1 _0749_ (.A(_0301_),
    .B(_0302_),
    .Y(_0303_));
 sky130_fd_sc_hd__o22a_1 _0750_ (.A1(net58),
    .A2(\A_reg[12] ),
    .B1(_0294_),
    .B2(_0034_),
    .X(_0304_));
 sky130_fd_sc_hd__o22a_1 _0751_ (.A1(_0033_),
    .A2(_0295_),
    .B1(_0297_),
    .B2(_0035_),
    .X(_0305_));
 sky130_fd_sc_hd__nand2_1 _0752_ (.A(_0304_),
    .B(_0305_),
    .Y(_0306_));
 sky130_fd_sc_hd__a22o_1 _0753_ (.A1(_0057_),
    .A2(_0169_),
    .B1(_0306_),
    .B2(net87),
    .X(_0307_));
 sky130_fd_sc_hd__a22o_1 _0754_ (.A1(net77),
    .A2(net99),
    .B1(net96),
    .B2(net63),
    .X(_0308_));
 sky130_fd_sc_hd__a211o_1 _0755_ (.A1(net67),
    .A2(net98),
    .B1(_0055_),
    .C1(_0308_),
    .X(_0309_));
 sky130_fd_sc_hd__a2bb2o_1 _0756_ (.A1_N(_0041_),
    .A2_N(_0243_),
    .B1(_0058_),
    .B2(net80),
    .X(_0310_));
 sky130_fd_sc_hd__a22o_1 _0757_ (.A1(net75),
    .A2(_0167_),
    .B1(_0309_),
    .B2(net71),
    .X(_0311_));
 sky130_fd_sc_hd__o21a_1 _0758_ (.A1(_0310_),
    .A2(_0311_),
    .B1(net86),
    .X(_0312_));
 sky130_fd_sc_hd__or3_1 _0759_ (.A(_0303_),
    .B(_0307_),
    .C(_0312_),
    .X(\result_comb[12] ));
 sky130_fd_sc_hd__xnor2_4 _0760_ (.A(net93),
    .B(\Beff_reg[13] ),
    .Y(_0313_));
 sky130_fd_sc_hd__inv_2 _0761_ (.A(_0313_),
    .Y(_0314_));
 sky130_fd_sc_hd__or3_1 _0762_ (.A(_0296_),
    .B(_0301_),
    .C(_0314_),
    .X(_0315_));
 sky130_fd_sc_hd__o21ai_1 _0763_ (.A1(_0296_),
    .A2(_0301_),
    .B1(_0314_),
    .Y(_0316_));
 sky130_fd_sc_hd__nor2_1 _0764_ (.A(_0035_),
    .B(_0313_),
    .Y(_0317_));
 sky130_fd_sc_hd__o21a_1 _0765_ (.A1(net93),
    .A2(\Beff_reg[13] ),
    .B1(net82),
    .X(_0318_));
 sky130_fd_sc_hd__nor2_1 _0766_ (.A(net58),
    .B(net93),
    .Y(_0319_));
 sky130_fd_sc_hd__a31o_1 _0767_ (.A1(net84),
    .A2(net93),
    .A3(\Beff_reg[13] ),
    .B1(_0318_),
    .X(_0320_));
 sky130_fd_sc_hd__o31a_1 _0768_ (.A1(_0317_),
    .A2(_0319_),
    .A3(_0320_),
    .B1(net87),
    .X(_0321_));
 sky130_fd_sc_hd__a22o_1 _0769_ (.A1(net67),
    .A2(net96),
    .B1(net94),
    .B2(net59),
    .X(_0322_));
 sky130_fd_sc_hd__or3b_1 _0770_ (.A(_0322_),
    .B(_0141_),
    .C_N(_0138_),
    .X(_0323_));
 sky130_fd_sc_hd__a22o_1 _0771_ (.A1(net80),
    .A2(_0100_),
    .B1(_0323_),
    .B2(net72),
    .X(_0324_));
 sky130_fd_sc_hd__a221o_1 _0772_ (.A1(net76),
    .A2(_0187_),
    .B1(_0252_),
    .B2(net74),
    .C1(_0324_),
    .X(_0325_));
 sky130_fd_sc_hd__a221o_1 _0773_ (.A1(_0081_),
    .A2(_0169_),
    .B1(_0325_),
    .B2(net86),
    .C1(_0321_),
    .X(_0326_));
 sky130_fd_sc_hd__a31o_1 _0774_ (.A1(net89),
    .A2(_0315_),
    .A3(_0316_),
    .B1(_0326_),
    .X(\result_comb[13] ));
 sky130_fd_sc_hd__nand2_1 _0775_ (.A(net92),
    .B(\Beff_reg[14] ),
    .Y(_0327_));
 sky130_fd_sc_hd__or2_1 _0776_ (.A(net92),
    .B(\Beff_reg[14] ),
    .X(_0328_));
 sky130_fd_sc_hd__and2_1 _0777_ (.A(_0327_),
    .B(_0328_),
    .X(_0329_));
 sky130_fd_sc_hd__nand2_1 _0778_ (.A(_0327_),
    .B(_0328_),
    .Y(_0330_));
 sky130_fd_sc_hd__a22oi_1 _0779_ (.A1(net95),
    .A2(\Beff_reg[12] ),
    .B1(\Beff_reg[13] ),
    .B2(net93),
    .Y(_0331_));
 sky130_fd_sc_hd__a21o_1 _0780_ (.A1(net93),
    .A2(\Beff_reg[13] ),
    .B1(_0296_),
    .X(_0332_));
 sky130_fd_sc_hd__o21a_1 _0781_ (.A1(net93),
    .A2(\Beff_reg[13] ),
    .B1(_0329_),
    .X(_0333_));
 sky130_fd_sc_hd__o21ai_1 _0782_ (.A1(net93),
    .A2(\Beff_reg[13] ),
    .B1(_0329_),
    .Y(_0334_));
 sky130_fd_sc_hd__o21ai_1 _0783_ (.A1(_0301_),
    .A2(_0332_),
    .B1(_0333_),
    .Y(_0335_));
 sky130_fd_sc_hd__or3_1 _0784_ (.A(net93),
    .B(\Beff_reg[13] ),
    .C(_0329_),
    .X(_0336_));
 sky130_fd_sc_hd__o31a_1 _0785_ (.A1(_0301_),
    .A2(_0329_),
    .A3(_0332_),
    .B1(net89),
    .X(_0337_));
 sky130_fd_sc_hd__nand2_1 _0786_ (.A(net81),
    .B(_0329_),
    .Y(_0338_));
 sky130_fd_sc_hd__o2bb2a_1 _0787_ (.A1_N(net82),
    .A2_N(_0328_),
    .B1(net58),
    .B2(net92),
    .X(_0339_));
 sky130_fd_sc_hd__o211ai_1 _0788_ (.A1(_0033_),
    .A2(_0327_),
    .B1(_0338_),
    .C1(_0339_),
    .Y(_0340_));
 sky130_fd_sc_hd__nor2_1 _0789_ (.A(_0043_),
    .B(_0204_),
    .Y(_0341_));
 sky130_fd_sc_hd__a22o_1 _0790_ (.A1(net77),
    .A2(net96),
    .B1(net94),
    .B2(net63),
    .X(_0342_));
 sky130_fd_sc_hd__a22o_1 _0791_ (.A1(net67),
    .A2(net95),
    .B1(net92),
    .B2(net59),
    .X(_0343_));
 sky130_fd_sc_hd__o21a_1 _0792_ (.A1(_0342_),
    .A2(_0343_),
    .B1(net71),
    .X(_0344_));
 sky130_fd_sc_hd__a22o_1 _0793_ (.A1(net80),
    .A2(_0120_),
    .B1(_0268_),
    .B2(net74),
    .X(_0345_));
 sky130_fd_sc_hd__o31a_1 _0794_ (.A1(_0341_),
    .A2(_0344_),
    .A3(_0345_),
    .B1(net86),
    .X(_0346_));
 sky130_fd_sc_hd__a221o_1 _0795_ (.A1(_0110_),
    .A2(_0169_),
    .B1(_0340_),
    .B2(net87),
    .C1(_0346_),
    .X(_0347_));
 sky130_fd_sc_hd__a31o_1 _0796_ (.A1(_0335_),
    .A2(_0336_),
    .A3(_0337_),
    .B1(_0347_),
    .X(\result_comb[14] ));
 sky130_fd_sc_hd__or2_2 _0797_ (.A(net91),
    .B(\Beff_reg[15] ),
    .X(_0348_));
 sky130_fd_sc_hd__nand2_1 _0798_ (.A(net91),
    .B(\Beff_reg[15] ),
    .Y(_0349_));
 sky130_fd_sc_hd__nand2_2 _0799_ (.A(_0348_),
    .B(_0349_),
    .Y(_0350_));
 sky130_fd_sc_hd__a2111o_1 _0800_ (.A1(_0298_),
    .A2(_0300_),
    .B1(_0313_),
    .C1(_0330_),
    .D1(_0297_),
    .X(_0351_));
 sky130_fd_sc_hd__and3_1 _0801_ (.A(net93),
    .B(\Beff_reg[13] ),
    .C(_0328_),
    .X(_0352_));
 sky130_fd_sc_hd__o21a_1 _0802_ (.A1(_0333_),
    .A2(_0352_),
    .B1(_0332_),
    .X(_0353_));
 sky130_fd_sc_hd__a21oi_1 _0803_ (.A1(net92),
    .A2(\Beff_reg[14] ),
    .B1(_0353_),
    .Y(_0354_));
 sky130_fd_sc_hd__nand2_1 _0804_ (.A(_0351_),
    .B(_0354_),
    .Y(_0355_));
 sky130_fd_sc_hd__a21oi_1 _0805_ (.A1(_0351_),
    .A2(_0354_),
    .B1(_0350_),
    .Y(_0356_));
 sky130_fd_sc_hd__a31o_1 _0806_ (.A1(_0350_),
    .A2(_0351_),
    .A3(_0354_),
    .B1(_0032_),
    .X(_0357_));
 sky130_fd_sc_hd__o2bb2a_1 _0807_ (.A1_N(net82),
    .A2_N(_0348_),
    .B1(net58),
    .B2(net91),
    .X(_0358_));
 sky130_fd_sc_hd__o221ai_1 _0808_ (.A1(_0033_),
    .A2(_0349_),
    .B1(_0350_),
    .B2(_0035_),
    .C1(_0358_),
    .Y(_0359_));
 sky130_fd_sc_hd__a221o_1 _0809_ (.A1(net77),
    .A2(net95),
    .B1(net94),
    .B2(net67),
    .C1(_0140_),
    .X(_0360_));
 sky130_fd_sc_hd__o21a_1 _0810_ (.A1(_0080_),
    .A2(_0360_),
    .B1(net71),
    .X(_0361_));
 sky130_fd_sc_hd__o21ai_1 _0811_ (.A1(_0284_),
    .A2(_0285_),
    .B1(net74),
    .Y(_0362_));
 sky130_fd_sc_hd__o21ai_1 _0812_ (.A1(_0043_),
    .A2(_0216_),
    .B1(_0362_),
    .Y(_0363_));
 sky130_fd_sc_hd__a211o_1 _0813_ (.A1(net80),
    .A2(_0134_),
    .B1(_0361_),
    .C1(_0363_),
    .X(_0364_));
 sky130_fd_sc_hd__a22o_1 _0814_ (.A1(net87),
    .A2(_0359_),
    .B1(_0364_),
    .B2(net86),
    .X(_0365_));
 sky130_fd_sc_hd__a21o_1 _0815_ (.A1(_0140_),
    .A2(_0169_),
    .B1(_0365_),
    .X(_0366_));
 sky130_fd_sc_hd__o21bai_1 _0816_ (.A1(_0356_),
    .A2(_0357_),
    .B1_N(_0366_),
    .Y(\result_comb[15] ));
 sky130_fd_sc_hd__or4_1 _0817_ (.A(_0150_),
    .B(_0177_),
    .C(_0262_),
    .D(_0277_),
    .X(_0367_));
 sky130_fd_sc_hd__and3_1 _0818_ (.A(_0066_),
    .B(_0092_),
    .C(_0156_),
    .X(_0368_));
 sky130_fd_sc_hd__a22oi_2 _0819_ (.A1(net92),
    .A2(\Beff_reg[14] ),
    .B1(\Beff_reg[15] ),
    .B2(net91),
    .Y(_0369_));
 sky130_fd_sc_hd__and4_1 _0820_ (.A(_0230_),
    .B(_0260_),
    .C(_0331_),
    .D(_0369_),
    .X(_0370_));
 sky130_fd_sc_hd__and3b_1 _0821_ (.A_N(_0367_),
    .B(_0368_),
    .C(_0370_),
    .X(_0371_));
 sky130_fd_sc_hd__a21oi_1 _0822_ (.A1(net82),
    .A2(_0371_),
    .B1(net81),
    .Y(_0372_));
 sky130_fd_sc_hd__or4_1 _0823_ (.A(_0153_),
    .B(_0179_),
    .C(_0196_),
    .D(_0212_),
    .X(_0373_));
 sky130_fd_sc_hd__nand2_1 _0824_ (.A(_0104_),
    .B(_0127_),
    .Y(_0374_));
 sky130_fd_sc_hd__or4_1 _0825_ (.A(_0068_),
    .B(_0094_),
    .C(_0373_),
    .D(_0374_),
    .X(_0375_));
 sky130_fd_sc_hd__or4_1 _0826_ (.A(_0235_),
    .B(_0247_),
    .C(_0263_),
    .D(_0278_),
    .X(_0376_));
 sky130_fd_sc_hd__and4_1 _0827_ (.A(_0297_),
    .B(_0313_),
    .C(_0330_),
    .D(_0350_),
    .X(_0377_));
 sky130_fd_sc_hd__or4b_1 _0828_ (.A(_0372_),
    .B(_0375_),
    .C(_0376_),
    .D_N(_0377_),
    .X(_0378_));
 sky130_fd_sc_hd__and4_1 _0829_ (.A(\A_reg[1] ),
    .B(net113),
    .C(net111),
    .D(net109),
    .X(_0379_));
 sky130_fd_sc_hd__and3_1 _0830_ (.A(\A_reg[0] ),
    .B(sel_not),
    .C(_0379_),
    .X(_0380_));
 sky130_fd_sc_hd__and3_1 _0831_ (.A(\A_reg[13] ),
    .B(\A_reg[14] ),
    .C(\A_reg[15] ),
    .X(_0381_));
 sky130_fd_sc_hd__and4_1 _0832_ (.A(net107),
    .B(net106),
    .C(net103),
    .D(net102),
    .X(_0382_));
 sky130_fd_sc_hd__and4_1 _0833_ (.A(net99),
    .B(net98),
    .C(net97),
    .D(net95),
    .X(_0383_));
 sky130_fd_sc_hd__and4_1 _0834_ (.A(_0380_),
    .B(_0381_),
    .C(_0382_),
    .D(_0383_),
    .X(_0384_));
 sky130_fd_sc_hd__a21oi_1 _0835_ (.A1(net84),
    .A2(_0371_),
    .B1(_0384_),
    .Y(_0385_));
 sky130_fd_sc_hd__a21boi_1 _0836_ (.A1(_0378_),
    .A2(_0385_),
    .B1_N(net88),
    .Y(_0386_));
 sky130_fd_sc_hd__or2_1 _0837_ (.A(net71),
    .B(net73),
    .X(_0387_));
 sky130_fd_sc_hd__or3_2 _0838_ (.A(net71),
    .B(net73),
    .C(net75),
    .X(_0388_));
 sky130_fd_sc_hd__or2_1 _0839_ (.A(net61),
    .B(_0388_),
    .X(_0389_));
 sky130_fd_sc_hd__or2_1 _0840_ (.A(_0040_),
    .B(_0387_),
    .X(_0390_));
 sky130_fd_sc_hd__or2_1 _0841_ (.A(_0040_),
    .B(_0388_),
    .X(_0391_));
 sky130_fd_sc_hd__a221o_1 _0842_ (.A1(net95),
    .A2(_0389_),
    .B1(_0391_),
    .B2(\A_reg[14] ),
    .C1(net91),
    .X(_0392_));
 sky130_fd_sc_hd__o21a_1 _0843_ (.A1(\sh_hi[3] ),
    .A2(_0388_),
    .B1(_0392_),
    .X(_0393_));
 sky130_fd_sc_hd__nor2_1 _0844_ (.A(net69),
    .B(net78),
    .Y(_0394_));
 sky130_fd_sc_hd__or2_1 _0845_ (.A(_0387_),
    .B(_0394_),
    .X(_0395_));
 sky130_fd_sc_hd__and2_1 _0846_ (.A(net101),
    .B(_0387_),
    .X(_0396_));
 sky130_fd_sc_hd__a211o_1 _0847_ (.A1(net59),
    .A2(net101),
    .B1(net96),
    .C1(_0396_),
    .X(_0397_));
 sky130_fd_sc_hd__a221o_1 _0848_ (.A1(net98),
    .A2(_0390_),
    .B1(_0395_),
    .B2(net99),
    .C1(_0397_),
    .X(_0398_));
 sky130_fd_sc_hd__a21o_1 _0849_ (.A1(net116),
    .A2(net61),
    .B1(net112),
    .X(_0399_));
 sky130_fd_sc_hd__a221o_1 _0850_ (.A1(net114),
    .A2(_0040_),
    .B1(_0394_),
    .B2(net115),
    .C1(_0399_),
    .X(_0400_));
 sky130_fd_sc_hd__o21a_1 _0851_ (.A1(net71),
    .A2(_0394_),
    .B1(net107),
    .X(_0401_));
 sky130_fd_sc_hd__a211o_1 _0852_ (.A1(net72),
    .A2(_0400_),
    .B1(_0401_),
    .C1(net103),
    .X(_0402_));
 sky130_fd_sc_hd__a21o_1 _0853_ (.A1(\sh_hi[3] ),
    .A2(_0394_),
    .B1(_0388_),
    .X(_0403_));
 sky130_fd_sc_hd__a21o_1 _0854_ (.A1(_0040_),
    .A2(net73),
    .B1(net71),
    .X(_0404_));
 sky130_fd_sc_hd__a21o_1 _0855_ (.A1(net59),
    .A2(net73),
    .B1(net71),
    .X(_0405_));
 sky130_fd_sc_hd__a221o_1 _0856_ (.A1(net105),
    .A2(_0404_),
    .B1(_0405_),
    .B2(net109),
    .C1(_0045_),
    .X(_0406_));
 sky130_fd_sc_hd__a221o_1 _0857_ (.A1(_0387_),
    .A2(_0402_),
    .B1(_0403_),
    .B2(net94),
    .C1(_0406_),
    .X(_0407_));
 sky130_fd_sc_hd__a211o_1 _0858_ (.A1(_0388_),
    .A2(_0398_),
    .B1(_0407_),
    .C1(_0393_),
    .X(_0408_));
 sky130_fd_sc_hd__a221o_1 _0859_ (.A1(net112),
    .A2(_0389_),
    .B1(_0391_),
    .B2(net115),
    .C1(net116),
    .X(_0409_));
 sky130_fd_sc_hd__a22o_1 _0860_ (.A1(net107),
    .A2(_0390_),
    .B1(_0395_),
    .B2(net105),
    .X(_0410_));
 sky130_fd_sc_hd__o21a_1 _0861_ (.A1(net59),
    .A2(_0387_),
    .B1(net103),
    .X(_0411_));
 sky130_fd_sc_hd__o31a_1 _0862_ (.A1(net109),
    .A2(_0410_),
    .A3(_0411_),
    .B1(_0388_),
    .X(_0412_));
 sky130_fd_sc_hd__o22a_1 _0863_ (.A1(\sh_hi[3] ),
    .A2(_0388_),
    .B1(_0409_),
    .B2(_0412_),
    .X(_0413_));
 sky130_fd_sc_hd__or2_1 _0864_ (.A(net95),
    .B(_0140_),
    .X(_0414_));
 sky130_fd_sc_hd__a221o_1 _0865_ (.A1(_0040_),
    .A2(net94),
    .B1(\A_reg[14] ),
    .B2(_0394_),
    .C1(_0414_),
    .X(_0415_));
 sky130_fd_sc_hd__a21oi_1 _0866_ (.A1(_0037_),
    .A2(net68),
    .B1(_0042_),
    .Y(_0416_));
 sky130_fd_sc_hd__o21a_1 _0867_ (.A1(net99),
    .A2(_0416_),
    .B1(_0404_),
    .X(_0417_));
 sky130_fd_sc_hd__a2111o_1 _0868_ (.A1(net96),
    .A2(_0405_),
    .B1(_0417_),
    .C1(_0396_),
    .D1(_0038_),
    .X(_0418_));
 sky130_fd_sc_hd__a221o_1 _0869_ (.A1(net114),
    .A2(_0403_),
    .B1(_0415_),
    .B2(net72),
    .C1(_0418_),
    .X(_0419_));
 sky130_fd_sc_hd__o21ai_1 _0870_ (.A1(_0413_),
    .A2(_0419_),
    .B1(_0408_),
    .Y(_0420_));
 sky130_fd_sc_hd__a22o_1 _0871_ (.A1(_0103_),
    .A2(_0127_),
    .B1(_0153_),
    .B2(_0126_),
    .X(_0421_));
 sky130_fd_sc_hd__xnor2_1 _0872_ (.A(_0176_),
    .B(_0197_),
    .Y(_0422_));
 sky130_fd_sc_hd__o22a_1 _0873_ (.A1(_0126_),
    .A2(_0153_),
    .B1(_0194_),
    .B2(_0213_),
    .X(_0423_));
 sky130_fd_sc_hd__a211o_1 _0874_ (.A1(_0093_),
    .A2(_0104_),
    .B1(_0422_),
    .C1(_0069_),
    .X(_0424_));
 sky130_fd_sc_hd__o22a_1 _0875_ (.A1(_0067_),
    .A2(_0095_),
    .B1(_0152_),
    .B2(_0180_),
    .X(_0425_));
 sky130_fd_sc_hd__a2bb2o_1 _0876_ (.A1_N(_0103_),
    .A2_N(_0127_),
    .B1(_0194_),
    .B2(_0213_),
    .X(_0426_));
 sky130_fd_sc_hd__a22o_1 _0877_ (.A1(_0067_),
    .A2(_0095_),
    .B1(_0152_),
    .B2(_0180_),
    .X(_0427_));
 sky130_fd_sc_hd__nor2_1 _0878_ (.A(_0426_),
    .B(_0427_),
    .Y(_0428_));
 sky130_fd_sc_hd__o211a_1 _0879_ (.A1(_0093_),
    .A2(_0104_),
    .B1(_0425_),
    .C1(_0428_),
    .X(_0429_));
 sky130_fd_sc_hd__and4bb_1 _0880_ (.A_N(_0424_),
    .B_N(_0421_),
    .C(_0423_),
    .D(_0429_),
    .X(_0430_));
 sky130_fd_sc_hd__xor2_1 _0881_ (.A(_0234_),
    .B(_0247_),
    .X(_0431_));
 sky130_fd_sc_hd__xor2_1 _0882_ (.A(_0261_),
    .B(_0278_),
    .X(_0432_));
 sky130_fd_sc_hd__xnor2_1 _0883_ (.A(_0328_),
    .B(_0350_),
    .Y(_0433_));
 sky130_fd_sc_hd__a2111o_1 _0884_ (.A1(_0334_),
    .A2(_0336_),
    .B1(_0431_),
    .C1(_0432_),
    .D1(_0433_),
    .X(_0434_));
 sky130_fd_sc_hd__xnor2_1 _0885_ (.A(_0246_),
    .B(_0263_),
    .Y(_0435_));
 sky130_fd_sc_hd__xnor2_1 _0886_ (.A(_0211_),
    .B(_0235_),
    .Y(_0436_));
 sky130_fd_sc_hd__xnor2_1 _0887_ (.A(_0294_),
    .B(_0313_),
    .Y(_0437_));
 sky130_fd_sc_hd__or2_1 _0888_ (.A(_0276_),
    .B(_0297_),
    .X(_0438_));
 sky130_fd_sc_hd__nand2_1 _0889_ (.A(_0276_),
    .B(_0297_),
    .Y(_0439_));
 sky130_fd_sc_hd__and3_1 _0890_ (.A(_0437_),
    .B(_0438_),
    .C(_0439_),
    .X(_0440_));
 sky130_fd_sc_hd__and4b_1 _0891_ (.A_N(_0434_),
    .B(_0435_),
    .C(_0436_),
    .D(_0440_),
    .X(_0441_));
 sky130_fd_sc_hd__o211a_1 _0892_ (.A1(_0226_),
    .A2(_0430_),
    .B1(_0441_),
    .C1(net89),
    .X(_0442_));
 sky130_fd_sc_hd__or3_1 _0893_ (.A(_0386_),
    .B(_0420_),
    .C(_0442_),
    .X(zero_comb));
 sky130_fd_sc_hd__a21o_1 _0894_ (.A1(_0228_),
    .A2(_0232_),
    .B1(_0299_),
    .X(_0443_));
 sky130_fd_sc_hd__or4_1 _0895_ (.A(_0294_),
    .B(_0313_),
    .C(_0330_),
    .D(_0350_),
    .X(_0444_));
 sky130_fd_sc_hd__a31oi_1 _0896_ (.A1(_0295_),
    .A2(_0298_),
    .A3(_0443_),
    .B1(_0444_),
    .Y(_0445_));
 sky130_fd_sc_hd__nand2b_1 _0897_ (.A_N(_0352_),
    .B(_0369_),
    .Y(_0446_));
 sky130_fd_sc_hd__a221o_1 _0898_ (.A1(_0226_),
    .A2(_0441_),
    .B1(_0446_),
    .B2(_0348_),
    .C1(_0445_),
    .X(_0447_));
 sky130_fd_sc_hd__a22o_1 _0899_ (.A1(net115),
    .A2(net69),
    .B1(net114),
    .B2(net78),
    .X(_0448_));
 sky130_fd_sc_hd__a21o_1 _0900_ (.A1(net116),
    .A2(net65),
    .B1(_0448_),
    .X(_0449_));
 sky130_fd_sc_hd__a22o_1 _0901_ (.A1(net73),
    .A2(_0146_),
    .B1(_0449_),
    .B2(net71),
    .X(_0450_));
 sky130_fd_sc_hd__a221o_1 _0902_ (.A1(net75),
    .A2(_0139_),
    .B1(_0143_),
    .B2(net80),
    .C1(_0450_),
    .X(_0451_));
 sky130_fd_sc_hd__a22o_1 _0903_ (.A1(net79),
    .A2(net94),
    .B1(net92),
    .B2(net67),
    .X(_0452_));
 sky130_fd_sc_hd__a21o_1 _0904_ (.A1(net63),
    .A2(net91),
    .B1(_0452_),
    .X(_0453_));
 sky130_fd_sc_hd__a22o_1 _0905_ (.A1(net80),
    .A2(_0167_),
    .B1(_0309_),
    .B2(net73),
    .X(_0454_));
 sky130_fd_sc_hd__a2bb2o_1 _0906_ (.A1_N(_0043_),
    .A2_N(_0243_),
    .B1(_0453_),
    .B2(net72),
    .X(_0455_));
 sky130_fd_sc_hd__o21a_1 _0907_ (.A1(_0454_),
    .A2(_0455_),
    .B1(net86),
    .X(_0456_));
 sky130_fd_sc_hd__a221o_1 _0908_ (.A1(net89),
    .A2(_0447_),
    .B1(_0451_),
    .B2(net85),
    .C1(_0456_),
    .X(carry_comb));
 sky130_fd_sc_hd__a31o_1 _0909_ (.A1(_0349_),
    .A2(_0351_),
    .A3(_0354_),
    .B1(_0032_),
    .X(_0457_));
 sky130_fd_sc_hd__a21oi_1 _0910_ (.A1(_0348_),
    .A2(_0355_),
    .B1(_0457_),
    .Y(overflow_comb));
 sky130_fd_sc_hd__xnor2_1 _0911_ (.A(net17),
    .B(net56),
    .Y(_0000_));
 sky130_fd_sc_hd__xnor2_1 _0912_ (.A(net24),
    .B(net57),
    .Y(_0007_));
 sky130_fd_sc_hd__xnor2_1 _0913_ (.A(net25),
    .B(net57),
    .Y(_0008_));
 sky130_fd_sc_hd__xnor2_1 _0914_ (.A(net26),
    .B(net57),
    .Y(_0009_));
 sky130_fd_sc_hd__xnor2_1 _0915_ (.A(net27),
    .B(net57),
    .Y(_0010_));
 sky130_fd_sc_hd__xnor2_1 _0916_ (.A(net28),
    .B(net57),
    .Y(_0011_));
 sky130_fd_sc_hd__xnor2_1 _0917_ (.A(net29),
    .B(net57),
    .Y(_0012_));
 sky130_fd_sc_hd__xnor2_1 _0918_ (.A(net30),
    .B(net57),
    .Y(_0013_));
 sky130_fd_sc_hd__xnor2_1 _0919_ (.A(net31),
    .B(net56),
    .Y(_0014_));
 sky130_fd_sc_hd__xnor2_1 _0920_ (.A(net32),
    .B(net56),
    .Y(_0015_));
 sky130_fd_sc_hd__xnor2_1 _0921_ (.A(net18),
    .B(net56),
    .Y(_0001_));
 sky130_fd_sc_hd__xnor2_1 _0922_ (.A(net19),
    .B(net56),
    .Y(_0002_));
 sky130_fd_sc_hd__xnor2_1 _0923_ (.A(net20),
    .B(net56),
    .Y(_0003_));
 sky130_fd_sc_hd__xnor2_1 _0924_ (.A(net21),
    .B(net56),
    .Y(_0004_));
 sky130_fd_sc_hd__xnor2_1 _0925_ (.A(net22),
    .B(net56),
    .Y(_0005_));
 sky130_fd_sc_hd__xnor2_1 _0926_ (.A(net23),
    .B(net56),
    .Y(_0006_));
 sky130_fd_sc_hd__nand2_1 _0927_ (.A(_0047_),
    .B(_0048_),
    .Y(_0018_));
 sky130_fd_sc_hd__and2_1 _0928_ (.A(net25),
    .B(net26),
    .X(_0024_));
 sky130_fd_sc_hd__and2_1 _0929_ (.A(net17),
    .B(net24),
    .X(_0025_));
 sky130_fd_sc_hd__and2b_1 _0930_ (.A_N(net25),
    .B(net26),
    .X(_0026_));
 sky130_fd_sc_hd__and2b_1 _0931_ (.A_N(net26),
    .B(net25),
    .X(_0027_));
 sky130_fd_sc_hd__nor2_1 _0932_ (.A(net25),
    .B(net26),
    .Y(_0028_));
 sky130_fd_sc_hd__and2b_1 _0933_ (.A_N(net17),
    .B(net24),
    .X(_0029_));
 sky130_fd_sc_hd__and2b_1 _0934_ (.A_N(net24),
    .B(net17),
    .X(_0030_));
 sky130_fd_sc_hd__nor2_1 _0935_ (.A(net17),
    .B(net24),
    .Y(_0031_));
 sky130_fd_sc_hd__dfxtp_1 _0936_ (.CLK(clknet_3_1__leaf_clk),
    .D(\result_comb[15] ),
    .Q(net37));
 sky130_fd_sc_hd__dfxtp_1 _0937_ (.CLK(clknet_3_1__leaf_clk),
    .D(overflow_comb),
    .Q(net38));
 sky130_fd_sc_hd__dfxtp_1 _0938_ (.CLK(clknet_3_6__leaf_clk),
    .D(\result_comb[0] ),
    .Q(net39));
 sky130_fd_sc_hd__dfxtp_1 _0939_ (.CLK(clknet_3_6__leaf_clk),
    .D(\result_comb[1] ),
    .Q(net46));
 sky130_fd_sc_hd__dfxtp_1 _0940_ (.CLK(clknet_3_3__leaf_clk),
    .D(\result_comb[2] ),
    .Q(net47));
 sky130_fd_sc_hd__dfxtp_1 _0941_ (.CLK(clknet_3_3__leaf_clk),
    .D(\result_comb[3] ),
    .Q(net48));
 sky130_fd_sc_hd__dfxtp_1 _0942_ (.CLK(clknet_3_6__leaf_clk),
    .D(\result_comb[4] ),
    .Q(net49));
 sky130_fd_sc_hd__dfxtp_1 _0943_ (.CLK(clknet_3_7__leaf_clk),
    .D(\result_comb[5] ),
    .Q(net50));
 sky130_fd_sc_hd__dfxtp_1 _0944_ (.CLK(clknet_3_6__leaf_clk),
    .D(\result_comb[6] ),
    .Q(net51));
 sky130_fd_sc_hd__dfxtp_1 _0945_ (.CLK(clknet_3_7__leaf_clk),
    .D(\result_comb[7] ),
    .Q(net52));
 sky130_fd_sc_hd__dfxtp_1 _0946_ (.CLK(clknet_3_4__leaf_clk),
    .D(\result_comb[8] ),
    .Q(net53));
 sky130_fd_sc_hd__dfxtp_1 _0947_ (.CLK(clknet_3_5__leaf_clk),
    .D(\result_comb[9] ),
    .Q(net54));
 sky130_fd_sc_hd__dfxtp_1 _0948_ (.CLK(clknet_3_5__leaf_clk),
    .D(\result_comb[10] ),
    .Q(net40));
 sky130_fd_sc_hd__dfxtp_1 _0949_ (.CLK(clknet_3_5__leaf_clk),
    .D(\result_comb[11] ),
    .Q(net41));
 sky130_fd_sc_hd__dfxtp_1 _0950_ (.CLK(clknet_3_1__leaf_clk),
    .D(\result_comb[12] ),
    .Q(net42));
 sky130_fd_sc_hd__dfxtp_1 _0951_ (.CLK(clknet_3_1__leaf_clk),
    .D(\result_comb[13] ),
    .Q(net43));
 sky130_fd_sc_hd__dfxtp_1 _0952_ (.CLK(clknet_3_4__leaf_clk),
    .D(\result_comb[14] ),
    .Q(net44));
 sky130_fd_sc_hd__dfxtp_1 _0953_ (.CLK(clknet_3_4__leaf_clk),
    .D(zero_comb),
    .Q(net55));
 sky130_fd_sc_hd__dfxtp_1 _0954_ (.CLK(clknet_3_2__leaf_clk),
    .D(net1),
    .Q(\A_reg[0] ));
 sky130_fd_sc_hd__dfxtp_1 _0955_ (.CLK(clknet_3_2__leaf_clk),
    .D(net8),
    .Q(\A_reg[1] ));
 sky130_fd_sc_hd__dfxtp_1 _0956_ (.CLK(clknet_3_2__leaf_clk),
    .D(net9),
    .Q(\A_reg[2] ));
 sky130_fd_sc_hd__dfxtp_1 _0957_ (.CLK(clknet_3_2__leaf_clk),
    .D(net10),
    .Q(\A_reg[3] ));
 sky130_fd_sc_hd__dfxtp_1 _0958_ (.CLK(clknet_3_2__leaf_clk),
    .D(net11),
    .Q(\A_reg[4] ));
 sky130_fd_sc_hd__dfxtp_1 _0959_ (.CLK(clknet_3_2__leaf_clk),
    .D(net12),
    .Q(\A_reg[5] ));
 sky130_fd_sc_hd__dfxtp_1 _0960_ (.CLK(clknet_3_2__leaf_clk),
    .D(net13),
    .Q(\A_reg[6] ));
 sky130_fd_sc_hd__dfxtp_1 _0961_ (.CLK(clknet_3_0__leaf_clk),
    .D(net14),
    .Q(\A_reg[7] ));
 sky130_fd_sc_hd__dfxtp_1 _0962_ (.CLK(clknet_3_0__leaf_clk),
    .D(net15),
    .Q(\A_reg[8] ));
 sky130_fd_sc_hd__dfxtp_1 _0963_ (.CLK(clknet_3_0__leaf_clk),
    .D(net16),
    .Q(\A_reg[9] ));
 sky130_fd_sc_hd__dfxtp_1 _0964_ (.CLK(clknet_3_0__leaf_clk),
    .D(net2),
    .Q(\A_reg[10] ));
 sky130_fd_sc_hd__dfxtp_1 _0965_ (.CLK(clknet_3_0__leaf_clk),
    .D(net3),
    .Q(\A_reg[11] ));
 sky130_fd_sc_hd__dfxtp_1 _0966_ (.CLK(clknet_3_0__leaf_clk),
    .D(net4),
    .Q(\A_reg[12] ));
 sky130_fd_sc_hd__dfxtp_1 _0967_ (.CLK(clknet_3_0__leaf_clk),
    .D(net5),
    .Q(\A_reg[13] ));
 sky130_fd_sc_hd__dfxtp_1 _0968_ (.CLK(clknet_3_0__leaf_clk),
    .D(net6),
    .Q(\A_reg[14] ));
 sky130_fd_sc_hd__dfxtp_1 _0969_ (.CLK(clknet_3_0__leaf_clk),
    .D(net7),
    .Q(\A_reg[15] ));
 sky130_fd_sc_hd__dfxtp_1 _0970_ (.CLK(clknet_3_3__leaf_clk),
    .D(_0000_),
    .Q(\Beff_reg[0] ));
 sky130_fd_sc_hd__dfxtp_1 _0971_ (.CLK(clknet_3_3__leaf_clk),
    .D(_0007_),
    .Q(\Beff_reg[1] ));
 sky130_fd_sc_hd__dfxtp_2 _0972_ (.CLK(clknet_3_2__leaf_clk),
    .D(_0008_),
    .Q(\Beff_reg[2] ));
 sky130_fd_sc_hd__dfxtp_2 _0973_ (.CLK(clknet_3_2__leaf_clk),
    .D(_0009_),
    .Q(\Beff_reg[3] ));
 sky130_fd_sc_hd__dfxtp_2 _0974_ (.CLK(clknet_3_6__leaf_clk),
    .D(_0010_),
    .Q(\Beff_reg[4] ));
 sky130_fd_sc_hd__dfxtp_1 _0975_ (.CLK(clknet_3_6__leaf_clk),
    .D(_0011_),
    .Q(\Beff_reg[5] ));
 sky130_fd_sc_hd__dfxtp_2 _0976_ (.CLK(clknet_3_6__leaf_clk),
    .D(_0012_),
    .Q(\Beff_reg[6] ));
 sky130_fd_sc_hd__dfxtp_2 _0977_ (.CLK(clknet_3_7__leaf_clk),
    .D(_0013_),
    .Q(\Beff_reg[7] ));
 sky130_fd_sc_hd__dfxtp_1 _0978_ (.CLK(clknet_3_5__leaf_clk),
    .D(_0014_),
    .Q(\Beff_reg[8] ));
 sky130_fd_sc_hd__dfxtp_2 _0979_ (.CLK(clknet_3_5__leaf_clk),
    .D(_0015_),
    .Q(\Beff_reg[9] ));
 sky130_fd_sc_hd__dfxtp_1 _0980_ (.CLK(clknet_3_5__leaf_clk),
    .D(_0001_),
    .Q(\Beff_reg[10] ));
 sky130_fd_sc_hd__dfxtp_1 _0981_ (.CLK(clknet_3_4__leaf_clk),
    .D(_0002_),
    .Q(\Beff_reg[11] ));
 sky130_fd_sc_hd__dfxtp_1 _0982_ (.CLK(clknet_3_4__leaf_clk),
    .D(_0003_),
    .Q(\Beff_reg[12] ));
 sky130_fd_sc_hd__dfxtp_4 _0983_ (.CLK(clknet_3_1__leaf_clk),
    .D(_0004_),
    .Q(\Beff_reg[13] ));
 sky130_fd_sc_hd__dfxtp_1 _0984_ (.CLK(clknet_3_1__leaf_clk),
    .D(_0005_),
    .Q(\Beff_reg[14] ));
 sky130_fd_sc_hd__dfxtp_1 _0985_ (.CLK(clknet_3_1__leaf_clk),
    .D(_0006_),
    .Q(\Beff_reg[15] ));
 sky130_fd_sc_hd__dfxtp_1 _0986_ (.CLK(clknet_3_6__leaf_clk),
    .D(in_sub),
    .Q(sub_reg));
 sky130_fd_sc_hd__dfxtp_1 _0987_ (.CLK(clknet_3_7__leaf_clk),
    .D(_0016_),
    .Q(sel_addsub));
 sky130_fd_sc_hd__dfxtp_1 _0988_ (.CLK(clknet_3_7__leaf_clk),
    .D(_0018_),
    .Q(sel_logic));
 sky130_fd_sc_hd__dfxtp_1 _0989_ (.CLK(clknet_3_5__leaf_clk),
    .D(_0021_),
    .Q(sel_shl));
 sky130_fd_sc_hd__dfxtp_1 _0990_ (.CLK(clknet_3_5__leaf_clk),
    .D(_0022_),
    .Q(sel_shr));
 sky130_fd_sc_hd__dfxtp_1 _0991_ (.CLK(clknet_3_7__leaf_clk),
    .D(_0017_),
    .Q(sel_and));
 sky130_fd_sc_hd__dfxtp_1 _0992_ (.CLK(clknet_3_5__leaf_clk),
    .D(_0020_),
    .Q(sel_or));
 sky130_fd_sc_hd__dfxtp_1 _0993_ (.CLK(clknet_3_7__leaf_clk),
    .D(_0023_),
    .Q(sel_xor));
 sky130_fd_sc_hd__dfxtp_1 _0994_ (.CLK(clknet_3_7__leaf_clk),
    .D(_0019_),
    .Q(sel_not));
 sky130_fd_sc_hd__dfxtp_1 _0995_ (.CLK(clknet_3_2__leaf_clk),
    .D(_0024_),
    .Q(\sh_hi[3] ));
 sky130_fd_sc_hd__dfxtp_1 _0996_ (.CLK(clknet_3_3__leaf_clk),
    .D(_0025_),
    .Q(\sh_lo[3] ));
 sky130_fd_sc_hd__dfxtp_1 _0997_ (.CLK(clknet_3_2__leaf_clk),
    .D(_0026_),
    .Q(\sh_hi[2] ));
 sky130_fd_sc_hd__dfxtp_1 _0998_ (.CLK(clknet_3_2__leaf_clk),
    .D(_0027_),
    .Q(\sh_hi[1] ));
 sky130_fd_sc_hd__dfxtp_1 _0999_ (.CLK(clknet_3_2__leaf_clk),
    .D(_0028_),
    .Q(\T[3] ));
 sky130_fd_sc_hd__dfxtp_1 _1000_ (.CLK(clknet_3_3__leaf_clk),
    .D(_0029_),
    .Q(\sh_lo[2] ));
 sky130_fd_sc_hd__dfxtp_1 _1001_ (.CLK(clknet_3_3__leaf_clk),
    .D(_0030_),
    .Q(\sh_lo[1] ));
 sky130_fd_sc_hd__dfxtp_1 _1002_ (.CLK(clknet_3_3__leaf_clk),
    .D(_0031_),
    .Q(\lo_le[0] ));
 sky130_fd_sc_hd__dfxtp_1 _1003_ (.CLK(clknet_3_4__leaf_clk),
    .D(carry_comb),
    .Q(net36));
 sky130_fd_sc_hd__clkbuf_1 _1004_ (.A(net37),
    .X(net45));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_0_Right_0 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_1_Right_1 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_2_Right_2 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_3_Right_3 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_4_Right_4 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_5_Right_5 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_6_Right_6 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_7_Right_7 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_8_Right_8 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_9_Right_9 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_10_Right_10 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_11_Right_11 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_12_Right_12 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_13_Right_13 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_14_Right_14 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_15_Right_15 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_16_Right_16 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_17_Right_17 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_18_Right_18 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_19_Right_19 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_20_Right_20 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_21_Right_21 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_22_Right_22 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_23_Right_23 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_24_Right_24 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_25_Right_25 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_Right_26 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_Right_27 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_Right_28 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_Right_29 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_Right_30 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_31_Right_31 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_32_Right_32 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_33_Right_33 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_34_Right_34 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_35_Right_35 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_36_Right_36 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_37_Right_37 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_38_Right_38 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_39_Right_39 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_40_Right_40 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_41_Right_41 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_42_Right_42 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_43_Right_43 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_44_Right_44 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_45_Right_45 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_46_Right_46 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_0_Left_47 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_1_Left_48 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_2_Left_49 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_3_Left_50 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_4_Left_51 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_5_Left_52 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_6_Left_53 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_7_Left_54 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_8_Left_55 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_9_Left_56 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_10_Left_57 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_11_Left_58 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_12_Left_59 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_13_Left_60 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_14_Left_61 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_15_Left_62 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_16_Left_63 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_17_Left_64 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_18_Left_65 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_19_Left_66 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_20_Left_67 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_21_Left_68 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_22_Left_69 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_23_Left_70 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_24_Left_71 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_25_Left_72 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_Left_73 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_Left_74 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_Left_75 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_Left_76 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_Left_77 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_31_Left_78 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_32_Left_79 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_33_Left_80 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_34_Left_81 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_35_Left_82 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_36_Left_83 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_37_Left_84 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_38_Left_85 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_39_Left_86 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_40_Left_87 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_41_Left_88 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_42_Left_89 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_43_Left_90 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_44_Left_91 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_45_Left_92 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_46_Left_93 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_94 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_95 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_96 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_97 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_98 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_99 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_100 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_101 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_102 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_103 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_104 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_105 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_106 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_107 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_108 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_109 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_110 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_111 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_112 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_113 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_114 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_115 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_116 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_117 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_118 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_119 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_120 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_121 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_122 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_123 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_124 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_125 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_126 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_127 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_128 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_129 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_130 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_131 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_132 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_133 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_134 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_135 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_136 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_137 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_138 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_139 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_140 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_141 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_142 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_143 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_144 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_145 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_146 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_147 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_148 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_149 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_150 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_151 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_152 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_153 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_154 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_155 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_156 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_157 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_158 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_159 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_160 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_161 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_162 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_163 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_164 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_165 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_166 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_167 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_168 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_169 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_170 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_171 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_172 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_173 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_174 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_175 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_176 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_177 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_178 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_179 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_180 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_181 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_182 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_183 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_184 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_185 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_186 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_187 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_188 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_189 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_190 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_191 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_192 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_193 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_194 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_195 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_196 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_197 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_198 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_199 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_200 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_201 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_202 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_203 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_204 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_205 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_206 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_207 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_208 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_209 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_210 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_211 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_212 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_213 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_214 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_215 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_216 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_217 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_218 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_219 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_220 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_221 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_222 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_223 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_224 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_225 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_226 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_227 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_228 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_229 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_230 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_231 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_232 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_233 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_234 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_235 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_236 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_237 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_238 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_239 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_240 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_241 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_242 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_243 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_244 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_245 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_246 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_247 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_248 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_249 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_250 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_251 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_252 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_253 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_254 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_255 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_256 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_257 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_258 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_259 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_260 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_261 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_262 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_263 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_264 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_265 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_266 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_267 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_268 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_269 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_270 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_271 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_272 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_273 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_274 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_275 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_276 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_277 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_278 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_279 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_280 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_281 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_282 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_41_283 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_41_284 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_41_285 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_41_286 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_42_287 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_42_288 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_42_289 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_42_290 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_42_291 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_43_292 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_43_293 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_43_294 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_43_295 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_44_296 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_44_297 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_44_298 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_44_299 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_44_300 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_45_301 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_45_302 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_45_303 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_45_304 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_46_305 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_46_306 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_46_307 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_46_308 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_46_309 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_46_310 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_46_311 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_46_312 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_46_313 ();
 sky130_fd_sc_hd__clkbuf_1 input1 (.A(A[0]),
    .X(net1));
 sky130_fd_sc_hd__clkbuf_1 input2 (.A(A[10]),
    .X(net2));
 sky130_fd_sc_hd__clkbuf_1 input3 (.A(A[11]),
    .X(net3));
 sky130_fd_sc_hd__clkbuf_1 input4 (.A(A[12]),
    .X(net4));
 sky130_fd_sc_hd__clkbuf_1 input5 (.A(A[13]),
    .X(net5));
 sky130_fd_sc_hd__clkbuf_1 input6 (.A(A[14]),
    .X(net6));
 sky130_fd_sc_hd__clkbuf_1 input7 (.A(A[15]),
    .X(net7));
 sky130_fd_sc_hd__clkbuf_1 input8 (.A(A[1]),
    .X(net8));
 sky130_fd_sc_hd__clkbuf_1 input9 (.A(A[2]),
    .X(net9));
 sky130_fd_sc_hd__clkbuf_1 input10 (.A(A[3]),
    .X(net10));
 sky130_fd_sc_hd__clkbuf_1 input11 (.A(A[4]),
    .X(net11));
 sky130_fd_sc_hd__clkbuf_1 input12 (.A(A[5]),
    .X(net12));
 sky130_fd_sc_hd__clkbuf_1 input13 (.A(A[6]),
    .X(net13));
 sky130_fd_sc_hd__clkbuf_1 input14 (.A(A[7]),
    .X(net14));
 sky130_fd_sc_hd__clkbuf_1 input15 (.A(A[8]),
    .X(net15));
 sky130_fd_sc_hd__clkbuf_1 input16 (.A(A[9]),
    .X(net16));
 sky130_fd_sc_hd__buf_1 input17 (.A(B[0]),
    .X(net17));
 sky130_fd_sc_hd__clkbuf_1 input18 (.A(B[10]),
    .X(net18));
 sky130_fd_sc_hd__clkbuf_1 input19 (.A(B[11]),
    .X(net19));
 sky130_fd_sc_hd__clkbuf_1 input20 (.A(B[12]),
    .X(net20));
 sky130_fd_sc_hd__clkbuf_1 input21 (.A(B[13]),
    .X(net21));
 sky130_fd_sc_hd__clkbuf_1 input22 (.A(B[14]),
    .X(net22));
 sky130_fd_sc_hd__clkbuf_1 input23 (.A(B[15]),
    .X(net23));
 sky130_fd_sc_hd__buf_1 input24 (.A(B[1]),
    .X(net24));
 sky130_fd_sc_hd__buf_1 input25 (.A(B[2]),
    .X(net25));
 sky130_fd_sc_hd__buf_1 input26 (.A(B[3]),
    .X(net26));
 sky130_fd_sc_hd__clkbuf_1 input27 (.A(B[4]),
    .X(net27));
 sky130_fd_sc_hd__clkbuf_1 input28 (.A(B[5]),
    .X(net28));
 sky130_fd_sc_hd__clkbuf_1 input29 (.A(B[6]),
    .X(net29));
 sky130_fd_sc_hd__clkbuf_1 input30 (.A(B[7]),
    .X(net30));
 sky130_fd_sc_hd__clkbuf_1 input31 (.A(B[8]),
    .X(net31));
 sky130_fd_sc_hd__clkbuf_1 input32 (.A(B[9]),
    .X(net32));
 sky130_fd_sc_hd__dlymetal6s2s_1 input33 (.A(opcode[0]),
    .X(net33));
 sky130_fd_sc_hd__dlymetal6s2s_1 input34 (.A(opcode[1]),
    .X(net34));
 sky130_fd_sc_hd__dlymetal6s2s_1 input35 (.A(opcode[2]),
    .X(net35));
 sky130_fd_sc_hd__buf_2 output36 (.A(net36),
    .X(C));
 sky130_fd_sc_hd__buf_2 output37 (.A(net37),
    .X(N));
 sky130_fd_sc_hd__buf_2 output38 (.A(net38),
    .X(V));
 sky130_fd_sc_hd__buf_2 output39 (.A(net39),
    .X(Y[0]));
 sky130_fd_sc_hd__buf_2 output40 (.A(net40),
    .X(Y[10]));
 sky130_fd_sc_hd__buf_2 output41 (.A(net41),
    .X(Y[11]));
 sky130_fd_sc_hd__buf_2 output42 (.A(net42),
    .X(Y[12]));
 sky130_fd_sc_hd__buf_2 output43 (.A(net43),
    .X(Y[13]));
 sky130_fd_sc_hd__buf_2 output44 (.A(net44),
    .X(Y[14]));
 sky130_fd_sc_hd__buf_2 output45 (.A(net45),
    .X(Y[15]));
 sky130_fd_sc_hd__buf_2 output46 (.A(net46),
    .X(Y[1]));
 sky130_fd_sc_hd__buf_2 output47 (.A(net47),
    .X(Y[2]));
 sky130_fd_sc_hd__buf_2 output48 (.A(net48),
    .X(Y[3]));
 sky130_fd_sc_hd__buf_2 output49 (.A(net49),
    .X(Y[4]));
 sky130_fd_sc_hd__buf_2 output50 (.A(net50),
    .X(Y[5]));
 sky130_fd_sc_hd__buf_2 output51 (.A(net51),
    .X(Y[6]));
 sky130_fd_sc_hd__buf_2 output52 (.A(net52),
    .X(Y[7]));
 sky130_fd_sc_hd__buf_2 output53 (.A(net53),
    .X(Y[8]));
 sky130_fd_sc_hd__buf_2 output54 (.A(net54),
    .X(Y[9]));
 sky130_fd_sc_hd__buf_2 output55 (.A(net55),
    .X(Z));
 sky130_fd_sc_hd__clkbuf_8 fanout56 (.A(_0046_),
    .X(net56));
 sky130_fd_sc_hd__clkbuf_4 fanout57 (.A(_0046_),
    .X(net57));
 sky130_fd_sc_hd__buf_2 fanout58 (.A(_0036_),
    .X(net58));
 sky130_fd_sc_hd__buf_2 fanout59 (.A(net62),
    .X(net59));
 sky130_fd_sc_hd__clkbuf_2 fanout60 (.A(net62),
    .X(net60));
 sky130_fd_sc_hd__buf_2 fanout61 (.A(net62),
    .X(net61));
 sky130_fd_sc_hd__clkbuf_2 fanout62 (.A(\lo_le[0] ),
    .X(net62));
 sky130_fd_sc_hd__buf_2 fanout63 (.A(net66),
    .X(net63));
 sky130_fd_sc_hd__dlymetal6s2s_1 fanout64 (.A(net66),
    .X(net64));
 sky130_fd_sc_hd__buf_2 fanout65 (.A(net66),
    .X(net65));
 sky130_fd_sc_hd__clkbuf_2 fanout66 (.A(\sh_lo[1] ),
    .X(net66));
 sky130_fd_sc_hd__buf_2 fanout67 (.A(net70),
    .X(net67));
 sky130_fd_sc_hd__clkbuf_2 fanout68 (.A(net70),
    .X(net68));
 sky130_fd_sc_hd__buf_2 fanout69 (.A(net70),
    .X(net69));
 sky130_fd_sc_hd__clkbuf_2 fanout70 (.A(\sh_lo[2] ),
    .X(net70));
 sky130_fd_sc_hd__buf_2 fanout71 (.A(net72),
    .X(net71));
 sky130_fd_sc_hd__buf_2 fanout72 (.A(\T[3] ),
    .X(net72));
 sky130_fd_sc_hd__buf_2 fanout73 (.A(\sh_hi[1] ),
    .X(net73));
 sky130_fd_sc_hd__clkbuf_2 fanout74 (.A(\sh_hi[1] ),
    .X(net74));
 sky130_fd_sc_hd__clkbuf_4 fanout75 (.A(\sh_hi[2] ),
    .X(net75));
 sky130_fd_sc_hd__dlymetal6s2s_1 fanout76 (.A(\sh_hi[2] ),
    .X(net76));
 sky130_fd_sc_hd__buf_2 fanout77 (.A(net79),
    .X(net77));
 sky130_fd_sc_hd__buf_2 fanout78 (.A(net79),
    .X(net78));
 sky130_fd_sc_hd__clkbuf_2 fanout79 (.A(\sh_lo[3] ),
    .X(net79));
 sky130_fd_sc_hd__buf_2 fanout80 (.A(\sh_hi[3] ),
    .X(net80));
 sky130_fd_sc_hd__clkbuf_4 fanout81 (.A(sel_xor),
    .X(net81));
 sky130_fd_sc_hd__clkbuf_4 fanout82 (.A(sel_or),
    .X(net82));
 sky130_fd_sc_hd__clkbuf_2 fanout83 (.A(sel_or),
    .X(net83));
 sky130_fd_sc_hd__clkbuf_4 fanout84 (.A(sel_and),
    .X(net84));
 sky130_fd_sc_hd__clkbuf_4 fanout85 (.A(sel_shr),
    .X(net85));
 sky130_fd_sc_hd__buf_2 fanout86 (.A(sel_shl),
    .X(net86));
 sky130_fd_sc_hd__clkbuf_4 fanout87 (.A(sel_logic),
    .X(net87));
 sky130_fd_sc_hd__clkbuf_2 fanout88 (.A(sel_logic),
    .X(net88));
 sky130_fd_sc_hd__clkbuf_4 fanout89 (.A(sel_addsub),
    .X(net89));
 sky130_fd_sc_hd__clkbuf_2 fanout90 (.A(sel_addsub),
    .X(net90));
 sky130_fd_sc_hd__buf_2 fanout91 (.A(\A_reg[15] ),
    .X(net91));
 sky130_fd_sc_hd__buf_2 fanout92 (.A(\A_reg[14] ),
    .X(net92));
 sky130_fd_sc_hd__clkbuf_4 fanout93 (.A(net94),
    .X(net93));
 sky130_fd_sc_hd__buf_2 fanout94 (.A(\A_reg[13] ),
    .X(net94));
 sky130_fd_sc_hd__clkbuf_4 fanout95 (.A(\A_reg[12] ),
    .X(net95));
 sky130_fd_sc_hd__buf_2 fanout96 (.A(\A_reg[11] ),
    .X(net96));
 sky130_fd_sc_hd__buf_1 fanout97 (.A(\A_reg[11] ),
    .X(net97));
 sky130_fd_sc_hd__clkbuf_4 fanout98 (.A(\A_reg[10] ),
    .X(net98));
 sky130_fd_sc_hd__clkbuf_4 fanout99 (.A(\A_reg[9] ),
    .X(net99));
 sky130_fd_sc_hd__clkbuf_4 fanout100 (.A(\A_reg[9] ),
    .X(net100));
 sky130_fd_sc_hd__buf_2 fanout101 (.A(\A_reg[8] ),
    .X(net101));
 sky130_fd_sc_hd__buf_1 fanout102 (.A(\A_reg[8] ),
    .X(net102));
 sky130_fd_sc_hd__clkbuf_4 fanout103 (.A(\A_reg[7] ),
    .X(net103));
 sky130_fd_sc_hd__clkbuf_2 fanout104 (.A(\A_reg[7] ),
    .X(net104));
 sky130_fd_sc_hd__clkbuf_4 fanout105 (.A(\A_reg[6] ),
    .X(net105));
 sky130_fd_sc_hd__buf_2 fanout106 (.A(\A_reg[6] ),
    .X(net106));
 sky130_fd_sc_hd__clkbuf_4 fanout107 (.A(\A_reg[5] ),
    .X(net107));
 sky130_fd_sc_hd__clkbuf_2 fanout108 (.A(\A_reg[5] ),
    .X(net108));
 sky130_fd_sc_hd__clkbuf_4 fanout109 (.A(\A_reg[4] ),
    .X(net109));
 sky130_fd_sc_hd__buf_2 fanout110 (.A(\A_reg[4] ),
    .X(net110));
 sky130_fd_sc_hd__clkbuf_4 fanout111 (.A(net112),
    .X(net111));
 sky130_fd_sc_hd__clkbuf_2 fanout112 (.A(\A_reg[3] ),
    .X(net112));
 sky130_fd_sc_hd__clkbuf_4 fanout113 (.A(net114),
    .X(net113));
 sky130_fd_sc_hd__clkbuf_2 fanout114 (.A(\A_reg[2] ),
    .X(net114));
 sky130_fd_sc_hd__clkbuf_4 fanout115 (.A(\A_reg[1] ),
    .X(net115));
 sky130_fd_sc_hd__clkbuf_4 fanout116 (.A(\A_reg[0] ),
    .X(net116));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_0_clk (.A(clk),
    .X(clknet_0_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_3_0__f_clk (.A(clknet_0_clk),
    .X(clknet_3_0__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_3_1__f_clk (.A(clknet_0_clk),
    .X(clknet_3_1__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_3_2__f_clk (.A(clknet_0_clk),
    .X(clknet_3_2__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_3_3__f_clk (.A(clknet_0_clk),
    .X(clknet_3_3__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_3_4__f_clk (.A(clknet_0_clk),
    .X(clknet_3_4__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_3_5__f_clk (.A(clknet_0_clk),
    .X(clknet_3_5__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_3_6__f_clk (.A(clknet_0_clk),
    .X(clknet_3_6__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_3_7__f_clk (.A(clknet_0_clk),
    .X(clknet_3_7__leaf_clk));
 sky130_fd_sc_hd__bufinv_16 clkload0 (.A(clknet_3_0__leaf_clk));
 sky130_fd_sc_hd__clkinv_4 clkload1 (.A(clknet_3_1__leaf_clk));
 sky130_fd_sc_hd__clkinvlp_4 clkload2 (.A(clknet_3_3__leaf_clk));
 sky130_fd_sc_hd__inv_6 clkload3 (.A(clknet_3_4__leaf_clk));
 sky130_fd_sc_hd__bufinv_16 clkload4 (.A(clknet_3_5__leaf_clk));
 sky130_fd_sc_hd__clkinvlp_4 clkload5 (.A(clknet_3_6__leaf_clk));
 sky130_fd_sc_hd__clkinvlp_4 clkload6 (.A(clknet_3_7__leaf_clk));
endmodule
