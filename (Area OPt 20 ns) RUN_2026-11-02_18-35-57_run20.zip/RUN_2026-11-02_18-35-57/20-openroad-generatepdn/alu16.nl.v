module alu16 (C,
    N,
    V,
    Z,
    clk,
    A,
    B,
    Y,
    opcode,
    VPWR,
    VGND);
 output C;
 output N;
 output V;
 output Z;
 input clk;
 input [15:0] A;
 input [15:0] B;
 output [15:0] Y;
 input [2:0] opcode;
 inout VPWR;
 inout VGND;

 wire \A_reg[0] ;
 wire \A_reg[10] ;
 wire \A_reg[11] ;
 wire \A_reg[12] ;
 wire \A_reg[13] ;
 wire \A_reg[14] ;
 wire \A_reg[15] ;
 wire \A_reg[1] ;
 wire \A_reg[2] ;
 wire \A_reg[3] ;
 wire \A_reg[4] ;
 wire \A_reg[5] ;
 wire \A_reg[6] ;
 wire \A_reg[7] ;
 wire \A_reg[8] ;
 wire \A_reg[9] ;
 wire \B_reg[0] ;
 wire \B_reg[10] ;
 wire \B_reg[11] ;
 wire \B_reg[12] ;
 wire \B_reg[13] ;
 wire \B_reg[14] ;
 wire \B_reg[15] ;
 wire \B_reg[1] ;
 wire \B_reg[2] ;
 wire \B_reg[3] ;
 wire \B_reg[4] ;
 wire \B_reg[5] ;
 wire \B_reg[6] ;
 wire \B_reg[7] ;
 wire \B_reg[8] ;
 wire \B_reg[9] ;
 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _070_;
 wire _071_;
 wire _072_;
 wire _073_;
 wire _074_;
 wire _075_;
 wire _076_;
 wire _077_;
 wire _078_;
 wire _079_;
 wire _080_;
 wire _081_;
 wire _082_;
 wire _083_;
 wire _084_;
 wire _085_;
 wire _086_;
 wire _087_;
 wire _088_;
 wire _089_;
 wire _090_;
 wire _091_;
 wire _092_;
 wire _093_;
 wire _094_;
 wire _095_;
 wire _096_;
 wire _097_;
 wire _098_;
 wire _099_;
 wire _100_;
 wire _101_;
 wire _102_;
 wire _103_;
 wire _104_;
 wire _105_;
 wire _106_;
 wire _107_;
 wire _108_;
 wire _109_;
 wire _110_;
 wire _111_;
 wire _112_;
 wire _113_;
 wire _114_;
 wire _115_;
 wire _116_;
 wire _117_;
 wire _118_;
 wire _119_;
 wire _120_;
 wire _121_;
 wire _122_;
 wire _123_;
 wire _124_;
 wire _125_;
 wire _126_;
 wire _127_;
 wire _128_;
 wire _129_;
 wire _130_;
 wire _131_;
 wire _132_;
 wire _133_;
 wire _134_;
 wire _135_;
 wire _136_;
 wire _137_;
 wire _138_;
 wire _139_;
 wire _140_;
 wire _141_;
 wire _142_;
 wire _143_;
 wire _144_;
 wire _145_;
 wire _146_;
 wire _147_;
 wire _148_;
 wire _149_;
 wire _150_;
 wire _151_;
 wire _152_;
 wire _153_;
 wire _154_;
 wire _155_;
 wire _156_;
 wire _157_;
 wire _158_;
 wire _159_;
 wire _160_;
 wire _161_;
 wire _162_;
 wire _163_;
 wire _164_;
 wire _165_;
 wire _166_;
 wire _167_;
 wire _168_;
 wire _169_;
 wire _170_;
 wire _171_;
 wire _172_;
 wire _173_;
 wire _174_;
 wire _175_;
 wire _176_;
 wire _177_;
 wire _178_;
 wire _179_;
 wire _180_;
 wire _181_;
 wire _182_;
 wire _183_;
 wire _184_;
 wire _185_;
 wire _186_;
 wire _187_;
 wire _188_;
 wire _189_;
 wire _190_;
 wire _191_;
 wire _192_;
 wire _193_;
 wire _194_;
 wire _195_;
 wire _196_;
 wire _197_;
 wire _198_;
 wire _199_;
 wire _200_;
 wire _201_;
 wire _202_;
 wire _203_;
 wire _204_;
 wire _205_;
 wire _206_;
 wire _207_;
 wire _208_;
 wire _209_;
 wire _210_;
 wire _211_;
 wire _212_;
 wire _213_;
 wire _214_;
 wire _215_;
 wire _216_;
 wire _217_;
 wire _218_;
 wire _219_;
 wire _220_;
 wire _221_;
 wire _222_;
 wire _223_;
 wire _224_;
 wire _225_;
 wire _226_;
 wire _227_;
 wire _228_;
 wire _229_;
 wire _230_;
 wire _231_;
 wire _232_;
 wire _233_;
 wire _234_;
 wire _235_;
 wire _236_;
 wire _237_;
 wire _238_;
 wire _239_;
 wire _240_;
 wire _241_;
 wire _242_;
 wire _243_;
 wire _244_;
 wire _245_;
 wire _246_;
 wire _247_;
 wire _248_;
 wire _249_;
 wire _250_;
 wire _251_;
 wire _252_;
 wire _253_;
 wire _254_;
 wire _255_;
 wire _256_;
 wire _257_;
 wire _258_;
 wire _259_;
 wire _260_;
 wire _261_;
 wire _262_;
 wire _263_;
 wire _264_;
 wire _265_;
 wire _266_;
 wire _267_;
 wire _268_;
 wire _269_;
 wire _270_;
 wire _271_;
 wire _272_;
 wire _273_;
 wire _274_;
 wire _275_;
 wire _276_;
 wire _277_;
 wire _278_;
 wire _279_;
 wire _280_;
 wire _281_;
 wire _282_;
 wire _283_;
 wire _284_;
 wire _285_;
 wire _286_;
 wire _287_;
 wire _288_;
 wire _289_;
 wire _290_;
 wire _291_;
 wire _292_;
 wire _293_;
 wire _294_;
 wire _295_;
 wire carry_comb;
 wire \opcode_reg[0] ;
 wire \opcode_reg[1] ;
 wire \opcode_reg[2] ;
 wire overflow_comb;
 wire \result_comb[0] ;
 wire \result_comb[10] ;
 wire \result_comb[11] ;
 wire \result_comb[12] ;
 wire \result_comb[13] ;
 wire \result_comb[14] ;
 wire \result_comb[15] ;
 wire \result_comb[1] ;
 wire \result_comb[2] ;
 wire \result_comb[3] ;
 wire \result_comb[4] ;
 wire \result_comb[5] ;
 wire \result_comb[6] ;
 wire \result_comb[7] ;
 wire \result_comb[8] ;
 wire \result_comb[9] ;

 sky130_fd_sc_hd__inv_2 _296_ (.A(\B_reg[0] ),
    .Y(_251_));
 sky130_fd_sc_hd__inv_2 _297_ (.A(\A_reg[15] ),
    .Y(_252_));
 sky130_fd_sc_hd__and2b_2 _298_ (.A_N(\opcode_reg[0] ),
    .B(\opcode_reg[1] ),
    .X(_253_));
 sky130_fd_sc_hd__and2_2 _299_ (.A(\opcode_reg[2] ),
    .B(_253_),
    .X(_254_));
 sky130_fd_sc_hd__nand2_2 _300_ (.A(\opcode_reg[2] ),
    .B(_253_),
    .Y(_255_));
 sky130_fd_sc_hd__nand2_2 _301_ (.A(\opcode_reg[1] ),
    .B(\opcode_reg[0] ),
    .Y(_256_));
 sky130_fd_sc_hd__and3_2 _302_ (.A(\opcode_reg[2] ),
    .B(\opcode_reg[1] ),
    .C(\opcode_reg[0] ),
    .X(_257_));
 sky130_fd_sc_hd__a22o_2 _303_ (.A1(\A_reg[11] ),
    .A2(_254_),
    .B1(_257_),
    .B2(\A_reg[4] ),
    .X(_258_));
 sky130_fd_sc_hd__inv_2 _304_ (.A(_258_),
    .Y(_259_));
 sky130_fd_sc_hd__a22o_2 _305_ (.A1(\A_reg[10] ),
    .A2(_254_),
    .B1(_257_),
    .B2(\A_reg[5] ),
    .X(_260_));
 sky130_fd_sc_hd__inv_2 _306_ (.A(_260_),
    .Y(_261_));
 sky130_fd_sc_hd__mux2_1 _307_ (.A0(_258_),
    .A1(_260_),
    .S(\B_reg[0] ),
    .X(_262_));
 sky130_fd_sc_hd__a22oi_2 _308_ (.A1(\A_reg[9] ),
    .A2(_254_),
    .B1(_257_),
    .B2(\A_reg[6] ),
    .Y(_263_));
 sky130_fd_sc_hd__a22oi_2 _309_ (.A1(\A_reg[8] ),
    .A2(_254_),
    .B1(_257_),
    .B2(\A_reg[7] ),
    .Y(_264_));
 sky130_fd_sc_hd__mux2_1 _310_ (.A0(_263_),
    .A1(_264_),
    .S(\B_reg[0] ),
    .X(_265_));
 sky130_fd_sc_hd__inv_2 _311_ (.A(_265_),
    .Y(_266_));
 sky130_fd_sc_hd__mux2_1 _312_ (.A0(_262_),
    .A1(_266_),
    .S(\B_reg[1] ),
    .X(_267_));
 sky130_fd_sc_hd__inv_2 _313_ (.A(_267_),
    .Y(_268_));
 sky130_fd_sc_hd__a22o_2 _314_ (.A1(\A_reg[13] ),
    .A2(_254_),
    .B1(_257_),
    .B2(\A_reg[2] ),
    .X(_269_));
 sky130_fd_sc_hd__a22oi_2 _315_ (.A1(\A_reg[12] ),
    .A2(_254_),
    .B1(_257_),
    .B2(\A_reg[3] ),
    .Y(_270_));
 sky130_fd_sc_hd__nand2_2 _316_ (.A(\B_reg[0] ),
    .B(_270_),
    .Y(_271_));
 sky130_fd_sc_hd__o21ai_2 _317_ (.A1(\B_reg[0] ),
    .A2(_269_),
    .B1(_271_),
    .Y(_272_));
 sky130_fd_sc_hd__a22o_2 _318_ (.A1(\A_reg[14] ),
    .A2(_254_),
    .B1(_257_),
    .B2(\A_reg[1] ),
    .X(_273_));
 sky130_fd_sc_hd__a22o_2 _319_ (.A1(\A_reg[15] ),
    .A2(_254_),
    .B1(_257_),
    .B2(\A_reg[0] ),
    .X(_274_));
 sky130_fd_sc_hd__mux2_1 _320_ (.A0(_273_),
    .A1(_274_),
    .S(_251_),
    .X(_275_));
 sky130_fd_sc_hd__nor2_2 _321_ (.A(\B_reg[1] ),
    .B(_275_),
    .Y(_276_));
 sky130_fd_sc_hd__a211o_2 _322_ (.A1(\B_reg[1] ),
    .A2(_272_),
    .B1(_276_),
    .C1(\B_reg[2] ),
    .X(_277_));
 sky130_fd_sc_hd__a21oi_2 _323_ (.A1(\B_reg[2] ),
    .A2(_267_),
    .B1(\B_reg[3] ),
    .Y(_278_));
 sky130_fd_sc_hd__a22oi_2 _324_ (.A1(\A_reg[6] ),
    .A2(_254_),
    .B1(_257_),
    .B2(\A_reg[9] ),
    .Y(_279_));
 sky130_fd_sc_hd__a22oi_2 _325_ (.A1(\A_reg[7] ),
    .A2(_254_),
    .B1(_257_),
    .B2(\A_reg[8] ),
    .Y(_280_));
 sky130_fd_sc_hd__mux2_1 _326_ (.A0(_279_),
    .A1(_280_),
    .S(_251_),
    .X(_281_));
 sky130_fd_sc_hd__a21o_2 _327_ (.A1(\A_reg[10] ),
    .A2(_257_),
    .B1(_254_),
    .X(_282_));
 sky130_fd_sc_hd__o21ai_2 _328_ (.A1(\A_reg[5] ),
    .A2(_255_),
    .B1(_282_),
    .Y(_283_));
 sky130_fd_sc_hd__a22oi_2 _329_ (.A1(\A_reg[4] ),
    .A2(_254_),
    .B1(_257_),
    .B2(\A_reg[11] ),
    .Y(_284_));
 sky130_fd_sc_hd__mux2_1 _330_ (.A0(_283_),
    .A1(_284_),
    .S(\B_reg[0] ),
    .X(_285_));
 sky130_fd_sc_hd__mux2_1 _331_ (.A0(_281_),
    .A1(_285_),
    .S(\B_reg[1] ),
    .X(_286_));
 sky130_fd_sc_hd__a22oi_2 _332_ (.A1(\A_reg[2] ),
    .A2(_254_),
    .B1(_257_),
    .B2(\A_reg[13] ),
    .Y(_287_));
 sky130_fd_sc_hd__a22oi_2 _333_ (.A1(\A_reg[3] ),
    .A2(_254_),
    .B1(_257_),
    .B2(\A_reg[12] ),
    .Y(_288_));
 sky130_fd_sc_hd__mux2_1 _334_ (.A0(_287_),
    .A1(_288_),
    .S(_251_),
    .X(_289_));
 sky130_fd_sc_hd__a22oi_2 _335_ (.A1(\A_reg[1] ),
    .A2(_254_),
    .B1(_257_),
    .B2(\A_reg[14] ),
    .Y(_290_));
 sky130_fd_sc_hd__a22oi_2 _336_ (.A1(\A_reg[0] ),
    .A2(_254_),
    .B1(_257_),
    .B2(\A_reg[15] ),
    .Y(_291_));
 sky130_fd_sc_hd__mux2_1 _337_ (.A0(_290_),
    .A1(_291_),
    .S(\B_reg[0] ),
    .X(_292_));
 sky130_fd_sc_hd__mux2_1 _338_ (.A0(_289_),
    .A1(_292_),
    .S(\B_reg[1] ),
    .X(_293_));
 sky130_fd_sc_hd__mux2_1 _339_ (.A0(_286_),
    .A1(_293_),
    .S(\B_reg[2] ),
    .X(_294_));
 sky130_fd_sc_hd__a22oi_2 _340_ (.A1(_277_),
    .A2(_278_),
    .B1(_294_),
    .B2(\B_reg[3] ),
    .Y(_295_));
 sky130_fd_sc_hd__or2_2 _341_ (.A(\B_reg[0] ),
    .B(_291_),
    .X(_001_));
 sky130_fd_sc_hd__or2_2 _342_ (.A(\B_reg[1] ),
    .B(_001_),
    .X(_002_));
 sky130_fd_sc_hd__or2_2 _343_ (.A(\B_reg[2] ),
    .B(_002_),
    .X(_003_));
 sky130_fd_sc_hd__or2_2 _344_ (.A(\B_reg[3] ),
    .B(_255_),
    .X(_004_));
 sky130_fd_sc_hd__nor2_2 _345_ (.A(\opcode_reg[2] ),
    .B(_256_),
    .Y(_005_));
 sky130_fd_sc_hd__or2_2 _346_ (.A(\opcode_reg[2] ),
    .B(_256_),
    .X(_006_));
 sky130_fd_sc_hd__nand2_2 _347_ (.A(\A_reg[0] ),
    .B(\B_reg[0] ),
    .Y(_007_));
 sky130_fd_sc_hd__nor3b_2 _348_ (.A(\opcode_reg[2] ),
    .B(\opcode_reg[1] ),
    .C_N(\opcode_reg[0] ),
    .Y(_008_));
 sky130_fd_sc_hd__a221o_2 _349_ (.A1(\opcode_reg[2] ),
    .A2(\opcode_reg[0] ),
    .B1(\B_reg[0] ),
    .B2(\A_reg[0] ),
    .C1(\opcode_reg[1] ),
    .X(_009_));
 sky130_fd_sc_hd__a2bb2o_2 _350_ (.A1_N(\A_reg[0] ),
    .A2_N(\B_reg[0] ),
    .B1(_006_),
    .B2(_009_),
    .X(_010_));
 sky130_fd_sc_hd__nand3b_2 _351_ (.A_N(\opcode_reg[1] ),
    .B(\opcode_reg[0] ),
    .C(\opcode_reg[2] ),
    .Y(_011_));
 sky130_fd_sc_hd__or3b_2 _352_ (.A(\opcode_reg[2] ),
    .B(\opcode_reg[0] ),
    .C_N(\opcode_reg[1] ),
    .X(_012_));
 sky130_fd_sc_hd__o221a_2 _353_ (.A1(\A_reg[0] ),
    .A2(_011_),
    .B1(_012_),
    .B2(_007_),
    .C1(_010_),
    .X(_013_));
 sky130_fd_sc_hd__o21ai_2 _354_ (.A1(_003_),
    .A2(_004_),
    .B1(_013_),
    .Y(_014_));
 sky130_fd_sc_hd__a21o_2 _355_ (.A1(_255_),
    .A2(_295_),
    .B1(_014_),
    .X(\result_comb[0] ));
 sky130_fd_sc_hd__mux2_1 _356_ (.A0(_261_),
    .A1(_263_),
    .S(\B_reg[0] ),
    .X(_015_));
 sky130_fd_sc_hd__and2b_2 _357_ (.A_N(\B_reg[1] ),
    .B(_015_),
    .X(_016_));
 sky130_fd_sc_hd__mux2_1 _358_ (.A0(_264_),
    .A1(_280_),
    .S(\B_reg[0] ),
    .X(_017_));
 sky130_fd_sc_hd__a21oi_2 _359_ (.A1(\B_reg[1] ),
    .A2(_017_),
    .B1(_016_),
    .Y(_018_));
 sky130_fd_sc_hd__mux2_1 _360_ (.A0(_259_),
    .A1(_270_),
    .S(_251_),
    .X(_019_));
 sky130_fd_sc_hd__mux2_1 _361_ (.A0(_269_),
    .A1(_273_),
    .S(_251_),
    .X(_020_));
 sky130_fd_sc_hd__nor2_2 _362_ (.A(\B_reg[1] ),
    .B(_020_),
    .Y(_021_));
 sky130_fd_sc_hd__a211oi_2 _363_ (.A1(\B_reg[1] ),
    .A2(_019_),
    .B1(_021_),
    .C1(\B_reg[2] ),
    .Y(_022_));
 sky130_fd_sc_hd__a211oi_2 _364_ (.A1(\B_reg[2] ),
    .A2(_018_),
    .B1(_022_),
    .C1(\B_reg[3] ),
    .Y(_023_));
 sky130_fd_sc_hd__mux2_1 _365_ (.A0(_279_),
    .A1(_283_),
    .S(\B_reg[0] ),
    .X(_024_));
 sky130_fd_sc_hd__mux2_1 _366_ (.A0(_284_),
    .A1(_288_),
    .S(\B_reg[0] ),
    .X(_025_));
 sky130_fd_sc_hd__mux2_1 _367_ (.A0(_024_),
    .A1(_025_),
    .S(\B_reg[1] ),
    .X(_026_));
 sky130_fd_sc_hd__mux2_1 _368_ (.A0(_287_),
    .A1(_290_),
    .S(\B_reg[0] ),
    .X(_027_));
 sky130_fd_sc_hd__mux2_1 _369_ (.A0(_027_),
    .A1(_001_),
    .S(\B_reg[1] ),
    .X(_028_));
 sky130_fd_sc_hd__mux2_1 _370_ (.A0(_026_),
    .A1(_028_),
    .S(\B_reg[2] ),
    .X(_029_));
 sky130_fd_sc_hd__a21oi_2 _371_ (.A1(\B_reg[3] ),
    .A2(_029_),
    .B1(_023_),
    .Y(_030_));
 sky130_fd_sc_hd__nor3_2 _372_ (.A(\opcode_reg[2] ),
    .B(\opcode_reg[1] ),
    .C(\opcode_reg[0] ),
    .Y(_031_));
 sky130_fd_sc_hd__or4b_2 _373_ (.A(\opcode_reg[2] ),
    .B(\opcode_reg[1] ),
    .C(\opcode_reg[0] ),
    .D_N(\B_reg[1] ),
    .X(_032_));
 sky130_fd_sc_hd__or4b_2 _374_ (.A(\opcode_reg[2] ),
    .B(\opcode_reg[1] ),
    .C(\B_reg[1] ),
    .D_N(\opcode_reg[0] ),
    .X(_033_));
 sky130_fd_sc_hd__a21boi_2 _375_ (.A1(_032_),
    .A2(_033_),
    .B1_N(\A_reg[1] ),
    .Y(_034_));
 sky130_fd_sc_hd__nand3b_2 _376_ (.A_N(\A_reg[1] ),
    .B(_032_),
    .C(_033_),
    .Y(_035_));
 sky130_fd_sc_hd__and2b_2 _377_ (.A_N(_034_),
    .B(_035_),
    .X(_036_));
 sky130_fd_sc_hd__a21bo_2 _378_ (.A1(_251_),
    .A2(_008_),
    .B1_N(_007_),
    .X(_037_));
 sky130_fd_sc_hd__nor2_2 _379_ (.A(_036_),
    .B(_037_),
    .Y(_038_));
 sky130_fd_sc_hd__or2_2 _380_ (.A(\opcode_reg[2] ),
    .B(\opcode_reg[1] ),
    .X(_039_));
 sky130_fd_sc_hd__nor2_2 _381_ (.A(\opcode_reg[2] ),
    .B(\opcode_reg[1] ),
    .Y(_040_));
 sky130_fd_sc_hd__a2111o_2 _382_ (.A1(_036_),
    .A2(_037_),
    .B1(_038_),
    .C1(\opcode_reg[1] ),
    .D1(\opcode_reg[2] ),
    .X(_041_));
 sky130_fd_sc_hd__or3b_2 _383_ (.A(\opcode_reg[1] ),
    .B(\opcode_reg[0] ),
    .C_N(\opcode_reg[2] ),
    .X(_042_));
 sky130_fd_sc_hd__nand2_2 _384_ (.A(\B_reg[1] ),
    .B(\A_reg[1] ),
    .Y(_043_));
 sky130_fd_sc_hd__nand2b_2 _385_ (.A_N(_042_),
    .B(_043_),
    .Y(_044_));
 sky130_fd_sc_hd__a2bb2o_2 _386_ (.A1_N(\B_reg[1] ),
    .A2_N(\A_reg[1] ),
    .B1(_006_),
    .B2(_044_),
    .X(_045_));
 sky130_fd_sc_hd__o221a_2 _387_ (.A1(\A_reg[1] ),
    .A2(_011_),
    .B1(_012_),
    .B2(_043_),
    .C1(_045_),
    .X(_046_));
 sky130_fd_sc_hd__or3_2 _388_ (.A(\B_reg[1] ),
    .B(\B_reg[2] ),
    .C(_292_),
    .X(_047_));
 sky130_fd_sc_hd__o211a_2 _389_ (.A1(_004_),
    .A2(_047_),
    .B1(_046_),
    .C1(_041_),
    .X(_048_));
 sky130_fd_sc_hd__a21bo_2 _390_ (.A1(_255_),
    .A2(_030_),
    .B1_N(_048_),
    .X(\result_comb[1] ));
 sky130_fd_sc_hd__mux2_1 _391_ (.A0(_265_),
    .A1(_281_),
    .S(\B_reg[1] ),
    .X(_049_));
 sky130_fd_sc_hd__nand2_2 _392_ (.A(\B_reg[1] ),
    .B(_262_),
    .Y(_050_));
 sky130_fd_sc_hd__o21ba_2 _393_ (.A1(\B_reg[1] ),
    .A2(_272_),
    .B1_N(\B_reg[2] ),
    .X(_051_));
 sky130_fd_sc_hd__a22o_2 _394_ (.A1(\B_reg[2] ),
    .A2(_049_),
    .B1(_050_),
    .B2(_051_),
    .X(_052_));
 sky130_fd_sc_hd__nand2b_2 _395_ (.A_N(_289_),
    .B(\B_reg[1] ),
    .Y(_053_));
 sky130_fd_sc_hd__o21ai_2 _396_ (.A1(\B_reg[1] ),
    .A2(_285_),
    .B1(_053_),
    .Y(_054_));
 sky130_fd_sc_hd__o21ai_2 _397_ (.A1(\B_reg[1] ),
    .A2(_292_),
    .B1(\B_reg[2] ),
    .Y(_055_));
 sky130_fd_sc_hd__o21ai_2 _398_ (.A1(\B_reg[2] ),
    .A2(_054_),
    .B1(_055_),
    .Y(_056_));
 sky130_fd_sc_hd__mux2_1 _399_ (.A0(_052_),
    .A1(_056_),
    .S(\B_reg[3] ),
    .X(_057_));
 sky130_fd_sc_hd__a31o_2 _400_ (.A1(_035_),
    .A2(_037_),
    .A3(_040_),
    .B1(_034_),
    .X(_058_));
 sky130_fd_sc_hd__mux2_1 _401_ (.A0(_008_),
    .A1(_031_),
    .S(\B_reg[2] ),
    .X(_059_));
 sky130_fd_sc_hd__or2_2 _402_ (.A(\A_reg[2] ),
    .B(_059_),
    .X(_060_));
 sky130_fd_sc_hd__and2_2 _403_ (.A(\A_reg[2] ),
    .B(_059_),
    .X(_061_));
 sky130_fd_sc_hd__nor2_2 _404_ (.A(_039_),
    .B(_061_),
    .Y(_062_));
 sky130_fd_sc_hd__nand2_2 _405_ (.A(_060_),
    .B(_062_),
    .Y(_063_));
 sky130_fd_sc_hd__xor2_2 _406_ (.A(_058_),
    .B(_063_),
    .X(_064_));
 sky130_fd_sc_hd__nand2_2 _407_ (.A(\B_reg[2] ),
    .B(\A_reg[2] ),
    .Y(_065_));
 sky130_fd_sc_hd__nand2b_2 _408_ (.A_N(_042_),
    .B(_065_),
    .Y(_066_));
 sky130_fd_sc_hd__a2bb2o_2 _409_ (.A1_N(\B_reg[2] ),
    .A2_N(\A_reg[2] ),
    .B1(_006_),
    .B2(_066_),
    .X(_067_));
 sky130_fd_sc_hd__o221a_2 _410_ (.A1(\A_reg[2] ),
    .A2(_011_),
    .B1(_012_),
    .B2(_065_),
    .C1(_067_),
    .X(_068_));
 sky130_fd_sc_hd__or2_2 _411_ (.A(\B_reg[2] ),
    .B(_028_),
    .X(_069_));
 sky130_fd_sc_hd__o211a_2 _412_ (.A1(_004_),
    .A2(_069_),
    .B1(_068_),
    .C1(_064_),
    .X(_070_));
 sky130_fd_sc_hd__o21ai_2 _413_ (.A1(_254_),
    .A2(_057_),
    .B1(_070_),
    .Y(\result_comb[2] ));
 sky130_fd_sc_hd__mux2_1 _414_ (.A0(_019_),
    .A1(_015_),
    .S(\B_reg[1] ),
    .X(_071_));
 sky130_fd_sc_hd__mux2_1 _415_ (.A0(_017_),
    .A1(_024_),
    .S(\B_reg[1] ),
    .X(_072_));
 sky130_fd_sc_hd__mux2_1 _416_ (.A0(_025_),
    .A1(_027_),
    .S(\B_reg[1] ),
    .X(_073_));
 sky130_fd_sc_hd__mux2_1 _417_ (.A0(_073_),
    .A1(_002_),
    .S(\B_reg[2] ),
    .X(_074_));
 sky130_fd_sc_hd__mux4_2 _418_ (.A0(_071_),
    .A1(_072_),
    .A2(_073_),
    .A3(_002_),
    .S0(\B_reg[2] ),
    .S1(\B_reg[3] ),
    .X(_075_));
 sky130_fd_sc_hd__a31o_2 _419_ (.A1(_040_),
    .A2(_058_),
    .A3(_060_),
    .B1(_061_),
    .X(_076_));
 sky130_fd_sc_hd__mux2_1 _420_ (.A0(_008_),
    .A1(_031_),
    .S(\B_reg[3] ),
    .X(_077_));
 sky130_fd_sc_hd__a21oi_2 _421_ (.A1(\A_reg[3] ),
    .A2(_077_),
    .B1(_039_),
    .Y(_078_));
 sky130_fd_sc_hd__o21a_2 _422_ (.A1(\A_reg[3] ),
    .A2(_077_),
    .B1(_078_),
    .X(_079_));
 sky130_fd_sc_hd__xnor2_2 _423_ (.A(_076_),
    .B(_079_),
    .Y(_080_));
 sky130_fd_sc_hd__or2_2 _424_ (.A(\B_reg[2] ),
    .B(_293_),
    .X(_081_));
 sky130_fd_sc_hd__nand2_2 _425_ (.A(\B_reg[3] ),
    .B(\A_reg[3] ),
    .Y(_082_));
 sky130_fd_sc_hd__nand2b_2 _426_ (.A_N(_042_),
    .B(_082_),
    .Y(_083_));
 sky130_fd_sc_hd__a2bb2o_2 _427_ (.A1_N(\B_reg[3] ),
    .A2_N(\A_reg[3] ),
    .B1(_006_),
    .B2(_083_),
    .X(_084_));
 sky130_fd_sc_hd__o221a_2 _428_ (.A1(\A_reg[3] ),
    .A2(_011_),
    .B1(_012_),
    .B2(_082_),
    .C1(_084_),
    .X(_085_));
 sky130_fd_sc_hd__o211a_2 _429_ (.A1(_004_),
    .A2(_081_),
    .B1(_085_),
    .C1(_080_),
    .X(_086_));
 sky130_fd_sc_hd__o21ai_2 _430_ (.A1(_254_),
    .A2(_075_),
    .B1(_086_),
    .Y(\result_comb[3] ));
 sky130_fd_sc_hd__mux2_1 _431_ (.A0(_008_),
    .A1(_031_),
    .S(\B_reg[4] ),
    .X(_087_));
 sky130_fd_sc_hd__nor2_2 _432_ (.A(\A_reg[4] ),
    .B(_087_),
    .Y(_088_));
 sky130_fd_sc_hd__or2_2 _433_ (.A(\A_reg[4] ),
    .B(_087_),
    .X(_089_));
 sky130_fd_sc_hd__and2_2 _434_ (.A(\A_reg[4] ),
    .B(_087_),
    .X(_090_));
 sky130_fd_sc_hd__or3_2 _435_ (.A(_039_),
    .B(_088_),
    .C(_090_),
    .X(_091_));
 sky130_fd_sc_hd__a22o_2 _436_ (.A1(\A_reg[3] ),
    .A2(_077_),
    .B1(_079_),
    .B2(_076_),
    .X(_092_));
 sky130_fd_sc_hd__xor2_2 _437_ (.A(_091_),
    .B(_092_),
    .X(_093_));
 sky130_fd_sc_hd__mux2_1 _438_ (.A0(_268_),
    .A1(_286_),
    .S(\B_reg[2] ),
    .X(_094_));
 sky130_fd_sc_hd__mux2_1 _439_ (.A0(_094_),
    .A1(_081_),
    .S(\B_reg[3] ),
    .X(_095_));
 sky130_fd_sc_hd__nand2_2 _440_ (.A(\A_reg[4] ),
    .B(\B_reg[4] ),
    .Y(_096_));
 sky130_fd_sc_hd__nand2b_2 _441_ (.A_N(_042_),
    .B(_096_),
    .Y(_097_));
 sky130_fd_sc_hd__a2bb2o_2 _442_ (.A1_N(\A_reg[4] ),
    .A2_N(\B_reg[4] ),
    .B1(_006_),
    .B2(_097_),
    .X(_098_));
 sky130_fd_sc_hd__o221a_2 _443_ (.A1(\A_reg[4] ),
    .A2(_011_),
    .B1(_012_),
    .B2(_096_),
    .C1(_098_),
    .X(_099_));
 sky130_fd_sc_hd__o211a_2 _444_ (.A1(_254_),
    .A2(_095_),
    .B1(_099_),
    .C1(_093_),
    .X(_100_));
 sky130_fd_sc_hd__o21ai_2 _445_ (.A1(_004_),
    .A2(_074_),
    .B1(_100_),
    .Y(\result_comb[4] ));
 sky130_fd_sc_hd__mux2_1 _446_ (.A0(_008_),
    .A1(_031_),
    .S(\B_reg[5] ),
    .X(_101_));
 sky130_fd_sc_hd__and2_2 _447_ (.A(\A_reg[5] ),
    .B(_101_),
    .X(_102_));
 sky130_fd_sc_hd__nor2_2 _448_ (.A(_039_),
    .B(_102_),
    .Y(_103_));
 sky130_fd_sc_hd__o21a_2 _449_ (.A1(\A_reg[5] ),
    .A2(_101_),
    .B1(_103_),
    .X(_104_));
 sky130_fd_sc_hd__a31o_2 _450_ (.A1(_040_),
    .A2(_089_),
    .A3(_092_),
    .B1(_090_),
    .X(_105_));
 sky130_fd_sc_hd__xnor2_2 _451_ (.A(_104_),
    .B(_105_),
    .Y(_106_));
 sky130_fd_sc_hd__nand2_2 _452_ (.A(\B_reg[2] ),
    .B(_026_),
    .Y(_107_));
 sky130_fd_sc_hd__o21ai_2 _453_ (.A1(\B_reg[2] ),
    .A2(_018_),
    .B1(_107_),
    .Y(_108_));
 sky130_fd_sc_hd__mux2_1 _454_ (.A0(_108_),
    .A1(_069_),
    .S(\B_reg[3] ),
    .X(_109_));
 sky130_fd_sc_hd__nand2_2 _455_ (.A(\A_reg[5] ),
    .B(\B_reg[5] ),
    .Y(_110_));
 sky130_fd_sc_hd__nand2b_2 _456_ (.A_N(_042_),
    .B(_110_),
    .Y(_111_));
 sky130_fd_sc_hd__a2bb2o_2 _457_ (.A1_N(\A_reg[5] ),
    .A2_N(\B_reg[5] ),
    .B1(_006_),
    .B2(_111_),
    .X(_112_));
 sky130_fd_sc_hd__o221a_2 _458_ (.A1(\A_reg[5] ),
    .A2(_011_),
    .B1(_012_),
    .B2(_110_),
    .C1(_112_),
    .X(_113_));
 sky130_fd_sc_hd__o211a_2 _459_ (.A1(_254_),
    .A2(_109_),
    .B1(_113_),
    .C1(_106_),
    .X(_114_));
 sky130_fd_sc_hd__o21ai_2 _460_ (.A1(_004_),
    .A2(_056_),
    .B1(_114_),
    .Y(\result_comb[5] ));
 sky130_fd_sc_hd__mux2_1 _461_ (.A0(_008_),
    .A1(_031_),
    .S(\B_reg[6] ),
    .X(_115_));
 sky130_fd_sc_hd__and2_2 _462_ (.A(\A_reg[6] ),
    .B(_115_),
    .X(_116_));
 sky130_fd_sc_hd__nor2_2 _463_ (.A(_039_),
    .B(_116_),
    .Y(_117_));
 sky130_fd_sc_hd__o21a_2 _464_ (.A1(\A_reg[6] ),
    .A2(_115_),
    .B1(_117_),
    .X(_118_));
 sky130_fd_sc_hd__a21o_2 _465_ (.A1(_104_),
    .A2(_105_),
    .B1(_102_),
    .X(_119_));
 sky130_fd_sc_hd__xnor2_2 _466_ (.A(_118_),
    .B(_119_),
    .Y(_120_));
 sky130_fd_sc_hd__nor2_2 _467_ (.A(\B_reg[2] ),
    .B(_049_),
    .Y(_121_));
 sky130_fd_sc_hd__a21oi_2 _468_ (.A1(\B_reg[2] ),
    .A2(_054_),
    .B1(_121_),
    .Y(_122_));
 sky130_fd_sc_hd__mux2_1 _469_ (.A0(_122_),
    .A1(_047_),
    .S(\B_reg[3] ),
    .X(_123_));
 sky130_fd_sc_hd__nand2_2 _470_ (.A(\A_reg[6] ),
    .B(\B_reg[6] ),
    .Y(_124_));
 sky130_fd_sc_hd__nand2b_2 _471_ (.A_N(_042_),
    .B(_124_),
    .Y(_125_));
 sky130_fd_sc_hd__a2bb2o_2 _472_ (.A1_N(\A_reg[6] ),
    .A2_N(\B_reg[6] ),
    .B1(_006_),
    .B2(_125_),
    .X(_126_));
 sky130_fd_sc_hd__o221a_2 _473_ (.A1(\A_reg[6] ),
    .A2(_011_),
    .B1(_012_),
    .B2(_124_),
    .C1(_126_),
    .X(_127_));
 sky130_fd_sc_hd__o221a_2 _474_ (.A1(_004_),
    .A2(_029_),
    .B1(_123_),
    .B2(_254_),
    .C1(_127_),
    .X(_128_));
 sky130_fd_sc_hd__nand2_2 _475_ (.A(_120_),
    .B(_128_),
    .Y(\result_comb[6] ));
 sky130_fd_sc_hd__mux2_1 _476_ (.A0(_008_),
    .A1(_031_),
    .S(\B_reg[7] ),
    .X(_129_));
 sky130_fd_sc_hd__and2_2 _477_ (.A(\A_reg[7] ),
    .B(_129_),
    .X(_130_));
 sky130_fd_sc_hd__nor2_2 _478_ (.A(_039_),
    .B(_130_),
    .Y(_131_));
 sky130_fd_sc_hd__o21a_2 _479_ (.A1(\A_reg[7] ),
    .A2(_129_),
    .B1(_131_),
    .X(_132_));
 sky130_fd_sc_hd__a21o_2 _480_ (.A1(_118_),
    .A2(_119_),
    .B1(_116_),
    .X(_133_));
 sky130_fd_sc_hd__xnor2_2 _481_ (.A(_132_),
    .B(_133_),
    .Y(_134_));
 sky130_fd_sc_hd__mux2_1 _482_ (.A0(_072_),
    .A1(_073_),
    .S(\B_reg[2] ),
    .X(_135_));
 sky130_fd_sc_hd__inv_2 _483_ (.A(_135_),
    .Y(_136_));
 sky130_fd_sc_hd__mux2_1 _484_ (.A0(_135_),
    .A1(_003_),
    .S(\B_reg[3] ),
    .X(_137_));
 sky130_fd_sc_hd__nand2_2 _485_ (.A(\A_reg[7] ),
    .B(\B_reg[7] ),
    .Y(_138_));
 sky130_fd_sc_hd__nor2_2 _486_ (.A(\B_reg[3] ),
    .B(_294_),
    .Y(_139_));
 sky130_fd_sc_hd__nand2b_2 _487_ (.A_N(_042_),
    .B(_138_),
    .Y(_140_));
 sky130_fd_sc_hd__a2bb2o_2 _488_ (.A1_N(\A_reg[7] ),
    .A2_N(\B_reg[7] ),
    .B1(_006_),
    .B2(_140_),
    .X(_141_));
 sky130_fd_sc_hd__o221a_2 _489_ (.A1(\A_reg[7] ),
    .A2(_011_),
    .B1(_012_),
    .B2(_138_),
    .C1(_141_),
    .X(_142_));
 sky130_fd_sc_hd__o21a_2 _490_ (.A1(_294_),
    .A2(_004_),
    .B1(_142_),
    .X(_143_));
 sky130_fd_sc_hd__o211ai_2 _491_ (.A1(_254_),
    .A2(_137_),
    .B1(_143_),
    .C1(_134_),
    .Y(\result_comb[7] ));
 sky130_fd_sc_hd__mux2_1 _492_ (.A0(_008_),
    .A1(_031_),
    .S(\B_reg[8] ),
    .X(_144_));
 sky130_fd_sc_hd__and2_2 _493_ (.A(\A_reg[8] ),
    .B(_144_),
    .X(_145_));
 sky130_fd_sc_hd__nor2_2 _494_ (.A(_039_),
    .B(_145_),
    .Y(_146_));
 sky130_fd_sc_hd__o21a_2 _495_ (.A1(\A_reg[8] ),
    .A2(_144_),
    .B1(_146_),
    .X(_147_));
 sky130_fd_sc_hd__a21o_2 _496_ (.A1(_132_),
    .A2(_133_),
    .B1(_130_),
    .X(_148_));
 sky130_fd_sc_hd__xor2_2 _497_ (.A(_147_),
    .B(_148_),
    .X(_149_));
 sky130_fd_sc_hd__or2_2 _498_ (.A(\B_reg[3] ),
    .B(_254_),
    .X(_150_));
 sky130_fd_sc_hd__a21oi_2 _499_ (.A1(\A_reg[8] ),
    .A2(\B_reg[8] ),
    .B1(_042_),
    .Y(_151_));
 sky130_fd_sc_hd__o22a_2 _500_ (.A1(\A_reg[8] ),
    .A2(\B_reg[8] ),
    .B1(_005_),
    .B2(_151_),
    .X(_152_));
 sky130_fd_sc_hd__a31o_2 _501_ (.A1(\A_reg[8] ),
    .A2(\B_reg[8] ),
    .A3(_253_),
    .B1(_139_),
    .X(_153_));
 sky130_fd_sc_hd__a2bb2o_2 _502_ (.A1_N(\A_reg[8] ),
    .A2_N(_011_),
    .B1(_153_),
    .B2(_255_),
    .X(_154_));
 sky130_fd_sc_hd__nor2_2 _503_ (.A(_255_),
    .B(_137_),
    .Y(_155_));
 sky130_fd_sc_hd__or4_2 _504_ (.A(_149_),
    .B(_152_),
    .C(_154_),
    .D(_155_),
    .X(\result_comb[8] ));
 sky130_fd_sc_hd__mux2_1 _505_ (.A0(_008_),
    .A1(_031_),
    .S(\B_reg[9] ),
    .X(_156_));
 sky130_fd_sc_hd__and2_2 _506_ (.A(\A_reg[9] ),
    .B(_156_),
    .X(_157_));
 sky130_fd_sc_hd__nor2_2 _507_ (.A(_039_),
    .B(_157_),
    .Y(_158_));
 sky130_fd_sc_hd__o21a_2 _508_ (.A1(\A_reg[9] ),
    .A2(_156_),
    .B1(_158_),
    .X(_159_));
 sky130_fd_sc_hd__a21o_2 _509_ (.A1(_147_),
    .A2(_148_),
    .B1(_145_),
    .X(_160_));
 sky130_fd_sc_hd__xor2_2 _510_ (.A(_159_),
    .B(_160_),
    .X(_161_));
 sky130_fd_sc_hd__nand2_2 _511_ (.A(\A_reg[9] ),
    .B(\B_reg[9] ),
    .Y(_162_));
 sky130_fd_sc_hd__and2b_2 _512_ (.A_N(_042_),
    .B(_162_),
    .X(_163_));
 sky130_fd_sc_hd__o22a_2 _513_ (.A1(\A_reg[9] ),
    .A2(\B_reg[9] ),
    .B1(_005_),
    .B2(_163_),
    .X(_164_));
 sky130_fd_sc_hd__o22a_2 _514_ (.A1(\A_reg[9] ),
    .A2(_011_),
    .B1(_012_),
    .B2(_162_),
    .X(_165_));
 sky130_fd_sc_hd__o21a_2 _515_ (.A1(_029_),
    .A2(_150_),
    .B1(_165_),
    .X(_166_));
 sky130_fd_sc_hd__nor2_2 _516_ (.A(_255_),
    .B(_123_),
    .Y(_167_));
 sky130_fd_sc_hd__or4b_2 _517_ (.A(_161_),
    .B(_164_),
    .C(_167_),
    .D_N(_166_),
    .X(\result_comb[9] ));
 sky130_fd_sc_hd__mux2_1 _518_ (.A0(_008_),
    .A1(_031_),
    .S(\B_reg[10] ),
    .X(_168_));
 sky130_fd_sc_hd__and2_2 _519_ (.A(\A_reg[10] ),
    .B(_168_),
    .X(_169_));
 sky130_fd_sc_hd__nor2_2 _520_ (.A(_039_),
    .B(_169_),
    .Y(_170_));
 sky130_fd_sc_hd__o21a_2 _521_ (.A1(\A_reg[10] ),
    .A2(_168_),
    .B1(_170_),
    .X(_171_));
 sky130_fd_sc_hd__a21o_2 _522_ (.A1(_159_),
    .A2(_160_),
    .B1(_157_),
    .X(_172_));
 sky130_fd_sc_hd__xnor2_2 _523_ (.A(_171_),
    .B(_172_),
    .Y(_173_));
 sky130_fd_sc_hd__nand2_2 _524_ (.A(\A_reg[10] ),
    .B(\B_reg[10] ),
    .Y(_174_));
 sky130_fd_sc_hd__nand2b_2 _525_ (.A_N(_042_),
    .B(_174_),
    .Y(_175_));
 sky130_fd_sc_hd__a2bb2o_2 _526_ (.A1_N(\A_reg[10] ),
    .A2_N(\B_reg[10] ),
    .B1(_006_),
    .B2(_175_),
    .X(_176_));
 sky130_fd_sc_hd__o221a_2 _527_ (.A1(\A_reg[10] ),
    .A2(_011_),
    .B1(_012_),
    .B2(_174_),
    .C1(_176_),
    .X(_177_));
 sky130_fd_sc_hd__o221a_2 _528_ (.A1(_255_),
    .A2(_109_),
    .B1(_150_),
    .B2(_056_),
    .C1(_177_),
    .X(_178_));
 sky130_fd_sc_hd__nand2_2 _529_ (.A(_173_),
    .B(_178_),
    .Y(\result_comb[10] ));
 sky130_fd_sc_hd__mux2_1 _530_ (.A0(_008_),
    .A1(_031_),
    .S(\B_reg[11] ),
    .X(_179_));
 sky130_fd_sc_hd__and2_2 _531_ (.A(\A_reg[11] ),
    .B(_179_),
    .X(_180_));
 sky130_fd_sc_hd__nor2_2 _532_ (.A(_039_),
    .B(_180_),
    .Y(_181_));
 sky130_fd_sc_hd__o21a_2 _533_ (.A1(\A_reg[11] ),
    .A2(_179_),
    .B1(_181_),
    .X(_182_));
 sky130_fd_sc_hd__a21o_2 _534_ (.A1(_171_),
    .A2(_172_),
    .B1(_169_),
    .X(_183_));
 sky130_fd_sc_hd__xnor2_2 _535_ (.A(_182_),
    .B(_183_),
    .Y(_184_));
 sky130_fd_sc_hd__nand2_2 _536_ (.A(\A_reg[11] ),
    .B(\B_reg[11] ),
    .Y(_185_));
 sky130_fd_sc_hd__nand2b_2 _537_ (.A_N(_042_),
    .B(_185_),
    .Y(_186_));
 sky130_fd_sc_hd__a2bb2o_2 _538_ (.A1_N(\A_reg[11] ),
    .A2_N(\B_reg[11] ),
    .B1(_006_),
    .B2(_186_),
    .X(_187_));
 sky130_fd_sc_hd__o221a_2 _539_ (.A1(\A_reg[11] ),
    .A2(_011_),
    .B1(_012_),
    .B2(_185_),
    .C1(_187_),
    .X(_188_));
 sky130_fd_sc_hd__o221a_2 _540_ (.A1(_255_),
    .A2(_095_),
    .B1(_150_),
    .B2(_074_),
    .C1(_188_),
    .X(_189_));
 sky130_fd_sc_hd__nand2_2 _541_ (.A(_184_),
    .B(_189_),
    .Y(\result_comb[11] ));
 sky130_fd_sc_hd__mux2_1 _542_ (.A0(_008_),
    .A1(_031_),
    .S(\B_reg[12] ),
    .X(_190_));
 sky130_fd_sc_hd__and2_2 _543_ (.A(\A_reg[12] ),
    .B(_190_),
    .X(_191_));
 sky130_fd_sc_hd__nor2_2 _544_ (.A(_039_),
    .B(_191_),
    .Y(_192_));
 sky130_fd_sc_hd__o21a_2 _545_ (.A1(\A_reg[12] ),
    .A2(_190_),
    .B1(_192_),
    .X(_193_));
 sky130_fd_sc_hd__a21o_2 _546_ (.A1(_182_),
    .A2(_183_),
    .B1(_180_),
    .X(_194_));
 sky130_fd_sc_hd__xnor2_2 _547_ (.A(_193_),
    .B(_194_),
    .Y(_195_));
 sky130_fd_sc_hd__nand2_2 _548_ (.A(\A_reg[12] ),
    .B(\B_reg[12] ),
    .Y(_196_));
 sky130_fd_sc_hd__nand2b_2 _549_ (.A_N(_042_),
    .B(_196_),
    .Y(_197_));
 sky130_fd_sc_hd__a2bb2o_2 _550_ (.A1_N(\A_reg[12] ),
    .A2_N(\B_reg[12] ),
    .B1(_006_),
    .B2(_197_),
    .X(_198_));
 sky130_fd_sc_hd__o221a_2 _551_ (.A1(\A_reg[12] ),
    .A2(_011_),
    .B1(_012_),
    .B2(_196_),
    .C1(_198_),
    .X(_199_));
 sky130_fd_sc_hd__o221a_2 _552_ (.A1(_255_),
    .A2(_075_),
    .B1(_081_),
    .B2(_150_),
    .C1(_199_),
    .X(_200_));
 sky130_fd_sc_hd__nand2_2 _553_ (.A(_195_),
    .B(_200_),
    .Y(\result_comb[12] ));
 sky130_fd_sc_hd__mux2_1 _554_ (.A0(_008_),
    .A1(_031_),
    .S(\B_reg[13] ),
    .X(_201_));
 sky130_fd_sc_hd__and2_2 _555_ (.A(\A_reg[13] ),
    .B(_201_),
    .X(_202_));
 sky130_fd_sc_hd__nor2_2 _556_ (.A(_039_),
    .B(_202_),
    .Y(_203_));
 sky130_fd_sc_hd__o21a_2 _557_ (.A1(\A_reg[13] ),
    .A2(_201_),
    .B1(_203_),
    .X(_204_));
 sky130_fd_sc_hd__a21o_2 _558_ (.A1(_193_),
    .A2(_194_),
    .B1(_191_),
    .X(_205_));
 sky130_fd_sc_hd__xnor2_2 _559_ (.A(_204_),
    .B(_205_),
    .Y(_206_));
 sky130_fd_sc_hd__nand2_2 _560_ (.A(\A_reg[13] ),
    .B(\B_reg[13] ),
    .Y(_207_));
 sky130_fd_sc_hd__nand2b_2 _561_ (.A_N(_042_),
    .B(_207_),
    .Y(_208_));
 sky130_fd_sc_hd__a2bb2o_2 _562_ (.A1_N(\A_reg[13] ),
    .A2_N(\B_reg[13] ),
    .B1(_006_),
    .B2(_208_),
    .X(_209_));
 sky130_fd_sc_hd__o221a_2 _563_ (.A1(\A_reg[13] ),
    .A2(_011_),
    .B1(_012_),
    .B2(_207_),
    .C1(_209_),
    .X(_210_));
 sky130_fd_sc_hd__o21a_2 _564_ (.A1(_069_),
    .A2(_150_),
    .B1(_210_),
    .X(_211_));
 sky130_fd_sc_hd__o211ai_2 _565_ (.A1(_255_),
    .A2(_057_),
    .B1(_206_),
    .C1(_211_),
    .Y(\result_comb[13] ));
 sky130_fd_sc_hd__mux2_1 _566_ (.A0(_008_),
    .A1(_031_),
    .S(\B_reg[14] ),
    .X(_212_));
 sky130_fd_sc_hd__nor2_2 _567_ (.A(\A_reg[14] ),
    .B(_212_),
    .Y(_213_));
 sky130_fd_sc_hd__nand2_2 _568_ (.A(\A_reg[14] ),
    .B(_212_),
    .Y(_214_));
 sky130_fd_sc_hd__or3b_2 _569_ (.A(_039_),
    .B(_213_),
    .C_N(_214_),
    .X(_215_));
 sky130_fd_sc_hd__a21oi_2 _570_ (.A1(_204_),
    .A2(_205_),
    .B1(_202_),
    .Y(_216_));
 sky130_fd_sc_hd__xnor2_2 _571_ (.A(_215_),
    .B(_216_),
    .Y(_217_));
 sky130_fd_sc_hd__nand2_2 _572_ (.A(\A_reg[14] ),
    .B(\B_reg[14] ),
    .Y(_218_));
 sky130_fd_sc_hd__nand2b_2 _573_ (.A_N(_042_),
    .B(_218_),
    .Y(_219_));
 sky130_fd_sc_hd__a2bb2o_2 _574_ (.A1_N(\A_reg[14] ),
    .A2_N(\B_reg[14] ),
    .B1(_006_),
    .B2(_219_),
    .X(_220_));
 sky130_fd_sc_hd__o221a_2 _575_ (.A1(\A_reg[14] ),
    .A2(_011_),
    .B1(_012_),
    .B2(_218_),
    .C1(_220_),
    .X(_221_));
 sky130_fd_sc_hd__nand2_2 _576_ (.A(_254_),
    .B(_030_),
    .Y(_222_));
 sky130_fd_sc_hd__o211a_2 _577_ (.A1(_047_),
    .A2(_150_),
    .B1(_221_),
    .C1(_222_),
    .X(_223_));
 sky130_fd_sc_hd__nand2_2 _578_ (.A(_217_),
    .B(_223_),
    .Y(\result_comb[14] ));
 sky130_fd_sc_hd__mux2_1 _579_ (.A0(_008_),
    .A1(_031_),
    .S(\B_reg[15] ),
    .X(_224_));
 sky130_fd_sc_hd__inv_2 _580_ (.A(_224_),
    .Y(_225_));
 sky130_fd_sc_hd__a21o_2 _581_ (.A1(\A_reg[15] ),
    .A2(_224_),
    .B1(_039_),
    .X(_226_));
 sky130_fd_sc_hd__a21o_2 _582_ (.A1(_252_),
    .A2(_225_),
    .B1(_226_),
    .X(_227_));
 sky130_fd_sc_hd__inv_2 _583_ (.A(_227_),
    .Y(_228_));
 sky130_fd_sc_hd__o21ai_2 _584_ (.A1(_215_),
    .A2(_216_),
    .B1(_214_),
    .Y(_229_));
 sky130_fd_sc_hd__o211a_2 _585_ (.A1(_215_),
    .A2(_216_),
    .B1(_227_),
    .C1(_214_),
    .X(_230_));
 sky130_fd_sc_hd__xnor2_2 _586_ (.A(_227_),
    .B(_229_),
    .Y(_231_));
 sky130_fd_sc_hd__xnor2_2 _587_ (.A(_228_),
    .B(_229_),
    .Y(_232_));
 sky130_fd_sc_hd__or2_2 _588_ (.A(\A_reg[15] ),
    .B(\B_reg[15] ),
    .X(_233_));
 sky130_fd_sc_hd__nand2_2 _589_ (.A(\A_reg[15] ),
    .B(\B_reg[15] ),
    .Y(_234_));
 sky130_fd_sc_hd__nand2_2 _590_ (.A(_233_),
    .B(_234_),
    .Y(_235_));
 sky130_fd_sc_hd__o2bb2a_2 _591_ (.A1_N(_005_),
    .A2_N(_233_),
    .B1(_235_),
    .B2(_042_),
    .X(_236_));
 sky130_fd_sc_hd__o221a_2 _592_ (.A1(\A_reg[15] ),
    .A2(_011_),
    .B1(_150_),
    .B2(_003_),
    .C1(_236_),
    .X(_237_));
 sky130_fd_sc_hd__o21a_2 _593_ (.A1(_012_),
    .A2(_234_),
    .B1(_237_),
    .X(_238_));
 sky130_fd_sc_hd__nand2_2 _594_ (.A(_254_),
    .B(_295_),
    .Y(_239_));
 sky130_fd_sc_hd__nand3_2 _595_ (.A(_232_),
    .B(_238_),
    .C(_239_),
    .Y(\result_comb[15] ));
 sky130_fd_sc_hd__or4_2 _596_ (.A(\result_comb[0] ),
    .B(\result_comb[1] ),
    .C(\result_comb[2] ),
    .D(\result_comb[3] ),
    .X(_240_));
 sky130_fd_sc_hd__or4_2 _597_ (.A(\result_comb[4] ),
    .B(\result_comb[5] ),
    .C(\result_comb[6] ),
    .D(_240_),
    .X(_241_));
 sky130_fd_sc_hd__or4_2 _598_ (.A(\result_comb[7] ),
    .B(\result_comb[8] ),
    .C(\result_comb[9] ),
    .D(_241_),
    .X(_242_));
 sky130_fd_sc_hd__or4_2 _599_ (.A(\result_comb[10] ),
    .B(\result_comb[11] ),
    .C(\result_comb[12] ),
    .D(_242_),
    .X(_243_));
 sky130_fd_sc_hd__and4bb_2 _600_ (.A_N(\result_comb[13] ),
    .B_N(_243_),
    .C(_217_),
    .D(_223_),
    .X(_244_));
 sky130_fd_sc_hd__and4_2 _601_ (.A(_232_),
    .B(_238_),
    .C(_239_),
    .D(_244_),
    .X(_000_));
 sky130_fd_sc_hd__and3b_2 _602_ (.A_N(\B_reg[1] ),
    .B(_274_),
    .C(\B_reg[0] ),
    .X(_245_));
 sky130_fd_sc_hd__a211oi_2 _603_ (.A1(\B_reg[1] ),
    .A2(_020_),
    .B1(_245_),
    .C1(\B_reg[2] ),
    .Y(_246_));
 sky130_fd_sc_hd__a211oi_2 _604_ (.A1(\B_reg[2] ),
    .A2(_071_),
    .B1(_246_),
    .C1(\B_reg[3] ),
    .Y(_247_));
 sky130_fd_sc_hd__a221o_2 _605_ (.A1(\B_reg[3] ),
    .A2(_136_),
    .B1(_224_),
    .B2(\A_reg[15] ),
    .C1(_247_),
    .X(_248_));
 sky130_fd_sc_hd__a21o_2 _606_ (.A1(_228_),
    .A2(_229_),
    .B1(_248_),
    .X(carry_comb));
 sky130_fd_sc_hd__a311o_2 _607_ (.A1(_040_),
    .A2(_225_),
    .A3(_229_),
    .B1(_230_),
    .C1(_252_),
    .X(_249_));
 sky130_fd_sc_hd__mux2_1 _608_ (.A0(_008_),
    .A1(_031_),
    .S(_235_),
    .X(_250_));
 sky130_fd_sc_hd__o211a_2 _609_ (.A1(\A_reg[15] ),
    .A2(_231_),
    .B1(_249_),
    .C1(_250_),
    .X(overflow_comb));
 sky130_fd_sc_hd__dfxtp_2 _610_ (.CLK(clk),
    .D(\result_comb[15] ),
    .Q(N));
 sky130_fd_sc_hd__dfxtp_2 _611_ (.CLK(clk),
    .D(overflow_comb),
    .Q(V));
 sky130_fd_sc_hd__dfxtp_2 _612_ (.CLK(clk),
    .D(\result_comb[0] ),
    .Q(Y[0]));
 sky130_fd_sc_hd__dfxtp_2 _613_ (.CLK(clk),
    .D(\result_comb[1] ),
    .Q(Y[1]));
 sky130_fd_sc_hd__dfxtp_2 _614_ (.CLK(clk),
    .D(\result_comb[2] ),
    .Q(Y[2]));
 sky130_fd_sc_hd__dfxtp_2 _615_ (.CLK(clk),
    .D(\result_comb[3] ),
    .Q(Y[3]));
 sky130_fd_sc_hd__dfxtp_2 _616_ (.CLK(clk),
    .D(\result_comb[4] ),
    .Q(Y[4]));
 sky130_fd_sc_hd__dfxtp_2 _617_ (.CLK(clk),
    .D(\result_comb[5] ),
    .Q(Y[5]));
 sky130_fd_sc_hd__dfxtp_2 _618_ (.CLK(clk),
    .D(\result_comb[6] ),
    .Q(Y[6]));
 sky130_fd_sc_hd__dfxtp_2 _619_ (.CLK(clk),
    .D(\result_comb[7] ),
    .Q(Y[7]));
 sky130_fd_sc_hd__dfxtp_2 _620_ (.CLK(clk),
    .D(\result_comb[8] ),
    .Q(Y[8]));
 sky130_fd_sc_hd__dfxtp_2 _621_ (.CLK(clk),
    .D(\result_comb[9] ),
    .Q(Y[9]));
 sky130_fd_sc_hd__dfxtp_2 _622_ (.CLK(clk),
    .D(\result_comb[10] ),
    .Q(Y[10]));
 sky130_fd_sc_hd__dfxtp_2 _623_ (.CLK(clk),
    .D(\result_comb[11] ),
    .Q(Y[11]));
 sky130_fd_sc_hd__dfxtp_2 _624_ (.CLK(clk),
    .D(\result_comb[12] ),
    .Q(Y[12]));
 sky130_fd_sc_hd__dfxtp_2 _625_ (.CLK(clk),
    .D(\result_comb[13] ),
    .Q(Y[13]));
 sky130_fd_sc_hd__dfxtp_2 _626_ (.CLK(clk),
    .D(\result_comb[14] ),
    .Q(Y[14]));
 sky130_fd_sc_hd__dfxtp_2 _627_ (.CLK(clk),
    .D(_000_),
    .Q(Z));
 sky130_fd_sc_hd__dfxtp_2 _628_ (.CLK(clk),
    .D(A[0]),
    .Q(\A_reg[0] ));
 sky130_fd_sc_hd__dfxtp_2 _629_ (.CLK(clk),
    .D(A[1]),
    .Q(\A_reg[1] ));
 sky130_fd_sc_hd__dfxtp_2 _630_ (.CLK(clk),
    .D(A[2]),
    .Q(\A_reg[2] ));
 sky130_fd_sc_hd__dfxtp_2 _631_ (.CLK(clk),
    .D(A[3]),
    .Q(\A_reg[3] ));
 sky130_fd_sc_hd__dfxtp_2 _632_ (.CLK(clk),
    .D(A[4]),
    .Q(\A_reg[4] ));
 sky130_fd_sc_hd__dfxtp_2 _633_ (.CLK(clk),
    .D(A[5]),
    .Q(\A_reg[5] ));
 sky130_fd_sc_hd__dfxtp_2 _634_ (.CLK(clk),
    .D(A[6]),
    .Q(\A_reg[6] ));
 sky130_fd_sc_hd__dfxtp_2 _635_ (.CLK(clk),
    .D(A[7]),
    .Q(\A_reg[7] ));
 sky130_fd_sc_hd__dfxtp_2 _636_ (.CLK(clk),
    .D(A[8]),
    .Q(\A_reg[8] ));
 sky130_fd_sc_hd__dfxtp_2 _637_ (.CLK(clk),
    .D(A[9]),
    .Q(\A_reg[9] ));
 sky130_fd_sc_hd__dfxtp_2 _638_ (.CLK(clk),
    .D(A[10]),
    .Q(\A_reg[10] ));
 sky130_fd_sc_hd__dfxtp_2 _639_ (.CLK(clk),
    .D(A[11]),
    .Q(\A_reg[11] ));
 sky130_fd_sc_hd__dfxtp_2 _640_ (.CLK(clk),
    .D(A[12]),
    .Q(\A_reg[12] ));
 sky130_fd_sc_hd__dfxtp_2 _641_ (.CLK(clk),
    .D(A[13]),
    .Q(\A_reg[13] ));
 sky130_fd_sc_hd__dfxtp_2 _642_ (.CLK(clk),
    .D(A[14]),
    .Q(\A_reg[14] ));
 sky130_fd_sc_hd__dfxtp_2 _643_ (.CLK(clk),
    .D(A[15]),
    .Q(\A_reg[15] ));
 sky130_fd_sc_hd__dfxtp_2 _644_ (.CLK(clk),
    .D(B[0]),
    .Q(\B_reg[0] ));
 sky130_fd_sc_hd__dfxtp_2 _645_ (.CLK(clk),
    .D(B[1]),
    .Q(\B_reg[1] ));
 sky130_fd_sc_hd__dfxtp_2 _646_ (.CLK(clk),
    .D(B[2]),
    .Q(\B_reg[2] ));
 sky130_fd_sc_hd__dfxtp_2 _647_ (.CLK(clk),
    .D(B[3]),
    .Q(\B_reg[3] ));
 sky130_fd_sc_hd__dfxtp_2 _648_ (.CLK(clk),
    .D(B[4]),
    .Q(\B_reg[4] ));
 sky130_fd_sc_hd__dfxtp_2 _649_ (.CLK(clk),
    .D(B[5]),
    .Q(\B_reg[5] ));
 sky130_fd_sc_hd__dfxtp_2 _650_ (.CLK(clk),
    .D(B[6]),
    .Q(\B_reg[6] ));
 sky130_fd_sc_hd__dfxtp_2 _651_ (.CLK(clk),
    .D(B[7]),
    .Q(\B_reg[7] ));
 sky130_fd_sc_hd__dfxtp_2 _652_ (.CLK(clk),
    .D(B[8]),
    .Q(\B_reg[8] ));
 sky130_fd_sc_hd__dfxtp_2 _653_ (.CLK(clk),
    .D(B[9]),
    .Q(\B_reg[9] ));
 sky130_fd_sc_hd__dfxtp_2 _654_ (.CLK(clk),
    .D(B[10]),
    .Q(\B_reg[10] ));
 sky130_fd_sc_hd__dfxtp_2 _655_ (.CLK(clk),
    .D(B[11]),
    .Q(\B_reg[11] ));
 sky130_fd_sc_hd__dfxtp_2 _656_ (.CLK(clk),
    .D(B[12]),
    .Q(\B_reg[12] ));
 sky130_fd_sc_hd__dfxtp_2 _657_ (.CLK(clk),
    .D(B[13]),
    .Q(\B_reg[13] ));
 sky130_fd_sc_hd__dfxtp_2 _658_ (.CLK(clk),
    .D(B[14]),
    .Q(\B_reg[14] ));
 sky130_fd_sc_hd__dfxtp_2 _659_ (.CLK(clk),
    .D(B[15]),
    .Q(\B_reg[15] ));
 sky130_fd_sc_hd__dfxtp_2 _660_ (.CLK(clk),
    .D(opcode[0]),
    .Q(\opcode_reg[0] ));
 sky130_fd_sc_hd__dfxtp_2 _661_ (.CLK(clk),
    .D(opcode[1]),
    .Q(\opcode_reg[1] ));
 sky130_fd_sc_hd__dfxtp_2 _662_ (.CLK(clk),
    .D(opcode[2]),
    .Q(\opcode_reg[2] ));
 sky130_fd_sc_hd__dfxtp_2 _663_ (.CLK(clk),
    .D(carry_comb),
    .Q(C));
 sky130_fd_sc_hd__buf_2 _664_ (.A(N),
    .X(Y[15]));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_0_Right_0 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_1_Right_1 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_2_Right_2 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_3_Right_3 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_4_Right_4 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_5_Right_5 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_6_Right_6 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_7_Right_7 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_8_Right_8 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_9_Right_9 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_10_Right_10 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_11_Right_11 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_12_Right_12 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_13_Right_13 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_14_Right_14 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_15_Right_15 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_16_Right_16 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_17_Right_17 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_18_Right_18 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_19_Right_19 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_20_Right_20 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_21_Right_21 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_22_Right_22 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_23_Right_23 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_24_Right_24 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_25_Right_25 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_Right_26 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_Right_27 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_Right_28 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_Right_29 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_Right_30 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_31_Right_31 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_32_Right_32 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_33_Right_33 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_34_Right_34 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_35_Right_35 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_36_Right_36 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_37_Right_37 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_38_Right_38 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_0_Left_39 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_1_Left_40 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_2_Left_41 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_3_Left_42 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_4_Left_43 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_5_Left_44 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_6_Left_45 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_7_Left_46 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_8_Left_47 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_9_Left_48 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_10_Left_49 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_11_Left_50 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_12_Left_51 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_13_Left_52 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_14_Left_53 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_15_Left_54 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_16_Left_55 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_17_Left_56 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_18_Left_57 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_19_Left_58 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_20_Left_59 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_21_Left_60 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_22_Left_61 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_23_Left_62 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_24_Left_63 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_25_Left_64 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_Left_65 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_Left_66 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_Left_67 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_Left_68 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_Left_69 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_31_Left_70 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_32_Left_71 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_33_Left_72 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_34_Left_73 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_35_Left_74 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_36_Left_75 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_37_Left_76 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_38_Left_77 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_78 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_79 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_80 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_81 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_82 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_83 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_84 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_85 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_86 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_87 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_88 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_89 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_90 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_91 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_92 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_93 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_94 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_95 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_96 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_97 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_98 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_99 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_100 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_101 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_102 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_103 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_104 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_105 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_106 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_107 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_108 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_109 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_110 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_111 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_112 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_113 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_114 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_115 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_116 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_117 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_118 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_119 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_120 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_121 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_122 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_123 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_124 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_125 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_126 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_127 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_128 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_129 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_130 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_131 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_132 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_133 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_134 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_135 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_136 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_137 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_138 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_139 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_140 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_141 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_142 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_143 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_144 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_145 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_146 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_147 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_148 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_149 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_150 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_151 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_152 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_153 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_154 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_155 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_156 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_157 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_158 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_159 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_160 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_161 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_162 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_163 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_164 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_165 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_166 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_167 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_168 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_169 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_170 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_171 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_172 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_173 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_174 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_175 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_176 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_177 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_178 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_179 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_180 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_181 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_182 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_183 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_184 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_185 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_186 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_187 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_188 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_189 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_190 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_191 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_192 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_193 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_194 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_195 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_196 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_197 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_198 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_199 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_200 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_201 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_202 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_203 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_204 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_205 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_206 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_207 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_208 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_209 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_210 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_211 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_212 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_213 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_214 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_215 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_216 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_217 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_218 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_219 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_220 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_221 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_222 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_223 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_224 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_225 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_226 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_227 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_228 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_229 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_230 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_231 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_232 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_233 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_234 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_235 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_236 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_237 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_238 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_239 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_240 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_241 ();
endmodule
