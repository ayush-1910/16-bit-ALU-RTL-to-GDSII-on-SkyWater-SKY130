module alu16 (C,
    N,
    V,
    Z,
    clk,
    A,
    B,
    Y,
    opcode);
 output C;
 output N;
 output V;
 output Z;
 input clk;
 input [15:0] A;
 input [15:0] B;
 output [15:0] Y;
 input [2:0] opcode;

 wire \A_reg[0] ;
 wire \A_reg[10] ;
 wire \A_reg[11] ;
 wire \A_reg[12] ;
 wire \A_reg[13] ;
 wire \A_reg[14] ;
 wire \A_reg[15] ;
 wire \A_reg[1] ;
 wire \A_reg[2] ;
 wire \A_reg[3] ;
 wire \A_reg[4] ;
 wire \A_reg[5] ;
 wire \A_reg[6] ;
 wire \A_reg[7] ;
 wire \A_reg[8] ;
 wire \A_reg[9] ;
 wire \B_reg[0] ;
 wire \B_reg[10] ;
 wire \B_reg[11] ;
 wire \B_reg[12] ;
 wire \B_reg[13] ;
 wire \B_reg[14] ;
 wire \B_reg[15] ;
 wire \B_reg[1] ;
 wire \B_reg[2] ;
 wire \B_reg[3] ;
 wire \B_reg[4] ;
 wire \B_reg[5] ;
 wire \B_reg[6] ;
 wire \B_reg[7] ;
 wire \B_reg[8] ;
 wire \B_reg[9] ;
 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _070_;
 wire _071_;
 wire _072_;
 wire _073_;
 wire _074_;
 wire _075_;
 wire _076_;
 wire _077_;
 wire _078_;
 wire _079_;
 wire _080_;
 wire _081_;
 wire _082_;
 wire _083_;
 wire _084_;
 wire _085_;
 wire _086_;
 wire _087_;
 wire _088_;
 wire _089_;
 wire _090_;
 wire _091_;
 wire _092_;
 wire _093_;
 wire _094_;
 wire _095_;
 wire _096_;
 wire _097_;
 wire _098_;
 wire _099_;
 wire _100_;
 wire _101_;
 wire _102_;
 wire _103_;
 wire _104_;
 wire _105_;
 wire _106_;
 wire _107_;
 wire _108_;
 wire _109_;
 wire _110_;
 wire _111_;
 wire _112_;
 wire _113_;
 wire _114_;
 wire _115_;
 wire _116_;
 wire _117_;
 wire _118_;
 wire _119_;
 wire _120_;
 wire _121_;
 wire _122_;
 wire _123_;
 wire _124_;
 wire _125_;
 wire _126_;
 wire _127_;
 wire _128_;
 wire _129_;
 wire _130_;
 wire _131_;
 wire _132_;
 wire _133_;
 wire _134_;
 wire _135_;
 wire _136_;
 wire _137_;
 wire _138_;
 wire _139_;
 wire _140_;
 wire _141_;
 wire _142_;
 wire _143_;
 wire _144_;
 wire _145_;
 wire _146_;
 wire _147_;
 wire _148_;
 wire _149_;
 wire _150_;
 wire _151_;
 wire _152_;
 wire _153_;
 wire _154_;
 wire _155_;
 wire _156_;
 wire _157_;
 wire _158_;
 wire _159_;
 wire _160_;
 wire _161_;
 wire _162_;
 wire _163_;
 wire _164_;
 wire _165_;
 wire _166_;
 wire _167_;
 wire _168_;
 wire _169_;
 wire _170_;
 wire _171_;
 wire _172_;
 wire _173_;
 wire _174_;
 wire _175_;
 wire _176_;
 wire _177_;
 wire _178_;
 wire _179_;
 wire _180_;
 wire _181_;
 wire _182_;
 wire _183_;
 wire _184_;
 wire _185_;
 wire _186_;
 wire _187_;
 wire _188_;
 wire _189_;
 wire _190_;
 wire _191_;
 wire _192_;
 wire _193_;
 wire _194_;
 wire _195_;
 wire _196_;
 wire _197_;
 wire _198_;
 wire _199_;
 wire _200_;
 wire _201_;
 wire _202_;
 wire _203_;
 wire _204_;
 wire _205_;
 wire _206_;
 wire _207_;
 wire _208_;
 wire _209_;
 wire _210_;
 wire _211_;
 wire _212_;
 wire _213_;
 wire _214_;
 wire _215_;
 wire _216_;
 wire _217_;
 wire _218_;
 wire _219_;
 wire _220_;
 wire _221_;
 wire _222_;
 wire _223_;
 wire _224_;
 wire _225_;
 wire _226_;
 wire _227_;
 wire _228_;
 wire _229_;
 wire _230_;
 wire _231_;
 wire _232_;
 wire _233_;
 wire _234_;
 wire _235_;
 wire _236_;
 wire _237_;
 wire _238_;
 wire _239_;
 wire _240_;
 wire _241_;
 wire _242_;
 wire _243_;
 wire _244_;
 wire _245_;
 wire _246_;
 wire _247_;
 wire _248_;
 wire _249_;
 wire _250_;
 wire _251_;
 wire _252_;
 wire _253_;
 wire _254_;
 wire _255_;
 wire _256_;
 wire _257_;
 wire _258_;
 wire _259_;
 wire _260_;
 wire _261_;
 wire _262_;
 wire _263_;
 wire _264_;
 wire _265_;
 wire _266_;
 wire _267_;
 wire _268_;
 wire _269_;
 wire _270_;
 wire _271_;
 wire _272_;
 wire _273_;
 wire _274_;
 wire _275_;
 wire _276_;
 wire _277_;
 wire _278_;
 wire _279_;
 wire _280_;
 wire _281_;
 wire _282_;
 wire _283_;
 wire _284_;
 wire _285_;
 wire _286_;
 wire _287_;
 wire _288_;
 wire _289_;
 wire _290_;
 wire _291_;
 wire _292_;
 wire _293_;
 wire _294_;
 wire _295_;
 wire _296_;
 wire _297_;
 wire _298_;
 wire _299_;
 wire carry_comb;
 wire is_sub;
 wire op_add;
 wire op_and;
 wire op_not;
 wire op_or;
 wire op_sll;
 wire op_srl;
 wire op_xor;
 wire overflow_comb;
 wire \result_comb[0] ;
 wire \result_comb[10] ;
 wire \result_comb[11] ;
 wire \result_comb[12] ;
 wire \result_comb[13] ;
 wire \result_comb[14] ;
 wire \result_comb[15] ;
 wire \result_comb[1] ;
 wire \result_comb[2] ;
 wire \result_comb[3] ;
 wire \result_comb[4] ;
 wire \result_comb[5] ;
 wire \result_comb[6] ;
 wire \result_comb[7] ;
 wire \result_comb[8] ;
 wire \result_comb[9] ;
 wire net1;
 wire net2;
 wire net3;
 wire net4;
 wire net5;
 wire net6;
 wire net7;
 wire net8;
 wire net9;
 wire net10;
 wire net11;
 wire net12;
 wire net13;
 wire net14;
 wire net15;
 wire net16;
 wire net17;
 wire net18;
 wire net19;
 wire net20;
 wire net21;
 wire net22;
 wire net23;
 wire net24;
 wire net25;
 wire net26;
 wire net27;
 wire net28;
 wire net29;
 wire net30;
 wire net31;
 wire net32;
 wire net33;
 wire net34;
 wire net35;
 wire net36;
 wire net37;
 wire net38;
 wire net39;
 wire net40;
 wire net41;
 wire net42;
 wire net43;
 wire net44;
 wire net45;
 wire net46;
 wire net47;
 wire net48;
 wire net49;
 wire net50;
 wire net51;
 wire net52;
 wire net53;
 wire net54;
 wire net55;
 wire net56;
 wire net57;
 wire net58;
 wire net59;
 wire net60;
 wire net61;
 wire net62;
 wire net63;
 wire net64;
 wire net65;
 wire net66;
 wire net67;
 wire net68;
 wire net69;
 wire net70;
 wire net71;
 wire net72;
 wire net73;
 wire net74;
 wire net75;
 wire net76;
 wire net77;
 wire net78;
 wire net79;
 wire net80;
 wire net81;
 wire net82;
 wire net83;
 wire net84;
 wire net85;
 wire clknet_0_clk;
 wire clknet_3_0__leaf_clk;
 wire clknet_3_1__leaf_clk;
 wire clknet_3_2__leaf_clk;
 wire clknet_3_3__leaf_clk;
 wire clknet_3_4__leaf_clk;
 wire clknet_3_5__leaf_clk;
 wire clknet_3_6__leaf_clk;
 wire clknet_3_7__leaf_clk;
 wire net86;

 sky130_fd_sc_hd__inv_2 _300_ (.A(net71),
    .Y(_271_));
 sky130_fd_sc_hd__inv_2 _301_ (.A(op_not),
    .Y(_272_));
 sky130_fd_sc_hd__inv_2 _302_ (.A(net64),
    .Y(_273_));
 sky130_fd_sc_hd__inv_2 _303_ (.A(\A_reg[15] ),
    .Y(_274_));
 sky130_fd_sc_hd__inv_2 _304_ (.A(\A_reg[1] ),
    .Y(_275_));
 sky130_fd_sc_hd__or2_1 _305_ (.A(op_srl),
    .B(net66),
    .X(_276_));
 sky130_fd_sc_hd__or2_1 _306_ (.A(net64),
    .B(\A_reg[4] ),
    .X(_277_));
 sky130_fd_sc_hd__o211a_1 _307_ (.A1(net61),
    .A2(\A_reg[11] ),
    .B1(net59),
    .C1(_277_),
    .X(_278_));
 sky130_fd_sc_hd__or2_1 _308_ (.A(net64),
    .B(\A_reg[5] ),
    .X(_279_));
 sky130_fd_sc_hd__o211a_1 _309_ (.A1(net61),
    .A2(\A_reg[10] ),
    .B1(net59),
    .C1(_279_),
    .X(_280_));
 sky130_fd_sc_hd__mux2_1 _310_ (.A0(_278_),
    .A1(_280_),
    .S(net83),
    .X(_281_));
 sky130_fd_sc_hd__inv_2 _311_ (.A(_281_),
    .Y(_282_));
 sky130_fd_sc_hd__or2_1 _312_ (.A(net65),
    .B(\A_reg[6] ),
    .X(_283_));
 sky130_fd_sc_hd__o211a_1 _313_ (.A1(net62),
    .A2(\A_reg[9] ),
    .B1(net59),
    .C1(_283_),
    .X(_284_));
 sky130_fd_sc_hd__or2_1 _314_ (.A(net65),
    .B(\A_reg[7] ),
    .X(_285_));
 sky130_fd_sc_hd__o211a_1 _315_ (.A1(net62),
    .A2(\A_reg[8] ),
    .B1(net59),
    .C1(_285_),
    .X(_286_));
 sky130_fd_sc_hd__mux2_1 _316_ (.A0(_284_),
    .A1(_286_),
    .S(net83),
    .X(_287_));
 sky130_fd_sc_hd__inv_2 _317_ (.A(_287_),
    .Y(_288_));
 sky130_fd_sc_hd__mux2_1 _318_ (.A0(_281_),
    .A1(_287_),
    .S(net80),
    .X(_289_));
 sky130_fd_sc_hd__and2_1 _319_ (.A(net78),
    .B(_289_),
    .X(_290_));
 sky130_fd_sc_hd__mux2_1 _320_ (.A0(\A_reg[2] ),
    .A1(\A_reg[13] ),
    .S(net66),
    .X(_291_));
 sky130_fd_sc_hd__nand2_1 _321_ (.A(net60),
    .B(_291_),
    .Y(_292_));
 sky130_fd_sc_hd__mux2_1 _322_ (.A0(\A_reg[3] ),
    .A1(\A_reg[12] ),
    .S(net66),
    .X(_293_));
 sky130_fd_sc_hd__nand2_1 _323_ (.A(net60),
    .B(_293_),
    .Y(_294_));
 sky130_fd_sc_hd__mux2_1 _324_ (.A0(_292_),
    .A1(_294_),
    .S(net84),
    .X(_295_));
 sky130_fd_sc_hd__or2_1 _325_ (.A(net66),
    .B(\A_reg[1] ),
    .X(_296_));
 sky130_fd_sc_hd__o211a_1 _326_ (.A1(net61),
    .A2(\A_reg[14] ),
    .B1(net60),
    .C1(_296_),
    .X(_297_));
 sky130_fd_sc_hd__or2_1 _327_ (.A(\A_reg[0] ),
    .B(op_sll),
    .X(_298_));
 sky130_fd_sc_hd__o211a_1 _328_ (.A1(net61),
    .A2(\A_reg[15] ),
    .B1(net60),
    .C1(_298_),
    .X(_299_));
 sky130_fd_sc_hd__mux2_1 _329_ (.A0(_299_),
    .A1(_297_),
    .S(net85),
    .X(_009_));
 sky130_fd_sc_hd__nor2_1 _330_ (.A(net81),
    .B(_009_),
    .Y(_010_));
 sky130_fd_sc_hd__a211oi_1 _331_ (.A1(net81),
    .A2(_295_),
    .B1(_010_),
    .C1(net78),
    .Y(_011_));
 sky130_fd_sc_hd__mux2_1 _332_ (.A0(\A_reg[8] ),
    .A1(\A_reg[7] ),
    .S(net65),
    .X(_012_));
 sky130_fd_sc_hd__nand2_1 _333_ (.A(net59),
    .B(_012_),
    .Y(_013_));
 sky130_fd_sc_hd__inv_2 _334_ (.A(_013_),
    .Y(_014_));
 sky130_fd_sc_hd__mux2_1 _335_ (.A0(\A_reg[9] ),
    .A1(\A_reg[6] ),
    .S(net65),
    .X(_015_));
 sky130_fd_sc_hd__nand2_1 _336_ (.A(net59),
    .B(_015_),
    .Y(_016_));
 sky130_fd_sc_hd__mux2_1 _337_ (.A0(_013_),
    .A1(_016_),
    .S(net83),
    .X(_017_));
 sky130_fd_sc_hd__mux2_1 _338_ (.A0(\A_reg[10] ),
    .A1(\A_reg[5] ),
    .S(net64),
    .X(_018_));
 sky130_fd_sc_hd__nand2_1 _339_ (.A(net59),
    .B(_018_),
    .Y(_019_));
 sky130_fd_sc_hd__mux2_1 _340_ (.A0(\A_reg[11] ),
    .A1(\A_reg[4] ),
    .S(net64),
    .X(_020_));
 sky130_fd_sc_hd__nand2_1 _341_ (.A(net59),
    .B(_020_),
    .Y(_021_));
 sky130_fd_sc_hd__mux2_1 _342_ (.A0(_019_),
    .A1(_021_),
    .S(net83),
    .X(_022_));
 sky130_fd_sc_hd__mux2_1 _343_ (.A0(_017_),
    .A1(_022_),
    .S(net80),
    .X(_023_));
 sky130_fd_sc_hd__mux2_1 _344_ (.A0(\A_reg[12] ),
    .A1(\A_reg[3] ),
    .S(net64),
    .X(_024_));
 sky130_fd_sc_hd__nand2_1 _345_ (.A(net60),
    .B(_024_),
    .Y(_025_));
 sky130_fd_sc_hd__mux2_1 _346_ (.A0(\A_reg[13] ),
    .A1(\A_reg[2] ),
    .S(net66),
    .X(_026_));
 sky130_fd_sc_hd__nand2_1 _347_ (.A(net59),
    .B(_026_),
    .Y(_027_));
 sky130_fd_sc_hd__mux2_1 _348_ (.A0(_025_),
    .A1(_027_),
    .S(net84),
    .X(_028_));
 sky130_fd_sc_hd__mux2_1 _349_ (.A0(\A_reg[14] ),
    .A1(\A_reg[1] ),
    .S(net66),
    .X(_029_));
 sky130_fd_sc_hd__nand2_1 _350_ (.A(net59),
    .B(_029_),
    .Y(_030_));
 sky130_fd_sc_hd__mux2_1 _351_ (.A0(\A_reg[15] ),
    .A1(\A_reg[0] ),
    .S(net66),
    .X(_031_));
 sky130_fd_sc_hd__nand2_1 _352_ (.A(net60),
    .B(_031_),
    .Y(_032_));
 sky130_fd_sc_hd__mux2_1 _353_ (.A0(_030_),
    .A1(_032_),
    .S(net84),
    .X(_033_));
 sky130_fd_sc_hd__mux2_1 _354_ (.A0(_028_),
    .A1(_033_),
    .S(net80),
    .X(_034_));
 sky130_fd_sc_hd__mux2_1 _355_ (.A0(_023_),
    .A1(_034_),
    .S(net77),
    .X(_035_));
 sky130_fd_sc_hd__nand2_1 _356_ (.A(net75),
    .B(_035_),
    .Y(_036_));
 sky130_fd_sc_hd__o311a_1 _357_ (.A1(net76),
    .A2(_290_),
    .A3(_011_),
    .B1(_036_),
    .C1(net61),
    .X(_037_));
 sky130_fd_sc_hd__or2_1 _358_ (.A(net84),
    .B(_032_),
    .X(_038_));
 sky130_fd_sc_hd__or2_1 _359_ (.A(net80),
    .B(_038_),
    .X(_039_));
 sky130_fd_sc_hd__or2_1 _360_ (.A(net78),
    .B(_039_),
    .X(_040_));
 sky130_fd_sc_hd__or2_4 _361_ (.A(net76),
    .B(net61),
    .X(_041_));
 sky130_fd_sc_hd__nor2_2 _362_ (.A(net73),
    .B(op_add),
    .Y(_042_));
 sky130_fd_sc_hd__or2_1 _363_ (.A(net73),
    .B(op_add),
    .X(_043_));
 sky130_fd_sc_hd__o2bb2a_1 _364_ (.A1_N(\A_reg[0] ),
    .A2_N(net85),
    .B1(net68),
    .B2(net56),
    .X(_044_));
 sky130_fd_sc_hd__o22ai_1 _365_ (.A1(\A_reg[0] ),
    .A2(net85),
    .B1(net69),
    .B2(_044_),
    .Y(_045_));
 sky130_fd_sc_hd__and3_1 _366_ (.A(\A_reg[0] ),
    .B(net85),
    .C(net71),
    .X(_046_));
 sky130_fd_sc_hd__o221a_1 _367_ (.A1(\A_reg[0] ),
    .A2(_272_),
    .B1(_040_),
    .B2(_041_),
    .C1(_045_),
    .X(_047_));
 sky130_fd_sc_hd__or3b_1 _368_ (.A(_037_),
    .B(_046_),
    .C_N(_047_),
    .X(\result_comb[0] ));
 sky130_fd_sc_hd__nand2b_1 _369_ (.A_N(_284_),
    .B(net83),
    .Y(_048_));
 sky130_fd_sc_hd__o21ai_1 _370_ (.A1(net83),
    .A2(_280_),
    .B1(_048_),
    .Y(_049_));
 sky130_fd_sc_hd__mux2_1 _371_ (.A0(_286_),
    .A1(_014_),
    .S(net85),
    .X(_050_));
 sky130_fd_sc_hd__inv_2 _372_ (.A(_050_),
    .Y(_051_));
 sky130_fd_sc_hd__nor2_1 _373_ (.A(net84),
    .B(_294_),
    .Y(_052_));
 sky130_fd_sc_hd__a21oi_1 _374_ (.A1(net83),
    .A2(_278_),
    .B1(_052_),
    .Y(_053_));
 sky130_fd_sc_hd__nor2_1 _375_ (.A(net83),
    .B(_297_),
    .Y(_054_));
 sky130_fd_sc_hd__a21oi_1 _376_ (.A1(net84),
    .A2(_292_),
    .B1(_054_),
    .Y(_055_));
 sky130_fd_sc_hd__inv_2 _377_ (.A(_055_),
    .Y(_056_));
 sky130_fd_sc_hd__mux4_1 _378_ (.A0(_056_),
    .A1(_053_),
    .A2(_049_),
    .A3(_051_),
    .S0(net81),
    .S1(net78),
    .X(_057_));
 sky130_fd_sc_hd__mux2_1 _379_ (.A0(_016_),
    .A1(_019_),
    .S(net83),
    .X(_058_));
 sky130_fd_sc_hd__inv_2 _380_ (.A(_058_),
    .Y(_059_));
 sky130_fd_sc_hd__mux2_1 _381_ (.A0(_021_),
    .A1(_025_),
    .S(net83),
    .X(_060_));
 sky130_fd_sc_hd__mux2_1 _382_ (.A0(_027_),
    .A1(_030_),
    .S(net84),
    .X(_061_));
 sky130_fd_sc_hd__mux2_1 _383_ (.A0(_061_),
    .A1(_038_),
    .S(net82),
    .X(_062_));
 sky130_fd_sc_hd__mux4_2 _384_ (.A0(_058_),
    .A1(_060_),
    .A2(_061_),
    .A3(_038_),
    .S0(net80),
    .S1(net77),
    .X(_063_));
 sky130_fd_sc_hd__mux2_1 _385_ (.A0(_057_),
    .A1(_063_),
    .S(net75),
    .X(_064_));
 sky130_fd_sc_hd__xor2_1 _386_ (.A(is_sub),
    .B(net82),
    .X(_065_));
 sky130_fd_sc_hd__xnor2_1 _387_ (.A(_275_),
    .B(_065_),
    .Y(_066_));
 sky130_fd_sc_hd__mux2_1 _388_ (.A0(net73),
    .A1(\A_reg[0] ),
    .S(net85),
    .X(_067_));
 sky130_fd_sc_hd__nand2_1 _389_ (.A(net56),
    .B(_067_),
    .Y(_068_));
 sky130_fd_sc_hd__mux2_1 _390_ (.A0(_067_),
    .A1(_068_),
    .S(_066_),
    .X(_069_));
 sky130_fd_sc_hd__a21boi_1 _391_ (.A1(net82),
    .A2(\A_reg[1] ),
    .B1_N(net68),
    .Y(_070_));
 sky130_fd_sc_hd__o22a_1 _392_ (.A1(net82),
    .A2(\A_reg[1] ),
    .B1(_070_),
    .B2(net70),
    .X(_071_));
 sky130_fd_sc_hd__and3_1 _393_ (.A(net71),
    .B(net82),
    .C(\A_reg[1] ),
    .X(_072_));
 sky130_fd_sc_hd__a221o_1 _394_ (.A1(op_not),
    .A2(_275_),
    .B1(net56),
    .B2(_069_),
    .C1(_072_),
    .X(_073_));
 sky130_fd_sc_hd__or2_1 _395_ (.A(net81),
    .B(_033_),
    .X(_074_));
 sky130_fd_sc_hd__or2_1 _396_ (.A(net77),
    .B(_074_),
    .X(_075_));
 sky130_fd_sc_hd__o22a_1 _397_ (.A1(net66),
    .A2(_064_),
    .B1(_075_),
    .B2(_041_),
    .X(_076_));
 sky130_fd_sc_hd__or3b_1 _398_ (.A(_071_),
    .B(_073_),
    .C_N(_076_),
    .X(\result_comb[1] ));
 sky130_fd_sc_hd__mux2_1 _399_ (.A0(_288_),
    .A1(_017_),
    .S(net80),
    .X(_077_));
 sky130_fd_sc_hd__mux2_1 _400_ (.A0(_295_),
    .A1(_282_),
    .S(net81),
    .X(_078_));
 sky130_fd_sc_hd__mux2_1 _401_ (.A0(_022_),
    .A1(_028_),
    .S(net80),
    .X(_079_));
 sky130_fd_sc_hd__mux2_1 _402_ (.A0(_079_),
    .A1(_074_),
    .S(net77),
    .X(_080_));
 sky130_fd_sc_hd__mux4_1 _403_ (.A0(_078_),
    .A1(_079_),
    .A2(_077_),
    .A3(_074_),
    .S0(net76),
    .S1(net77),
    .X(_081_));
 sky130_fd_sc_hd__and3_1 _404_ (.A(\A_reg[1] ),
    .B(net56),
    .C(_065_),
    .X(_082_));
 sky130_fd_sc_hd__a31o_1 _405_ (.A1(net56),
    .A2(_066_),
    .A3(_067_),
    .B1(_082_),
    .X(_083_));
 sky130_fd_sc_hd__xor2_1 _406_ (.A(net73),
    .B(net79),
    .X(_084_));
 sky130_fd_sc_hd__nand2_1 _407_ (.A(\A_reg[2] ),
    .B(_084_),
    .Y(_085_));
 sky130_fd_sc_hd__or2_1 _408_ (.A(\A_reg[2] ),
    .B(_084_),
    .X(_086_));
 sky130_fd_sc_hd__and3_1 _409_ (.A(net56),
    .B(_085_),
    .C(_086_),
    .X(_087_));
 sky130_fd_sc_hd__xnor2_1 _410_ (.A(_083_),
    .B(_087_),
    .Y(_088_));
 sky130_fd_sc_hd__nor2_1 _411_ (.A(net77),
    .B(\A_reg[2] ),
    .Y(_089_));
 sky130_fd_sc_hd__nand2_1 _412_ (.A(net79),
    .B(\A_reg[2] ),
    .Y(_090_));
 sky130_fd_sc_hd__a21oi_1 _413_ (.A1(net68),
    .A2(_090_),
    .B1(net69),
    .Y(_091_));
 sky130_fd_sc_hd__o221a_1 _414_ (.A1(_271_),
    .A2(_090_),
    .B1(_091_),
    .B2(_089_),
    .C1(_088_),
    .X(_092_));
 sky130_fd_sc_hd__or2_1 _415_ (.A(net79),
    .B(_062_),
    .X(_093_));
 sky130_fd_sc_hd__o221a_1 _416_ (.A1(net63),
    .A2(\A_reg[2] ),
    .B1(_041_),
    .B2(_093_),
    .C1(_092_),
    .X(_094_));
 sky130_fd_sc_hd__o21ai_1 _417_ (.A1(net66),
    .A2(_081_),
    .B1(_094_),
    .Y(\result_comb[2] ));
 sky130_fd_sc_hd__mux2_1 _418_ (.A0(_053_),
    .A1(_049_),
    .S(net80),
    .X(_095_));
 sky130_fd_sc_hd__mux2_1 _419_ (.A0(_050_),
    .A1(_059_),
    .S(net80),
    .X(_096_));
 sky130_fd_sc_hd__mux2_1 _420_ (.A0(_060_),
    .A1(_061_),
    .S(net80),
    .X(_097_));
 sky130_fd_sc_hd__inv_2 _421_ (.A(_097_),
    .Y(_098_));
 sky130_fd_sc_hd__mux2_1 _422_ (.A0(_097_),
    .A1(_039_),
    .S(net78),
    .X(_099_));
 sky130_fd_sc_hd__or2_1 _423_ (.A(net78),
    .B(_095_),
    .X(_100_));
 sky130_fd_sc_hd__a21oi_1 _424_ (.A1(net78),
    .A2(_096_),
    .B1(net75),
    .Y(_101_));
 sky130_fd_sc_hd__a22o_1 _425_ (.A1(net75),
    .A2(_099_),
    .B1(_100_),
    .B2(_101_),
    .X(_102_));
 sky130_fd_sc_hd__a2bb2o_1 _426_ (.A1_N(_042_),
    .A2_N(_085_),
    .B1(_087_),
    .B2(_083_),
    .X(_103_));
 sky130_fd_sc_hd__xor2_1 _427_ (.A(net73),
    .B(net76),
    .X(_104_));
 sky130_fd_sc_hd__nand2_1 _428_ (.A(\A_reg[3] ),
    .B(_104_),
    .Y(_105_));
 sky130_fd_sc_hd__or2_1 _429_ (.A(\A_reg[3] ),
    .B(_104_),
    .X(_106_));
 sky130_fd_sc_hd__and3_1 _430_ (.A(net56),
    .B(_105_),
    .C(_106_),
    .X(_107_));
 sky130_fd_sc_hd__xnor2_1 _431_ (.A(_103_),
    .B(_107_),
    .Y(_108_));
 sky130_fd_sc_hd__or2_1 _432_ (.A(net77),
    .B(_034_),
    .X(_109_));
 sky130_fd_sc_hd__nand2_1 _433_ (.A(net76),
    .B(\A_reg[3] ),
    .Y(_110_));
 sky130_fd_sc_hd__a21o_1 _434_ (.A1(net68),
    .A2(_110_),
    .B1(net70),
    .X(_111_));
 sky130_fd_sc_hd__o21ai_1 _435_ (.A1(net76),
    .A2(\A_reg[3] ),
    .B1(_111_),
    .Y(_112_));
 sky130_fd_sc_hd__o221a_1 _436_ (.A1(net63),
    .A2(\A_reg[3] ),
    .B1(_110_),
    .B2(_271_),
    .C1(_112_),
    .X(_113_));
 sky130_fd_sc_hd__o221a_1 _437_ (.A1(net64),
    .A2(_102_),
    .B1(_109_),
    .B2(_041_),
    .C1(_113_),
    .X(_114_));
 sky130_fd_sc_hd__nand2_1 _438_ (.A(_108_),
    .B(_114_),
    .Y(\result_comb[3] ));
 sky130_fd_sc_hd__xor2_1 _439_ (.A(net74),
    .B(\B_reg[4] ),
    .X(_115_));
 sky130_fd_sc_hd__nand2_1 _440_ (.A(\A_reg[4] ),
    .B(_115_),
    .Y(_116_));
 sky130_fd_sc_hd__or2_1 _441_ (.A(\A_reg[4] ),
    .B(_115_),
    .X(_117_));
 sky130_fd_sc_hd__and3_1 _442_ (.A(net57),
    .B(_116_),
    .C(_117_),
    .X(_118_));
 sky130_fd_sc_hd__a2bb2o_1 _443_ (.A1_N(net58),
    .A2_N(_105_),
    .B1(_107_),
    .B2(_103_),
    .X(_119_));
 sky130_fd_sc_hd__nand2_1 _444_ (.A(_118_),
    .B(_119_),
    .Y(_120_));
 sky130_fd_sc_hd__or2_1 _445_ (.A(_118_),
    .B(_119_),
    .X(_121_));
 sky130_fd_sc_hd__nor2_1 _446_ (.A(_041_),
    .B(_099_),
    .Y(_122_));
 sky130_fd_sc_hd__a21boi_1 _447_ (.A1(\A_reg[4] ),
    .A2(\B_reg[4] ),
    .B1_N(net67),
    .Y(_123_));
 sky130_fd_sc_hd__o22a_1 _448_ (.A1(\A_reg[4] ),
    .A2(\B_reg[4] ),
    .B1(_123_),
    .B2(net69),
    .X(_124_));
 sky130_fd_sc_hd__nor2_1 _449_ (.A(net77),
    .B(_289_),
    .Y(_125_));
 sky130_fd_sc_hd__a21o_1 _450_ (.A1(net77),
    .A2(_023_),
    .B1(_125_),
    .X(_126_));
 sky130_fd_sc_hd__mux2_1 _451_ (.A0(_126_),
    .A1(_109_),
    .S(net76),
    .X(_127_));
 sky130_fd_sc_hd__a31o_1 _452_ (.A1(net71),
    .A2(\A_reg[4] ),
    .A3(\B_reg[4] ),
    .B1(_124_),
    .X(_128_));
 sky130_fd_sc_hd__a211o_1 _453_ (.A1(_120_),
    .A2(_121_),
    .B1(_122_),
    .C1(_128_),
    .X(_129_));
 sky130_fd_sc_hd__o22ai_1 _454_ (.A1(net63),
    .A2(\A_reg[4] ),
    .B1(_127_),
    .B2(net64),
    .Y(_130_));
 sky130_fd_sc_hd__or2_1 _455_ (.A(_129_),
    .B(_130_),
    .X(\result_comb[4] ));
 sky130_fd_sc_hd__xor2_1 _456_ (.A(net74),
    .B(\B_reg[5] ),
    .X(_131_));
 sky130_fd_sc_hd__nand2_1 _457_ (.A(\A_reg[5] ),
    .B(_131_),
    .Y(_132_));
 sky130_fd_sc_hd__or2_1 _458_ (.A(\A_reg[5] ),
    .B(_131_),
    .X(_133_));
 sky130_fd_sc_hd__and3_1 _459_ (.A(net57),
    .B(_132_),
    .C(_133_),
    .X(_134_));
 sky130_fd_sc_hd__a2bb2o_1 _460_ (.A1_N(net58),
    .A2_N(_116_),
    .B1(_118_),
    .B2(_119_),
    .X(_135_));
 sky130_fd_sc_hd__xnor2_1 _461_ (.A(_134_),
    .B(_135_),
    .Y(_136_));
 sky130_fd_sc_hd__a21boi_1 _462_ (.A1(\A_reg[5] ),
    .A2(\B_reg[5] ),
    .B1_N(net67),
    .Y(_137_));
 sky130_fd_sc_hd__o22a_1 _463_ (.A1(\A_reg[5] ),
    .A2(\B_reg[5] ),
    .B1(_137_),
    .B2(net69),
    .X(_138_));
 sky130_fd_sc_hd__mux4_1 _464_ (.A0(_049_),
    .A1(_051_),
    .A2(_058_),
    .A3(_060_),
    .S0(net81),
    .S1(net78),
    .X(_139_));
 sky130_fd_sc_hd__mux2_1 _465_ (.A0(_139_),
    .A1(_093_),
    .S(net76),
    .X(_140_));
 sky130_fd_sc_hd__a31oi_1 _466_ (.A1(net71),
    .A2(\A_reg[5] ),
    .A3(\B_reg[5] ),
    .B1(_138_),
    .Y(_141_));
 sky130_fd_sc_hd__o221a_1 _467_ (.A1(_041_),
    .A2(_080_),
    .B1(_140_),
    .B2(net64),
    .C1(_141_),
    .X(_142_));
 sky130_fd_sc_hd__o211ai_2 _468_ (.A1(net63),
    .A2(net86),
    .B1(_136_),
    .C1(_142_),
    .Y(\result_comb[5] ));
 sky130_fd_sc_hd__xor2_1 _469_ (.A(net74),
    .B(\B_reg[6] ),
    .X(_143_));
 sky130_fd_sc_hd__nand2_1 _470_ (.A(\A_reg[6] ),
    .B(_143_),
    .Y(_144_));
 sky130_fd_sc_hd__or2_1 _471_ (.A(\A_reg[6] ),
    .B(_143_),
    .X(_145_));
 sky130_fd_sc_hd__and3_1 _472_ (.A(net57),
    .B(_144_),
    .C(_145_),
    .X(_146_));
 sky130_fd_sc_hd__a2bb2o_1 _473_ (.A1_N(net58),
    .A2_N(_132_),
    .B1(_134_),
    .B2(_135_),
    .X(_147_));
 sky130_fd_sc_hd__xor2_1 _474_ (.A(_146_),
    .B(_147_),
    .X(_148_));
 sky130_fd_sc_hd__a21boi_1 _475_ (.A1(\A_reg[6] ),
    .A2(\B_reg[6] ),
    .B1_N(net67),
    .Y(_149_));
 sky130_fd_sc_hd__o22a_1 _476_ (.A1(\A_reg[6] ),
    .A2(\B_reg[6] ),
    .B1(_149_),
    .B2(net69),
    .X(_150_));
 sky130_fd_sc_hd__nand3_1 _477_ (.A(net72),
    .B(\A_reg[6] ),
    .C(\B_reg[6] ),
    .Y(_151_));
 sky130_fd_sc_hd__o221a_1 _478_ (.A1(_272_),
    .A2(\A_reg[6] ),
    .B1(_041_),
    .B2(_063_),
    .C1(_151_),
    .X(_152_));
 sky130_fd_sc_hd__mux2_1 _479_ (.A0(_077_),
    .A1(_079_),
    .S(net77),
    .X(_153_));
 sky130_fd_sc_hd__mux2_1 _480_ (.A0(_153_),
    .A1(_075_),
    .S(net75),
    .X(_154_));
 sky130_fd_sc_hd__nor2_1 _481_ (.A(net65),
    .B(_154_),
    .Y(_155_));
 sky130_fd_sc_hd__or4b_1 _482_ (.A(_148_),
    .B(_150_),
    .C(_155_),
    .D_N(_152_),
    .X(\result_comb[6] ));
 sky130_fd_sc_hd__xor2_1 _483_ (.A(net74),
    .B(\B_reg[7] ),
    .X(_156_));
 sky130_fd_sc_hd__nand2_1 _484_ (.A(\A_reg[7] ),
    .B(_156_),
    .Y(_157_));
 sky130_fd_sc_hd__or2_1 _485_ (.A(\A_reg[7] ),
    .B(_156_),
    .X(_158_));
 sky130_fd_sc_hd__and3_1 _486_ (.A(net57),
    .B(_157_),
    .C(_158_),
    .X(_159_));
 sky130_fd_sc_hd__a2bb2o_1 _487_ (.A1_N(net58),
    .A2_N(_144_),
    .B1(_146_),
    .B2(_147_),
    .X(_160_));
 sky130_fd_sc_hd__xor2_1 _488_ (.A(_159_),
    .B(_160_),
    .X(_161_));
 sky130_fd_sc_hd__a21boi_1 _489_ (.A1(\A_reg[7] ),
    .A2(\B_reg[7] ),
    .B1_N(net67),
    .Y(_162_));
 sky130_fd_sc_hd__o22a_1 _490_ (.A1(\A_reg[7] ),
    .A2(\B_reg[7] ),
    .B1(_162_),
    .B2(net69),
    .X(_163_));
 sky130_fd_sc_hd__nand3_1 _491_ (.A(net72),
    .B(\A_reg[7] ),
    .C(\B_reg[7] ),
    .Y(_164_));
 sky130_fd_sc_hd__o221a_1 _492_ (.A1(_272_),
    .A2(\A_reg[7] ),
    .B1(_035_),
    .B2(_041_),
    .C1(_164_),
    .X(_165_));
 sky130_fd_sc_hd__mux2_1 _493_ (.A0(_096_),
    .A1(_098_),
    .S(net78),
    .X(_166_));
 sky130_fd_sc_hd__nor2_1 _494_ (.A(net75),
    .B(_166_),
    .Y(_167_));
 sky130_fd_sc_hd__a211oi_1 _495_ (.A1(net75),
    .A2(_040_),
    .B1(_167_),
    .C1(net65),
    .Y(_168_));
 sky130_fd_sc_hd__or4b_1 _496_ (.A(_161_),
    .B(_163_),
    .C(_168_),
    .D_N(_165_),
    .X(\result_comb[7] ));
 sky130_fd_sc_hd__xor2_1 _497_ (.A(net74),
    .B(\B_reg[8] ),
    .X(_169_));
 sky130_fd_sc_hd__nand2_1 _498_ (.A(\A_reg[8] ),
    .B(_169_),
    .Y(_170_));
 sky130_fd_sc_hd__or2_1 _499_ (.A(\A_reg[8] ),
    .B(_169_),
    .X(_171_));
 sky130_fd_sc_hd__and3_1 _500_ (.A(net57),
    .B(_170_),
    .C(_171_),
    .X(_172_));
 sky130_fd_sc_hd__a2bb2o_1 _501_ (.A1_N(net58),
    .A2_N(_157_),
    .B1(_159_),
    .B2(_160_),
    .X(_173_));
 sky130_fd_sc_hd__xor2_1 _502_ (.A(_172_),
    .B(_173_),
    .X(_174_));
 sky130_fd_sc_hd__or2_4 _503_ (.A(net76),
    .B(net64),
    .X(_175_));
 sky130_fd_sc_hd__a21boi_1 _504_ (.A1(\A_reg[8] ),
    .A2(\B_reg[8] ),
    .B1_N(net67),
    .Y(_176_));
 sky130_fd_sc_hd__o22a_1 _505_ (.A1(\A_reg[8] ),
    .A2(\B_reg[8] ),
    .B1(_176_),
    .B2(net69),
    .X(_177_));
 sky130_fd_sc_hd__nand3_1 _506_ (.A(net72),
    .B(\A_reg[8] ),
    .C(\B_reg[8] ),
    .Y(_178_));
 sky130_fd_sc_hd__o221a_1 _507_ (.A1(net63),
    .A2(\A_reg[8] ),
    .B1(_035_),
    .B2(_175_),
    .C1(_178_),
    .X(_179_));
 sky130_fd_sc_hd__a211oi_1 _508_ (.A1(net75),
    .A2(_040_),
    .B1(_167_),
    .C1(net62),
    .Y(_180_));
 sky130_fd_sc_hd__or4b_1 _509_ (.A(_174_),
    .B(_177_),
    .C(_180_),
    .D_N(_179_),
    .X(\result_comb[8] ));
 sky130_fd_sc_hd__xor2_1 _510_ (.A(net74),
    .B(\B_reg[9] ),
    .X(_181_));
 sky130_fd_sc_hd__nand2_1 _511_ (.A(\A_reg[9] ),
    .B(_181_),
    .Y(_182_));
 sky130_fd_sc_hd__or2_1 _512_ (.A(\A_reg[9] ),
    .B(_181_),
    .X(_183_));
 sky130_fd_sc_hd__and3_1 _513_ (.A(net57),
    .B(_182_),
    .C(_183_),
    .X(_184_));
 sky130_fd_sc_hd__a2bb2o_1 _514_ (.A1_N(net58),
    .A2_N(_170_),
    .B1(_172_),
    .B2(_173_),
    .X(_185_));
 sky130_fd_sc_hd__and2_1 _515_ (.A(_184_),
    .B(_185_),
    .X(_186_));
 sky130_fd_sc_hd__nor2_1 _516_ (.A(_184_),
    .B(_185_),
    .Y(_187_));
 sky130_fd_sc_hd__a21boi_1 _517_ (.A1(\A_reg[9] ),
    .A2(\B_reg[9] ),
    .B1_N(net67),
    .Y(_188_));
 sky130_fd_sc_hd__o22ai_1 _518_ (.A1(\A_reg[9] ),
    .A2(\B_reg[9] ),
    .B1(_188_),
    .B2(net69),
    .Y(_189_));
 sky130_fd_sc_hd__o221a_1 _519_ (.A1(net63),
    .A2(\A_reg[9] ),
    .B1(_063_),
    .B2(_175_),
    .C1(_189_),
    .X(_190_));
 sky130_fd_sc_hd__o221ai_1 _520_ (.A1(net62),
    .A2(_154_),
    .B1(_186_),
    .B2(_187_),
    .C1(_190_),
    .Y(_191_));
 sky130_fd_sc_hd__a31o_1 _521_ (.A1(net72),
    .A2(\A_reg[9] ),
    .A3(\B_reg[9] ),
    .B1(_191_),
    .X(\result_comb[9] ));
 sky130_fd_sc_hd__xor2_1 _522_ (.A(net74),
    .B(\B_reg[10] ),
    .X(_192_));
 sky130_fd_sc_hd__nand2_1 _523_ (.A(\A_reg[10] ),
    .B(_192_),
    .Y(_193_));
 sky130_fd_sc_hd__or2_1 _524_ (.A(\A_reg[10] ),
    .B(_192_),
    .X(_194_));
 sky130_fd_sc_hd__and3_1 _525_ (.A(net57),
    .B(_193_),
    .C(_194_),
    .X(_195_));
 sky130_fd_sc_hd__a2bb2o_1 _526_ (.A1_N(net58),
    .A2_N(_182_),
    .B1(_184_),
    .B2(_185_),
    .X(_196_));
 sky130_fd_sc_hd__and2_1 _527_ (.A(_195_),
    .B(_196_),
    .X(_197_));
 sky130_fd_sc_hd__nor2_1 _528_ (.A(_195_),
    .B(_196_),
    .Y(_198_));
 sky130_fd_sc_hd__a21boi_1 _529_ (.A1(\A_reg[10] ),
    .A2(\B_reg[10] ),
    .B1_N(net67),
    .Y(_199_));
 sky130_fd_sc_hd__o22ai_1 _530_ (.A1(\A_reg[10] ),
    .A2(\B_reg[10] ),
    .B1(_199_),
    .B2(net69),
    .Y(_200_));
 sky130_fd_sc_hd__o221a_1 _531_ (.A1(net63),
    .A2(\A_reg[10] ),
    .B1(_080_),
    .B2(_175_),
    .C1(_200_),
    .X(_201_));
 sky130_fd_sc_hd__o221ai_1 _532_ (.A1(net61),
    .A2(_140_),
    .B1(_197_),
    .B2(_198_),
    .C1(_201_),
    .Y(_202_));
 sky130_fd_sc_hd__a31o_1 _533_ (.A1(net71),
    .A2(\A_reg[10] ),
    .A3(\B_reg[10] ),
    .B1(_202_),
    .X(\result_comb[10] ));
 sky130_fd_sc_hd__xor2_1 _534_ (.A(net74),
    .B(\B_reg[11] ),
    .X(_203_));
 sky130_fd_sc_hd__nand2_1 _535_ (.A(\A_reg[11] ),
    .B(_203_),
    .Y(_204_));
 sky130_fd_sc_hd__or2_1 _536_ (.A(\A_reg[11] ),
    .B(_203_),
    .X(_205_));
 sky130_fd_sc_hd__and3_1 _537_ (.A(net57),
    .B(_204_),
    .C(_205_),
    .X(_206_));
 sky130_fd_sc_hd__a2bb2o_1 _538_ (.A1_N(net58),
    .A2_N(_193_),
    .B1(_195_),
    .B2(_196_),
    .X(_207_));
 sky130_fd_sc_hd__xor2_1 _539_ (.A(_206_),
    .B(_207_),
    .X(_208_));
 sky130_fd_sc_hd__a21boi_1 _540_ (.A1(\A_reg[11] ),
    .A2(\B_reg[11] ),
    .B1_N(net67),
    .Y(_209_));
 sky130_fd_sc_hd__o22a_1 _541_ (.A1(\A_reg[11] ),
    .A2(\B_reg[11] ),
    .B1(_209_),
    .B2(net69),
    .X(_210_));
 sky130_fd_sc_hd__nand3_1 _542_ (.A(net71),
    .B(\A_reg[11] ),
    .C(\B_reg[11] ),
    .Y(_211_));
 sky130_fd_sc_hd__o221a_1 _543_ (.A1(net63),
    .A2(\A_reg[11] ),
    .B1(_099_),
    .B2(_175_),
    .C1(_211_),
    .X(_212_));
 sky130_fd_sc_hd__nor2_1 _544_ (.A(net61),
    .B(_127_),
    .Y(_213_));
 sky130_fd_sc_hd__or4b_1 _545_ (.A(_208_),
    .B(_210_),
    .C(_213_),
    .D_N(_212_),
    .X(\result_comb[11] ));
 sky130_fd_sc_hd__xor2_1 _546_ (.A(net73),
    .B(\B_reg[12] ),
    .X(_214_));
 sky130_fd_sc_hd__nand2_1 _547_ (.A(\A_reg[12] ),
    .B(_214_),
    .Y(_215_));
 sky130_fd_sc_hd__or2_1 _548_ (.A(\A_reg[12] ),
    .B(_214_),
    .X(_216_));
 sky130_fd_sc_hd__and3_1 _549_ (.A(net56),
    .B(_215_),
    .C(_216_),
    .X(_217_));
 sky130_fd_sc_hd__a2bb2o_1 _550_ (.A1_N(net58),
    .A2_N(_204_),
    .B1(_206_),
    .B2(_207_),
    .X(_218_));
 sky130_fd_sc_hd__xor2_1 _551_ (.A(_217_),
    .B(_218_),
    .X(_219_));
 sky130_fd_sc_hd__a21boi_1 _552_ (.A1(\A_reg[12] ),
    .A2(\B_reg[12] ),
    .B1_N(net67),
    .Y(_220_));
 sky130_fd_sc_hd__o22a_1 _553_ (.A1(\A_reg[12] ),
    .A2(\B_reg[12] ),
    .B1(_220_),
    .B2(net70),
    .X(_221_));
 sky130_fd_sc_hd__a31o_1 _554_ (.A1(net71),
    .A2(\A_reg[12] ),
    .A3(\B_reg[12] ),
    .B1(_221_),
    .X(_222_));
 sky130_fd_sc_hd__o22a_1 _555_ (.A1(net63),
    .A2(\A_reg[12] ),
    .B1(_109_),
    .B2(_175_),
    .X(_223_));
 sky130_fd_sc_hd__nor2_1 _556_ (.A(net61),
    .B(_102_),
    .Y(_224_));
 sky130_fd_sc_hd__or4b_1 _557_ (.A(_219_),
    .B(_222_),
    .C(_224_),
    .D_N(_223_),
    .X(\result_comb[12] ));
 sky130_fd_sc_hd__xor2_1 _558_ (.A(net73),
    .B(\B_reg[13] ),
    .X(_225_));
 sky130_fd_sc_hd__nand2_1 _559_ (.A(\A_reg[13] ),
    .B(_225_),
    .Y(_226_));
 sky130_fd_sc_hd__or2_1 _560_ (.A(\A_reg[13] ),
    .B(_225_),
    .X(_227_));
 sky130_fd_sc_hd__and3_1 _561_ (.A(net56),
    .B(_226_),
    .C(_227_),
    .X(_228_));
 sky130_fd_sc_hd__a2bb2o_1 _562_ (.A1_N(_042_),
    .A2_N(_215_),
    .B1(_217_),
    .B2(_218_),
    .X(_229_));
 sky130_fd_sc_hd__xor2_1 _563_ (.A(_228_),
    .B(_229_),
    .X(_230_));
 sky130_fd_sc_hd__a21boi_1 _564_ (.A1(\A_reg[13] ),
    .A2(\B_reg[13] ),
    .B1_N(net67),
    .Y(_231_));
 sky130_fd_sc_hd__o22a_1 _565_ (.A1(\A_reg[13] ),
    .A2(\B_reg[13] ),
    .B1(_231_),
    .B2(net70),
    .X(_232_));
 sky130_fd_sc_hd__nand3_1 _566_ (.A(net71),
    .B(\A_reg[13] ),
    .C(\B_reg[13] ),
    .Y(_233_));
 sky130_fd_sc_hd__o221a_1 _567_ (.A1(net63),
    .A2(\A_reg[13] ),
    .B1(_093_),
    .B2(_175_),
    .C1(_233_),
    .X(_234_));
 sky130_fd_sc_hd__nor2_1 _568_ (.A(net61),
    .B(_081_),
    .Y(_235_));
 sky130_fd_sc_hd__or4b_1 _569_ (.A(_230_),
    .B(_232_),
    .C(_235_),
    .D_N(_234_),
    .X(\result_comb[13] ));
 sky130_fd_sc_hd__xor2_1 _570_ (.A(net73),
    .B(\B_reg[14] ),
    .X(_236_));
 sky130_fd_sc_hd__nand2_1 _571_ (.A(\A_reg[14] ),
    .B(_236_),
    .Y(_237_));
 sky130_fd_sc_hd__or2_1 _572_ (.A(\A_reg[14] ),
    .B(_236_),
    .X(_238_));
 sky130_fd_sc_hd__and3_1 _573_ (.A(net56),
    .B(_237_),
    .C(_238_),
    .X(_239_));
 sky130_fd_sc_hd__a2bb2o_1 _574_ (.A1_N(net58),
    .A2_N(_226_),
    .B1(_228_),
    .B2(_229_),
    .X(_240_));
 sky130_fd_sc_hd__xor2_1 _575_ (.A(_239_),
    .B(_240_),
    .X(_241_));
 sky130_fd_sc_hd__a21boi_1 _576_ (.A1(\A_reg[14] ),
    .A2(\B_reg[14] ),
    .B1_N(net68),
    .Y(_242_));
 sky130_fd_sc_hd__o22a_1 _577_ (.A1(\A_reg[14] ),
    .A2(\B_reg[14] ),
    .B1(_242_),
    .B2(net70),
    .X(_243_));
 sky130_fd_sc_hd__nand3_1 _578_ (.A(net71),
    .B(\A_reg[14] ),
    .C(\B_reg[14] ),
    .Y(_244_));
 sky130_fd_sc_hd__o221a_1 _579_ (.A1(_272_),
    .A2(\A_reg[14] ),
    .B1(_075_),
    .B2(_175_),
    .C1(_244_),
    .X(_245_));
 sky130_fd_sc_hd__nor2_1 _580_ (.A(net62),
    .B(_064_),
    .Y(_246_));
 sky130_fd_sc_hd__or4b_1 _581_ (.A(_241_),
    .B(_243_),
    .C(_246_),
    .D_N(_245_),
    .X(\result_comb[14] ));
 sky130_fd_sc_hd__o2bb2a_1 _582_ (.A1_N(_239_),
    .A2_N(_240_),
    .B1(_042_),
    .B2(_237_),
    .X(_247_));
 sky130_fd_sc_hd__xor2_2 _583_ (.A(\A_reg[15] ),
    .B(\B_reg[15] ),
    .X(_248_));
 sky130_fd_sc_hd__nand2_1 _584_ (.A(op_add),
    .B(_248_),
    .Y(_249_));
 sky130_fd_sc_hd__mux2_1 _585_ (.A0(_249_),
    .A1(_248_),
    .S(net73),
    .X(_250_));
 sky130_fd_sc_hd__nor2_1 _586_ (.A(_247_),
    .B(_250_),
    .Y(_251_));
 sky130_fd_sc_hd__xor2_1 _587_ (.A(_247_),
    .B(_250_),
    .X(_252_));
 sky130_fd_sc_hd__nor2_1 _588_ (.A(_040_),
    .B(_175_),
    .Y(_253_));
 sky130_fd_sc_hd__o21a_1 _589_ (.A1(\A_reg[15] ),
    .A2(\B_reg[15] ),
    .B1(net70),
    .X(_254_));
 sky130_fd_sc_hd__a31o_1 _590_ (.A1(net72),
    .A2(\A_reg[15] ),
    .A3(\B_reg[15] ),
    .B1(_254_),
    .X(_255_));
 sky130_fd_sc_hd__a211o_1 _591_ (.A1(net68),
    .A2(_248_),
    .B1(_253_),
    .C1(_255_),
    .X(_256_));
 sky130_fd_sc_hd__o311a_1 _592_ (.A1(net75),
    .A2(_290_),
    .A3(_011_),
    .B1(_036_),
    .C1(net66),
    .X(_257_));
 sky130_fd_sc_hd__a2111o_1 _593_ (.A1(op_not),
    .A2(_274_),
    .B1(_252_),
    .C1(_256_),
    .D1(_257_),
    .X(\result_comb[15] ));
 sky130_fd_sc_hd__nor3_1 _594_ (.A(net35),
    .B(net34),
    .C(net33),
    .Y(_001_));
 sky130_fd_sc_hd__nor3b_1 _595_ (.A(net35),
    .B(net34),
    .C_N(net33),
    .Y(_007_));
 sky130_fd_sc_hd__nor3b_1 _596_ (.A(net35),
    .B(net33),
    .C_N(net34),
    .Y(_002_));
 sky130_fd_sc_hd__and3b_1 _597_ (.A_N(net35),
    .B(net34),
    .C(net33),
    .X(_004_));
 sky130_fd_sc_hd__nor3b_1 _598_ (.A(net34),
    .B(net33),
    .C_N(net35),
    .Y(_008_));
 sky130_fd_sc_hd__and3b_1 _599_ (.A_N(net34),
    .B(net33),
    .C(net35),
    .X(_003_));
 sky130_fd_sc_hd__and3b_1 _600_ (.A_N(net33),
    .B(net34),
    .C(net35),
    .X(_005_));
 sky130_fd_sc_hd__and3_1 _601_ (.A(net35),
    .B(net34),
    .C(net33),
    .X(_006_));
 sky130_fd_sc_hd__or4_1 _602_ (.A(\result_comb[0] ),
    .B(\result_comb[1] ),
    .C(\result_comb[2] ),
    .D(\result_comb[3] ),
    .X(_258_));
 sky130_fd_sc_hd__or4_1 _603_ (.A(\result_comb[4] ),
    .B(\result_comb[5] ),
    .C(\result_comb[6] ),
    .D(_258_),
    .X(_259_));
 sky130_fd_sc_hd__or3_1 _604_ (.A(\result_comb[7] ),
    .B(\result_comb[8] ),
    .C(_259_),
    .X(_260_));
 sky130_fd_sc_hd__or4_1 _605_ (.A(\result_comb[9] ),
    .B(\result_comb[10] ),
    .C(\result_comb[11] ),
    .D(_260_),
    .X(_261_));
 sky130_fd_sc_hd__or3_1 _606_ (.A(\result_comb[12] ),
    .B(\result_comb[13] ),
    .C(_261_),
    .X(_262_));
 sky130_fd_sc_hd__nor3_1 _607_ (.A(\result_comb[14] ),
    .B(\result_comb[15] ),
    .C(_262_),
    .Y(_000_));
 sky130_fd_sc_hd__nand2_1 _608_ (.A(net73),
    .B(\B_reg[15] ),
    .Y(_263_));
 sky130_fd_sc_hd__or2_1 _609_ (.A(is_sub),
    .B(\B_reg[15] ),
    .X(_264_));
 sky130_fd_sc_hd__and3b_1 _610_ (.A_N(net81),
    .B(_299_),
    .C(net85),
    .X(_265_));
 sky130_fd_sc_hd__a211oi_1 _611_ (.A1(net81),
    .A2(_055_),
    .B1(_265_),
    .C1(net79),
    .Y(_266_));
 sky130_fd_sc_hd__a211oi_1 _612_ (.A1(net78),
    .A2(_095_),
    .B1(_266_),
    .C1(\B_reg[3] ),
    .Y(_267_));
 sky130_fd_sc_hd__a41o_1 _613_ (.A1(\A_reg[15] ),
    .A2(net57),
    .A3(_263_),
    .A4(_264_),
    .B1(_267_),
    .X(_268_));
 sky130_fd_sc_hd__a211o_1 _614_ (.A1(net75),
    .A2(_166_),
    .B1(_251_),
    .C1(_268_),
    .X(carry_comb));
 sky130_fd_sc_hd__mux2_1 _615_ (.A0(op_add),
    .A1(net74),
    .S(_248_),
    .X(_269_));
 sky130_fd_sc_hd__a21boi_1 _616_ (.A1(\A_reg[15] ),
    .A2(_252_),
    .B1_N(_269_),
    .Y(_270_));
 sky130_fd_sc_hd__o21a_1 _617_ (.A1(\A_reg[15] ),
    .A2(_252_),
    .B1(_270_),
    .X(overflow_comb));
 sky130_fd_sc_hd__dfxtp_1 _618_ (.CLK(clknet_3_6__leaf_clk),
    .D(\result_comb[15] ),
    .Q(net37));
 sky130_fd_sc_hd__dfxtp_1 _619_ (.CLK(clknet_3_6__leaf_clk),
    .D(overflow_comb),
    .Q(net38));
 sky130_fd_sc_hd__dfxtp_1 _620_ (.CLK(clknet_3_5__leaf_clk),
    .D(\result_comb[0] ),
    .Q(net39));
 sky130_fd_sc_hd__dfxtp_1 _621_ (.CLK(clknet_3_7__leaf_clk),
    .D(\result_comb[1] ),
    .Q(net46));
 sky130_fd_sc_hd__dfxtp_1 _622_ (.CLK(clknet_3_7__leaf_clk),
    .D(\result_comb[2] ),
    .Q(net47));
 sky130_fd_sc_hd__dfxtp_1 _623_ (.CLK(clknet_3_7__leaf_clk),
    .D(\result_comb[3] ),
    .Q(net48));
 sky130_fd_sc_hd__dfxtp_1 _624_ (.CLK(clknet_3_1__leaf_clk),
    .D(\result_comb[4] ),
    .Q(net49));
 sky130_fd_sc_hd__dfxtp_1 _625_ (.CLK(clknet_3_4__leaf_clk),
    .D(\result_comb[5] ),
    .Q(net50));
 sky130_fd_sc_hd__dfxtp_1 _626_ (.CLK(clknet_3_4__leaf_clk),
    .D(\result_comb[6] ),
    .Q(net51));
 sky130_fd_sc_hd__dfxtp_1 _627_ (.CLK(clknet_3_4__leaf_clk),
    .D(\result_comb[7] ),
    .Q(net52));
 sky130_fd_sc_hd__dfxtp_1 _628_ (.CLK(clknet_3_5__leaf_clk),
    .D(\result_comb[8] ),
    .Q(net53));
 sky130_fd_sc_hd__dfxtp_1 _629_ (.CLK(clknet_3_1__leaf_clk),
    .D(\result_comb[9] ),
    .Q(net54));
 sky130_fd_sc_hd__dfxtp_1 _630_ (.CLK(clknet_3_0__leaf_clk),
    .D(\result_comb[10] ),
    .Q(net40));
 sky130_fd_sc_hd__dfxtp_1 _631_ (.CLK(clknet_3_0__leaf_clk),
    .D(\result_comb[11] ),
    .Q(net41));
 sky130_fd_sc_hd__dfxtp_1 _632_ (.CLK(clknet_3_2__leaf_clk),
    .D(\result_comb[12] ),
    .Q(net42));
 sky130_fd_sc_hd__dfxtp_1 _633_ (.CLK(clknet_3_3__leaf_clk),
    .D(\result_comb[13] ),
    .Q(net43));
 sky130_fd_sc_hd__dfxtp_1 _634_ (.CLK(clknet_3_6__leaf_clk),
    .D(\result_comb[14] ),
    .Q(net44));
 sky130_fd_sc_hd__dfxtp_1 _635_ (.CLK(clknet_3_6__leaf_clk),
    .D(_000_),
    .Q(net55));
 sky130_fd_sc_hd__dfxtp_1 _636_ (.CLK(clknet_3_7__leaf_clk),
    .D(net1),
    .Q(\A_reg[0] ));
 sky130_fd_sc_hd__dfxtp_1 _637_ (.CLK(clknet_3_6__leaf_clk),
    .D(net8),
    .Q(\A_reg[1] ));
 sky130_fd_sc_hd__dfxtp_1 _638_ (.CLK(clknet_3_3__leaf_clk),
    .D(net9),
    .Q(\A_reg[2] ));
 sky130_fd_sc_hd__dfxtp_1 _639_ (.CLK(clknet_3_0__leaf_clk),
    .D(net10),
    .Q(\A_reg[3] ));
 sky130_fd_sc_hd__dfxtp_1 _640_ (.CLK(clknet_3_1__leaf_clk),
    .D(net11),
    .Q(\A_reg[4] ));
 sky130_fd_sc_hd__dfxtp_2 _641_ (.CLK(clknet_3_1__leaf_clk),
    .D(net12),
    .Q(\A_reg[5] ));
 sky130_fd_sc_hd__dfxtp_1 _642_ (.CLK(clknet_3_4__leaf_clk),
    .D(net13),
    .Q(\A_reg[6] ));
 sky130_fd_sc_hd__dfxtp_1 _643_ (.CLK(clknet_3_5__leaf_clk),
    .D(net14),
    .Q(\A_reg[7] ));
 sky130_fd_sc_hd__dfxtp_1 _644_ (.CLK(clknet_3_5__leaf_clk),
    .D(net15),
    .Q(\A_reg[8] ));
 sky130_fd_sc_hd__dfxtp_1 _645_ (.CLK(clknet_3_1__leaf_clk),
    .D(net16),
    .Q(\A_reg[9] ));
 sky130_fd_sc_hd__dfxtp_1 _646_ (.CLK(clknet_3_0__leaf_clk),
    .D(net2),
    .Q(\A_reg[10] ));
 sky130_fd_sc_hd__dfxtp_1 _647_ (.CLK(clknet_3_0__leaf_clk),
    .D(net3),
    .Q(\A_reg[11] ));
 sky130_fd_sc_hd__dfxtp_1 _648_ (.CLK(clknet_3_0__leaf_clk),
    .D(net4),
    .Q(\A_reg[12] ));
 sky130_fd_sc_hd__dfxtp_1 _649_ (.CLK(clknet_3_2__leaf_clk),
    .D(net5),
    .Q(\A_reg[13] ));
 sky130_fd_sc_hd__dfxtp_1 _650_ (.CLK(clknet_3_3__leaf_clk),
    .D(net6),
    .Q(\A_reg[14] ));
 sky130_fd_sc_hd__dfxtp_2 _651_ (.CLK(clknet_3_6__leaf_clk),
    .D(net7),
    .Q(\A_reg[15] ));
 sky130_fd_sc_hd__dfxtp_1 _652_ (.CLK(clknet_3_5__leaf_clk),
    .D(net17),
    .Q(\B_reg[0] ));
 sky130_fd_sc_hd__dfxtp_1 _653_ (.CLK(clknet_3_3__leaf_clk),
    .D(net24),
    .Q(\B_reg[1] ));
 sky130_fd_sc_hd__dfxtp_1 _654_ (.CLK(clknet_3_5__leaf_clk),
    .D(net25),
    .Q(\B_reg[2] ));
 sky130_fd_sc_hd__dfxtp_1 _655_ (.CLK(clknet_3_0__leaf_clk),
    .D(net26),
    .Q(\B_reg[3] ));
 sky130_fd_sc_hd__dfxtp_1 _656_ (.CLK(clknet_3_0__leaf_clk),
    .D(net27),
    .Q(\B_reg[4] ));
 sky130_fd_sc_hd__dfxtp_1 _657_ (.CLK(clknet_3_1__leaf_clk),
    .D(net28),
    .Q(\B_reg[5] ));
 sky130_fd_sc_hd__dfxtp_1 _658_ (.CLK(clknet_3_4__leaf_clk),
    .D(net29),
    .Q(\B_reg[6] ));
 sky130_fd_sc_hd__dfxtp_1 _659_ (.CLK(clknet_3_4__leaf_clk),
    .D(net30),
    .Q(\B_reg[7] ));
 sky130_fd_sc_hd__dfxtp_1 _660_ (.CLK(clknet_3_5__leaf_clk),
    .D(net31),
    .Q(\B_reg[8] ));
 sky130_fd_sc_hd__dfxtp_1 _661_ (.CLK(clknet_3_1__leaf_clk),
    .D(net32),
    .Q(\B_reg[9] ));
 sky130_fd_sc_hd__dfxtp_1 _662_ (.CLK(clknet_3_0__leaf_clk),
    .D(net18),
    .Q(\B_reg[10] ));
 sky130_fd_sc_hd__dfxtp_1 _663_ (.CLK(clknet_3_0__leaf_clk),
    .D(net19),
    .Q(\B_reg[11] ));
 sky130_fd_sc_hd__dfxtp_1 _664_ (.CLK(clknet_3_2__leaf_clk),
    .D(net20),
    .Q(\B_reg[12] ));
 sky130_fd_sc_hd__dfxtp_1 _665_ (.CLK(clknet_3_2__leaf_clk),
    .D(net21),
    .Q(\B_reg[13] ));
 sky130_fd_sc_hd__dfxtp_1 _666_ (.CLK(clknet_3_3__leaf_clk),
    .D(net22),
    .Q(\B_reg[14] ));
 sky130_fd_sc_hd__dfxtp_1 _667_ (.CLK(clknet_3_7__leaf_clk),
    .D(net23),
    .Q(\B_reg[15] ));
 sky130_fd_sc_hd__dfxtp_1 _668_ (.CLK(clknet_3_6__leaf_clk),
    .D(_001_),
    .Q(op_add));
 sky130_fd_sc_hd__dfxtp_1 _669_ (.CLK(clknet_3_2__leaf_clk),
    .D(_007_),
    .Q(is_sub));
 sky130_fd_sc_hd__dfxtp_1 _670_ (.CLK(clknet_3_2__leaf_clk),
    .D(_002_),
    .Q(op_and));
 sky130_fd_sc_hd__dfxtp_1 _671_ (.CLK(clknet_3_2__leaf_clk),
    .D(_004_),
    .Q(op_or));
 sky130_fd_sc_hd__dfxtp_1 _672_ (.CLK(clknet_3_2__leaf_clk),
    .D(_008_),
    .Q(op_xor));
 sky130_fd_sc_hd__dfxtp_1 _673_ (.CLK(clknet_3_3__leaf_clk),
    .D(_003_),
    .Q(op_not));
 sky130_fd_sc_hd__dfxtp_1 _674_ (.CLK(clknet_3_3__leaf_clk),
    .D(_005_),
    .Q(op_sll));
 sky130_fd_sc_hd__dfxtp_1 _675_ (.CLK(clknet_3_3__leaf_clk),
    .D(_006_),
    .Q(op_srl));
 sky130_fd_sc_hd__dfxtp_1 _676_ (.CLK(clknet_3_7__leaf_clk),
    .D(carry_comb),
    .Q(net36));
 sky130_fd_sc_hd__clkbuf_1 _677_ (.A(net37),
    .X(net45));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_0_Right_0 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_1_Right_1 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_2_Right_2 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_3_Right_3 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_4_Right_4 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_5_Right_5 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_6_Right_6 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_7_Right_7 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_8_Right_8 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_9_Right_9 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_10_Right_10 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_11_Right_11 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_12_Right_12 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_13_Right_13 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_14_Right_14 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_15_Right_15 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_16_Right_16 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_17_Right_17 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_18_Right_18 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_19_Right_19 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_20_Right_20 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_21_Right_21 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_22_Right_22 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_23_Right_23 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_24_Right_24 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_25_Right_25 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_Right_26 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_Right_27 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_Right_28 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_Right_29 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_Right_30 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_31_Right_31 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_32_Right_32 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_33_Right_33 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_34_Right_34 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_35_Right_35 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_36_Right_36 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_37_Right_37 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_38_Right_38 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_39_Right_39 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_40_Right_40 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_0_Left_41 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_1_Left_42 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_2_Left_43 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_3_Left_44 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_4_Left_45 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_5_Left_46 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_6_Left_47 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_7_Left_48 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_8_Left_49 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_9_Left_50 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_10_Left_51 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_11_Left_52 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_12_Left_53 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_13_Left_54 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_14_Left_55 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_15_Left_56 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_16_Left_57 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_17_Left_58 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_18_Left_59 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_19_Left_60 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_20_Left_61 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_21_Left_62 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_22_Left_63 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_23_Left_64 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_24_Left_65 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_25_Left_66 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_Left_67 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_Left_68 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_Left_69 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_Left_70 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_Left_71 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_31_Left_72 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_32_Left_73 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_33_Left_74 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_34_Left_75 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_35_Left_76 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_36_Left_77 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_37_Left_78 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_38_Left_79 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_39_Left_80 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_40_Left_81 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_82 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_83 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_84 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_85 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_86 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_87 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_88 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_89 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_90 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_91 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_92 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_93 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_94 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_95 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_96 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_97 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_98 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_99 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_100 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_101 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_102 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_103 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_104 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_105 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_106 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_107 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_108 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_109 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_110 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_111 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_112 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_113 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_114 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_115 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_116 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_117 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_118 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_119 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_120 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_121 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_122 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_123 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_124 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_125 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_126 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_127 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_128 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_129 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_130 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_131 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_132 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_133 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_134 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_135 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_136 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_137 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_138 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_139 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_140 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_141 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_142 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_143 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_144 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_145 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_146 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_147 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_148 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_149 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_150 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_151 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_152 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_153 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_154 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_155 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_156 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_157 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_158 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_159 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_160 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_161 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_162 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_163 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_164 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_165 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_166 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_167 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_168 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_169 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_170 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_171 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_172 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_173 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_174 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_175 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_176 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_177 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_178 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_179 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_180 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_181 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_182 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_183 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_184 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_185 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_186 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_187 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_188 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_189 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_190 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_191 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_192 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_193 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_194 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_195 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_196 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_197 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_198 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_199 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_200 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_201 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_202 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_203 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_204 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_205 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_206 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_207 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_208 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_209 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_210 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_211 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_212 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_213 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_214 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_215 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_216 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_217 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_218 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_219 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_220 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_221 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_222 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_223 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_224 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_225 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_226 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_227 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_228 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_229 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_230 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_231 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_232 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_233 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_234 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_235 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_236 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_237 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_238 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_239 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_240 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_241 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_242 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_243 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_244 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_245 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_246 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_247 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_248 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_249 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_250 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_251 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_252 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_253 ();
 sky130_fd_sc_hd__clkbuf_1 input1 (.A(A[0]),
    .X(net1));
 sky130_fd_sc_hd__clkbuf_1 input2 (.A(A[10]),
    .X(net2));
 sky130_fd_sc_hd__clkbuf_1 input3 (.A(A[11]),
    .X(net3));
 sky130_fd_sc_hd__clkbuf_1 input4 (.A(A[12]),
    .X(net4));
 sky130_fd_sc_hd__clkbuf_1 input5 (.A(A[13]),
    .X(net5));
 sky130_fd_sc_hd__clkbuf_1 input6 (.A(A[14]),
    .X(net6));
 sky130_fd_sc_hd__clkbuf_1 input7 (.A(A[15]),
    .X(net7));
 sky130_fd_sc_hd__clkbuf_1 input8 (.A(A[1]),
    .X(net8));
 sky130_fd_sc_hd__clkbuf_1 input9 (.A(A[2]),
    .X(net9));
 sky130_fd_sc_hd__clkbuf_1 input10 (.A(A[3]),
    .X(net10));
 sky130_fd_sc_hd__clkbuf_1 input11 (.A(A[4]),
    .X(net11));
 sky130_fd_sc_hd__clkbuf_1 input12 (.A(A[5]),
    .X(net12));
 sky130_fd_sc_hd__clkbuf_1 input13 (.A(A[6]),
    .X(net13));
 sky130_fd_sc_hd__clkbuf_1 input14 (.A(A[7]),
    .X(net14));
 sky130_fd_sc_hd__clkbuf_1 input15 (.A(A[8]),
    .X(net15));
 sky130_fd_sc_hd__clkbuf_1 input16 (.A(A[9]),
    .X(net16));
 sky130_fd_sc_hd__clkbuf_1 input17 (.A(B[0]),
    .X(net17));
 sky130_fd_sc_hd__clkbuf_1 input18 (.A(B[10]),
    .X(net18));
 sky130_fd_sc_hd__clkbuf_1 input19 (.A(B[11]),
    .X(net19));
 sky130_fd_sc_hd__clkbuf_1 input20 (.A(B[12]),
    .X(net20));
 sky130_fd_sc_hd__clkbuf_1 input21 (.A(B[13]),
    .X(net21));
 sky130_fd_sc_hd__clkbuf_1 input22 (.A(B[14]),
    .X(net22));
 sky130_fd_sc_hd__clkbuf_1 input23 (.A(B[15]),
    .X(net23));
 sky130_fd_sc_hd__clkbuf_1 input24 (.A(B[1]),
    .X(net24));
 sky130_fd_sc_hd__clkbuf_1 input25 (.A(B[2]),
    .X(net25));
 sky130_fd_sc_hd__clkbuf_1 input26 (.A(B[3]),
    .X(net26));
 sky130_fd_sc_hd__clkbuf_1 input27 (.A(B[4]),
    .X(net27));
 sky130_fd_sc_hd__clkbuf_1 input28 (.A(B[5]),
    .X(net28));
 sky130_fd_sc_hd__clkbuf_1 input29 (.A(B[6]),
    .X(net29));
 sky130_fd_sc_hd__clkbuf_1 input30 (.A(B[7]),
    .X(net30));
 sky130_fd_sc_hd__clkbuf_1 input31 (.A(B[8]),
    .X(net31));
 sky130_fd_sc_hd__clkbuf_1 input32 (.A(B[9]),
    .X(net32));
 sky130_fd_sc_hd__clkbuf_2 input33 (.A(opcode[0]),
    .X(net33));
 sky130_fd_sc_hd__clkbuf_2 input34 (.A(opcode[1]),
    .X(net34));
 sky130_fd_sc_hd__clkbuf_2 input35 (.A(opcode[2]),
    .X(net35));
 sky130_fd_sc_hd__buf_2 output36 (.A(net36),
    .X(C));
 sky130_fd_sc_hd__buf_2 output37 (.A(net37),
    .X(N));
 sky130_fd_sc_hd__buf_2 output38 (.A(net38),
    .X(V));
 sky130_fd_sc_hd__buf_2 output39 (.A(net39),
    .X(Y[0]));
 sky130_fd_sc_hd__buf_2 output40 (.A(net40),
    .X(Y[10]));
 sky130_fd_sc_hd__buf_2 output41 (.A(net41),
    .X(Y[11]));
 sky130_fd_sc_hd__buf_2 output42 (.A(net42),
    .X(Y[12]));
 sky130_fd_sc_hd__buf_2 output43 (.A(net43),
    .X(Y[13]));
 sky130_fd_sc_hd__buf_2 output44 (.A(net44),
    .X(Y[14]));
 sky130_fd_sc_hd__buf_2 output45 (.A(net45),
    .X(Y[15]));
 sky130_fd_sc_hd__buf_2 output46 (.A(net46),
    .X(Y[1]));
 sky130_fd_sc_hd__buf_2 output47 (.A(net47),
    .X(Y[2]));
 sky130_fd_sc_hd__buf_2 output48 (.A(net48),
    .X(Y[3]));
 sky130_fd_sc_hd__buf_2 output49 (.A(net49),
    .X(Y[4]));
 sky130_fd_sc_hd__buf_2 output50 (.A(net50),
    .X(Y[5]));
 sky130_fd_sc_hd__buf_2 output51 (.A(net51),
    .X(Y[6]));
 sky130_fd_sc_hd__buf_2 output52 (.A(net52),
    .X(Y[7]));
 sky130_fd_sc_hd__buf_2 output53 (.A(net53),
    .X(Y[8]));
 sky130_fd_sc_hd__buf_2 output54 (.A(net54),
    .X(Y[9]));
 sky130_fd_sc_hd__buf_2 output55 (.A(net55),
    .X(Z));
 sky130_fd_sc_hd__buf_2 fanout56 (.A(net57),
    .X(net56));
 sky130_fd_sc_hd__buf_2 fanout57 (.A(_043_),
    .X(net57));
 sky130_fd_sc_hd__buf_2 fanout58 (.A(_042_),
    .X(net58));
 sky130_fd_sc_hd__buf_2 fanout59 (.A(_276_),
    .X(net59));
 sky130_fd_sc_hd__clkbuf_2 fanout60 (.A(_276_),
    .X(net60));
 sky130_fd_sc_hd__clkbuf_4 fanout61 (.A(_273_),
    .X(net61));
 sky130_fd_sc_hd__clkbuf_2 fanout62 (.A(_273_),
    .X(net62));
 sky130_fd_sc_hd__clkbuf_4 fanout63 (.A(_272_),
    .X(net63));
 sky130_fd_sc_hd__buf_2 fanout64 (.A(op_sll),
    .X(net64));
 sky130_fd_sc_hd__clkbuf_2 fanout65 (.A(op_sll),
    .X(net65));
 sky130_fd_sc_hd__clkbuf_4 fanout66 (.A(op_sll),
    .X(net66));
 sky130_fd_sc_hd__buf_2 fanout67 (.A(op_xor),
    .X(net67));
 sky130_fd_sc_hd__clkbuf_2 fanout68 (.A(op_xor),
    .X(net68));
 sky130_fd_sc_hd__clkbuf_4 fanout69 (.A(op_or),
    .X(net69));
 sky130_fd_sc_hd__buf_2 fanout70 (.A(op_or),
    .X(net70));
 sky130_fd_sc_hd__clkbuf_4 fanout71 (.A(op_and),
    .X(net71));
 sky130_fd_sc_hd__clkbuf_2 fanout72 (.A(op_and),
    .X(net72));
 sky130_fd_sc_hd__buf_4 fanout73 (.A(net74),
    .X(net73));
 sky130_fd_sc_hd__buf_4 fanout74 (.A(is_sub),
    .X(net74));
 sky130_fd_sc_hd__buf_2 fanout75 (.A(net76),
    .X(net75));
 sky130_fd_sc_hd__clkbuf_4 fanout76 (.A(\B_reg[3] ),
    .X(net76));
 sky130_fd_sc_hd__buf_2 fanout77 (.A(net79),
    .X(net77));
 sky130_fd_sc_hd__buf_2 fanout78 (.A(net79),
    .X(net78));
 sky130_fd_sc_hd__clkbuf_2 fanout79 (.A(\B_reg[2] ),
    .X(net79));
 sky130_fd_sc_hd__clkbuf_4 fanout80 (.A(net81),
    .X(net80));
 sky130_fd_sc_hd__buf_2 fanout81 (.A(net82),
    .X(net81));
 sky130_fd_sc_hd__clkbuf_2 fanout82 (.A(\B_reg[1] ),
    .X(net82));
 sky130_fd_sc_hd__clkbuf_4 fanout83 (.A(net85),
    .X(net83));
 sky130_fd_sc_hd__clkbuf_2 fanout84 (.A(net85),
    .X(net84));
 sky130_fd_sc_hd__buf_2 fanout85 (.A(\B_reg[0] ),
    .X(net85));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_0_clk (.A(clk),
    .X(clknet_0_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_3_0__f_clk (.A(clknet_0_clk),
    .X(clknet_3_0__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_3_1__f_clk (.A(clknet_0_clk),
    .X(clknet_3_1__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_3_2__f_clk (.A(clknet_0_clk),
    .X(clknet_3_2__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_3_3__f_clk (.A(clknet_0_clk),
    .X(clknet_3_3__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_3_4__f_clk (.A(clknet_0_clk),
    .X(clknet_3_4__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_3_5__f_clk (.A(clknet_0_clk),
    .X(clknet_3_5__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_3_6__f_clk (.A(clknet_0_clk),
    .X(clknet_3_6__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_3_7__f_clk (.A(clknet_0_clk),
    .X(clknet_3_7__leaf_clk));
 sky130_fd_sc_hd__clkinv_2 clkload0 (.A(clknet_3_1__leaf_clk));
 sky130_fd_sc_hd__clkbuf_8 clkload1 (.A(clknet_3_2__leaf_clk));
 sky130_fd_sc_hd__clkbuf_8 clkload2 (.A(clknet_3_3__leaf_clk));
 sky130_fd_sc_hd__bufinv_16 clkload3 (.A(clknet_3_4__leaf_clk));
 sky130_fd_sc_hd__clkinv_2 clkload4 (.A(clknet_3_5__leaf_clk));
 sky130_fd_sc_hd__clkinv_2 clkload5 (.A(clknet_3_6__leaf_clk));
 sky130_fd_sc_hd__bufinv_16 clkload6 (.A(clknet_3_7__leaf_clk));
 sky130_fd_sc_hd__dlygate4sd3_1 hold1 (.A(\A_reg[5] ),
    .X(net86));
endmodule
