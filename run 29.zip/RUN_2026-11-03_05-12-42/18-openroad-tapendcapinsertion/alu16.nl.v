module alu16 (C,
    N,
    V,
    Z,
    clk,
    A,
    B,
    Y,
    opcode);
 output C;
 output N;
 output V;
 output Z;
 input clk;
 input [15:0] A;
 input [15:0] B;
 output [15:0] Y;
 input [2:0] opcode;

 wire \A_reg[0] ;
 wire \A_reg[10] ;
 wire \A_reg[11] ;
 wire \A_reg[12] ;
 wire \A_reg[13] ;
 wire \A_reg[14] ;
 wire \A_reg[15] ;
 wire \A_reg[1] ;
 wire \A_reg[2] ;
 wire \A_reg[3] ;
 wire \A_reg[4] ;
 wire \A_reg[5] ;
 wire \A_reg[6] ;
 wire \A_reg[7] ;
 wire \A_reg[8] ;
 wire \A_reg[9] ;
 wire \B_reg[0] ;
 wire \B_reg[10] ;
 wire \B_reg[11] ;
 wire \B_reg[12] ;
 wire \B_reg[13] ;
 wire \B_reg[14] ;
 wire \B_reg[15] ;
 wire \B_reg[1] ;
 wire \B_reg[2] ;
 wire \B_reg[3] ;
 wire \B_reg[4] ;
 wire \B_reg[5] ;
 wire \B_reg[6] ;
 wire \B_reg[7] ;
 wire \B_reg[8] ;
 wire \B_reg[9] ;
 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _070_;
 wire _071_;
 wire _072_;
 wire _073_;
 wire _074_;
 wire _075_;
 wire _076_;
 wire _077_;
 wire _078_;
 wire _079_;
 wire _080_;
 wire _081_;
 wire _082_;
 wire _083_;
 wire _084_;
 wire _085_;
 wire _086_;
 wire _087_;
 wire _088_;
 wire _089_;
 wire _090_;
 wire _091_;
 wire _092_;
 wire _093_;
 wire _094_;
 wire _095_;
 wire _096_;
 wire _097_;
 wire _098_;
 wire _099_;
 wire _100_;
 wire _101_;
 wire _102_;
 wire _103_;
 wire _104_;
 wire _105_;
 wire _106_;
 wire _107_;
 wire _108_;
 wire _109_;
 wire _110_;
 wire _111_;
 wire _112_;
 wire _113_;
 wire _114_;
 wire _115_;
 wire _116_;
 wire _117_;
 wire _118_;
 wire _119_;
 wire _120_;
 wire _121_;
 wire _122_;
 wire _123_;
 wire _124_;
 wire _125_;
 wire _126_;
 wire _127_;
 wire _128_;
 wire _129_;
 wire _130_;
 wire _131_;
 wire _132_;
 wire _133_;
 wire _134_;
 wire _135_;
 wire _136_;
 wire _137_;
 wire _138_;
 wire _139_;
 wire _140_;
 wire _141_;
 wire _142_;
 wire _143_;
 wire _144_;
 wire _145_;
 wire _146_;
 wire _147_;
 wire _148_;
 wire _149_;
 wire _150_;
 wire _151_;
 wire _152_;
 wire _153_;
 wire _154_;
 wire _155_;
 wire _156_;
 wire _157_;
 wire _158_;
 wire _159_;
 wire _160_;
 wire _161_;
 wire _162_;
 wire _163_;
 wire _164_;
 wire _165_;
 wire _166_;
 wire _167_;
 wire _168_;
 wire _169_;
 wire _170_;
 wire _171_;
 wire _172_;
 wire _173_;
 wire _174_;
 wire _175_;
 wire _176_;
 wire _177_;
 wire _178_;
 wire _179_;
 wire _180_;
 wire _181_;
 wire _182_;
 wire _183_;
 wire _184_;
 wire _185_;
 wire _186_;
 wire _187_;
 wire _188_;
 wire _189_;
 wire _190_;
 wire _191_;
 wire _192_;
 wire _193_;
 wire _194_;
 wire _195_;
 wire _196_;
 wire _197_;
 wire _198_;
 wire _199_;
 wire _200_;
 wire _201_;
 wire _202_;
 wire _203_;
 wire _204_;
 wire _205_;
 wire _206_;
 wire _207_;
 wire _208_;
 wire _209_;
 wire _210_;
 wire _211_;
 wire _212_;
 wire _213_;
 wire _214_;
 wire _215_;
 wire _216_;
 wire _217_;
 wire _218_;
 wire _219_;
 wire _220_;
 wire _221_;
 wire _222_;
 wire _223_;
 wire _224_;
 wire _225_;
 wire _226_;
 wire _227_;
 wire _228_;
 wire _229_;
 wire _230_;
 wire _231_;
 wire _232_;
 wire _233_;
 wire _234_;
 wire _235_;
 wire _236_;
 wire _237_;
 wire _238_;
 wire _239_;
 wire _240_;
 wire _241_;
 wire _242_;
 wire _243_;
 wire _244_;
 wire _245_;
 wire _246_;
 wire _247_;
 wire _248_;
 wire _249_;
 wire _250_;
 wire _251_;
 wire _252_;
 wire _253_;
 wire _254_;
 wire _255_;
 wire _256_;
 wire _257_;
 wire _258_;
 wire _259_;
 wire _260_;
 wire _261_;
 wire _262_;
 wire _263_;
 wire _264_;
 wire _265_;
 wire _266_;
 wire _267_;
 wire _268_;
 wire _269_;
 wire _270_;
 wire _271_;
 wire _272_;
 wire _273_;
 wire _274_;
 wire _275_;
 wire _276_;
 wire _277_;
 wire _278_;
 wire _279_;
 wire _280_;
 wire _281_;
 wire _282_;
 wire _283_;
 wire _284_;
 wire _285_;
 wire _286_;
 wire _287_;
 wire _288_;
 wire _289_;
 wire _290_;
 wire _291_;
 wire _292_;
 wire _293_;
 wire _294_;
 wire _295_;
 wire _296_;
 wire _297_;
 wire _298_;
 wire _299_;
 wire carry_comb;
 wire is_sub;
 wire op_add;
 wire op_and;
 wire op_not;
 wire op_or;
 wire op_sll;
 wire op_srl;
 wire op_xor;
 wire overflow_comb;
 wire \result_comb[0] ;
 wire \result_comb[10] ;
 wire \result_comb[11] ;
 wire \result_comb[12] ;
 wire \result_comb[13] ;
 wire \result_comb[14] ;
 wire \result_comb[15] ;
 wire \result_comb[1] ;
 wire \result_comb[2] ;
 wire \result_comb[3] ;
 wire \result_comb[4] ;
 wire \result_comb[5] ;
 wire \result_comb[6] ;
 wire \result_comb[7] ;
 wire \result_comb[8] ;
 wire \result_comb[9] ;

 sky130_fd_sc_hd__inv_2 _300_ (.A(op_and),
    .Y(_271_));
 sky130_fd_sc_hd__inv_2 _301_ (.A(op_not),
    .Y(_272_));
 sky130_fd_sc_hd__inv_2 _302_ (.A(op_sll),
    .Y(_273_));
 sky130_fd_sc_hd__inv_2 _303_ (.A(\A_reg[15] ),
    .Y(_274_));
 sky130_fd_sc_hd__inv_2 _304_ (.A(\A_reg[1] ),
    .Y(_275_));
 sky130_fd_sc_hd__or2_2 _305_ (.A(op_srl),
    .B(op_sll),
    .X(_276_));
 sky130_fd_sc_hd__or2_2 _306_ (.A(op_sll),
    .B(\A_reg[4] ),
    .X(_277_));
 sky130_fd_sc_hd__o211a_2 _307_ (.A1(_273_),
    .A2(\A_reg[11] ),
    .B1(_276_),
    .C1(_277_),
    .X(_278_));
 sky130_fd_sc_hd__or2_2 _308_ (.A(op_sll),
    .B(\A_reg[5] ),
    .X(_279_));
 sky130_fd_sc_hd__o211a_2 _309_ (.A1(_273_),
    .A2(\A_reg[10] ),
    .B1(_276_),
    .C1(_279_),
    .X(_280_));
 sky130_fd_sc_hd__mux2_1 _310_ (.A0(_278_),
    .A1(_280_),
    .S(\B_reg[0] ),
    .X(_281_));
 sky130_fd_sc_hd__inv_2 _311_ (.A(_281_),
    .Y(_282_));
 sky130_fd_sc_hd__or2_2 _312_ (.A(op_sll),
    .B(\A_reg[6] ),
    .X(_283_));
 sky130_fd_sc_hd__o211a_2 _313_ (.A1(_273_),
    .A2(\A_reg[9] ),
    .B1(_276_),
    .C1(_283_),
    .X(_284_));
 sky130_fd_sc_hd__or2_2 _314_ (.A(op_sll),
    .B(\A_reg[7] ),
    .X(_285_));
 sky130_fd_sc_hd__o211a_2 _315_ (.A1(_273_),
    .A2(\A_reg[8] ),
    .B1(_276_),
    .C1(_285_),
    .X(_286_));
 sky130_fd_sc_hd__mux2_1 _316_ (.A0(_284_),
    .A1(_286_),
    .S(\B_reg[0] ),
    .X(_287_));
 sky130_fd_sc_hd__inv_2 _317_ (.A(_287_),
    .Y(_288_));
 sky130_fd_sc_hd__mux2_1 _318_ (.A0(_281_),
    .A1(_287_),
    .S(\B_reg[1] ),
    .X(_289_));
 sky130_fd_sc_hd__and2_2 _319_ (.A(\B_reg[2] ),
    .B(_289_),
    .X(_290_));
 sky130_fd_sc_hd__mux2_1 _320_ (.A0(\A_reg[2] ),
    .A1(\A_reg[13] ),
    .S(op_sll),
    .X(_291_));
 sky130_fd_sc_hd__nand2_2 _321_ (.A(_276_),
    .B(_291_),
    .Y(_292_));
 sky130_fd_sc_hd__mux2_1 _322_ (.A0(\A_reg[3] ),
    .A1(\A_reg[12] ),
    .S(op_sll),
    .X(_293_));
 sky130_fd_sc_hd__nand2_2 _323_ (.A(_276_),
    .B(_293_),
    .Y(_294_));
 sky130_fd_sc_hd__mux2_1 _324_ (.A0(_292_),
    .A1(_294_),
    .S(\B_reg[0] ),
    .X(_295_));
 sky130_fd_sc_hd__or2_2 _325_ (.A(op_sll),
    .B(\A_reg[1] ),
    .X(_296_));
 sky130_fd_sc_hd__o211a_2 _326_ (.A1(_273_),
    .A2(\A_reg[14] ),
    .B1(_276_),
    .C1(_296_),
    .X(_297_));
 sky130_fd_sc_hd__or2_2 _327_ (.A(\A_reg[0] ),
    .B(op_sll),
    .X(_298_));
 sky130_fd_sc_hd__o211a_2 _328_ (.A1(_273_),
    .A2(\A_reg[15] ),
    .B1(_276_),
    .C1(_298_),
    .X(_299_));
 sky130_fd_sc_hd__mux2_1 _329_ (.A0(_299_),
    .A1(_297_),
    .S(\B_reg[0] ),
    .X(_009_));
 sky130_fd_sc_hd__nor2_2 _330_ (.A(\B_reg[1] ),
    .B(_009_),
    .Y(_010_));
 sky130_fd_sc_hd__a211oi_2 _331_ (.A1(\B_reg[1] ),
    .A2(_295_),
    .B1(_010_),
    .C1(\B_reg[2] ),
    .Y(_011_));
 sky130_fd_sc_hd__mux2_1 _332_ (.A0(\A_reg[8] ),
    .A1(\A_reg[7] ),
    .S(op_sll),
    .X(_012_));
 sky130_fd_sc_hd__nand2_2 _333_ (.A(_276_),
    .B(_012_),
    .Y(_013_));
 sky130_fd_sc_hd__inv_2 _334_ (.A(_013_),
    .Y(_014_));
 sky130_fd_sc_hd__mux2_1 _335_ (.A0(\A_reg[9] ),
    .A1(\A_reg[6] ),
    .S(op_sll),
    .X(_015_));
 sky130_fd_sc_hd__nand2_2 _336_ (.A(_276_),
    .B(_015_),
    .Y(_016_));
 sky130_fd_sc_hd__mux2_1 _337_ (.A0(_013_),
    .A1(_016_),
    .S(\B_reg[0] ),
    .X(_017_));
 sky130_fd_sc_hd__mux2_1 _338_ (.A0(\A_reg[10] ),
    .A1(\A_reg[5] ),
    .S(op_sll),
    .X(_018_));
 sky130_fd_sc_hd__nand2_2 _339_ (.A(_276_),
    .B(_018_),
    .Y(_019_));
 sky130_fd_sc_hd__mux2_1 _340_ (.A0(\A_reg[11] ),
    .A1(\A_reg[4] ),
    .S(op_sll),
    .X(_020_));
 sky130_fd_sc_hd__nand2_2 _341_ (.A(_276_),
    .B(_020_),
    .Y(_021_));
 sky130_fd_sc_hd__mux2_1 _342_ (.A0(_019_),
    .A1(_021_),
    .S(\B_reg[0] ),
    .X(_022_));
 sky130_fd_sc_hd__mux2_1 _343_ (.A0(_017_),
    .A1(_022_),
    .S(\B_reg[1] ),
    .X(_023_));
 sky130_fd_sc_hd__mux2_1 _344_ (.A0(\A_reg[12] ),
    .A1(\A_reg[3] ),
    .S(op_sll),
    .X(_024_));
 sky130_fd_sc_hd__nand2_2 _345_ (.A(_276_),
    .B(_024_),
    .Y(_025_));
 sky130_fd_sc_hd__mux2_1 _346_ (.A0(\A_reg[13] ),
    .A1(\A_reg[2] ),
    .S(op_sll),
    .X(_026_));
 sky130_fd_sc_hd__nand2_2 _347_ (.A(_276_),
    .B(_026_),
    .Y(_027_));
 sky130_fd_sc_hd__mux2_1 _348_ (.A0(_025_),
    .A1(_027_),
    .S(\B_reg[0] ),
    .X(_028_));
 sky130_fd_sc_hd__mux2_1 _349_ (.A0(\A_reg[14] ),
    .A1(\A_reg[1] ),
    .S(op_sll),
    .X(_029_));
 sky130_fd_sc_hd__nand2_2 _350_ (.A(_276_),
    .B(_029_),
    .Y(_030_));
 sky130_fd_sc_hd__mux2_1 _351_ (.A0(\A_reg[15] ),
    .A1(\A_reg[0] ),
    .S(op_sll),
    .X(_031_));
 sky130_fd_sc_hd__nand2_2 _352_ (.A(_276_),
    .B(_031_),
    .Y(_032_));
 sky130_fd_sc_hd__mux2_1 _353_ (.A0(_030_),
    .A1(_032_),
    .S(\B_reg[0] ),
    .X(_033_));
 sky130_fd_sc_hd__mux2_1 _354_ (.A0(_028_),
    .A1(_033_),
    .S(\B_reg[1] ),
    .X(_034_));
 sky130_fd_sc_hd__mux2_1 _355_ (.A0(_023_),
    .A1(_034_),
    .S(\B_reg[2] ),
    .X(_035_));
 sky130_fd_sc_hd__nand2_2 _356_ (.A(\B_reg[3] ),
    .B(_035_),
    .Y(_036_));
 sky130_fd_sc_hd__o311a_2 _357_ (.A1(\B_reg[3] ),
    .A2(_290_),
    .A3(_011_),
    .B1(_036_),
    .C1(_273_),
    .X(_037_));
 sky130_fd_sc_hd__or2_2 _358_ (.A(\B_reg[0] ),
    .B(_032_),
    .X(_038_));
 sky130_fd_sc_hd__or2_2 _359_ (.A(\B_reg[1] ),
    .B(_038_),
    .X(_039_));
 sky130_fd_sc_hd__or2_2 _360_ (.A(\B_reg[2] ),
    .B(_039_),
    .X(_040_));
 sky130_fd_sc_hd__or2_2 _361_ (.A(\B_reg[3] ),
    .B(_273_),
    .X(_041_));
 sky130_fd_sc_hd__nor2_2 _362_ (.A(is_sub),
    .B(op_add),
    .Y(_042_));
 sky130_fd_sc_hd__or2_2 _363_ (.A(is_sub),
    .B(op_add),
    .X(_043_));
 sky130_fd_sc_hd__o2bb2a_2 _364_ (.A1_N(\A_reg[0] ),
    .A2_N(\B_reg[0] ),
    .B1(op_xor),
    .B2(_043_),
    .X(_044_));
 sky130_fd_sc_hd__o22ai_2 _365_ (.A1(\A_reg[0] ),
    .A2(\B_reg[0] ),
    .B1(op_or),
    .B2(_044_),
    .Y(_045_));
 sky130_fd_sc_hd__and3_2 _366_ (.A(\A_reg[0] ),
    .B(\B_reg[0] ),
    .C(op_and),
    .X(_046_));
 sky130_fd_sc_hd__o221a_2 _367_ (.A1(\A_reg[0] ),
    .A2(_272_),
    .B1(_040_),
    .B2(_041_),
    .C1(_045_),
    .X(_047_));
 sky130_fd_sc_hd__or3b_2 _368_ (.A(_037_),
    .B(_046_),
    .C_N(_047_),
    .X(\result_comb[0] ));
 sky130_fd_sc_hd__nand2b_2 _369_ (.A_N(_284_),
    .B(\B_reg[0] ),
    .Y(_048_));
 sky130_fd_sc_hd__o21ai_2 _370_ (.A1(\B_reg[0] ),
    .A2(_280_),
    .B1(_048_),
    .Y(_049_));
 sky130_fd_sc_hd__mux2_1 _371_ (.A0(_286_),
    .A1(_014_),
    .S(\B_reg[0] ),
    .X(_050_));
 sky130_fd_sc_hd__inv_2 _372_ (.A(_050_),
    .Y(_051_));
 sky130_fd_sc_hd__nor2_2 _373_ (.A(\B_reg[0] ),
    .B(_294_),
    .Y(_052_));
 sky130_fd_sc_hd__a21oi_2 _374_ (.A1(\B_reg[0] ),
    .A2(_278_),
    .B1(_052_),
    .Y(_053_));
 sky130_fd_sc_hd__nor2_2 _375_ (.A(\B_reg[0] ),
    .B(_297_),
    .Y(_054_));
 sky130_fd_sc_hd__a21oi_2 _376_ (.A1(\B_reg[0] ),
    .A2(_292_),
    .B1(_054_),
    .Y(_055_));
 sky130_fd_sc_hd__inv_2 _377_ (.A(_055_),
    .Y(_056_));
 sky130_fd_sc_hd__mux4_2 _378_ (.A0(_056_),
    .A1(_053_),
    .A2(_049_),
    .A3(_051_),
    .S0(\B_reg[1] ),
    .S1(\B_reg[2] ),
    .X(_057_));
 sky130_fd_sc_hd__mux2_1 _379_ (.A0(_016_),
    .A1(_019_),
    .S(\B_reg[0] ),
    .X(_058_));
 sky130_fd_sc_hd__inv_2 _380_ (.A(_058_),
    .Y(_059_));
 sky130_fd_sc_hd__mux2_1 _381_ (.A0(_021_),
    .A1(_025_),
    .S(\B_reg[0] ),
    .X(_060_));
 sky130_fd_sc_hd__mux2_1 _382_ (.A0(_027_),
    .A1(_030_),
    .S(\B_reg[0] ),
    .X(_061_));
 sky130_fd_sc_hd__mux2_1 _383_ (.A0(_061_),
    .A1(_038_),
    .S(\B_reg[1] ),
    .X(_062_));
 sky130_fd_sc_hd__mux4_2 _384_ (.A0(_058_),
    .A1(_060_),
    .A2(_061_),
    .A3(_038_),
    .S0(\B_reg[1] ),
    .S1(\B_reg[2] ),
    .X(_063_));
 sky130_fd_sc_hd__mux2_1 _385_ (.A0(_057_),
    .A1(_063_),
    .S(\B_reg[3] ),
    .X(_064_));
 sky130_fd_sc_hd__xor2_2 _386_ (.A(is_sub),
    .B(\B_reg[1] ),
    .X(_065_));
 sky130_fd_sc_hd__xnor2_2 _387_ (.A(_275_),
    .B(_065_),
    .Y(_066_));
 sky130_fd_sc_hd__mux2_1 _388_ (.A0(is_sub),
    .A1(\A_reg[0] ),
    .S(\B_reg[0] ),
    .X(_067_));
 sky130_fd_sc_hd__nand2_2 _389_ (.A(_043_),
    .B(_067_),
    .Y(_068_));
 sky130_fd_sc_hd__mux2_1 _390_ (.A0(_067_),
    .A1(_068_),
    .S(_066_),
    .X(_069_));
 sky130_fd_sc_hd__a21boi_2 _391_ (.A1(\B_reg[1] ),
    .A2(\A_reg[1] ),
    .B1_N(op_xor),
    .Y(_070_));
 sky130_fd_sc_hd__o22a_2 _392_ (.A1(\B_reg[1] ),
    .A2(\A_reg[1] ),
    .B1(_070_),
    .B2(op_or),
    .X(_071_));
 sky130_fd_sc_hd__and3_2 _393_ (.A(op_and),
    .B(\B_reg[1] ),
    .C(\A_reg[1] ),
    .X(_072_));
 sky130_fd_sc_hd__a221o_2 _394_ (.A1(op_not),
    .A2(_275_),
    .B1(_043_),
    .B2(_069_),
    .C1(_072_),
    .X(_073_));
 sky130_fd_sc_hd__or2_2 _395_ (.A(\B_reg[1] ),
    .B(_033_),
    .X(_074_));
 sky130_fd_sc_hd__or2_2 _396_ (.A(\B_reg[2] ),
    .B(_074_),
    .X(_075_));
 sky130_fd_sc_hd__o22a_2 _397_ (.A1(op_sll),
    .A2(_064_),
    .B1(_075_),
    .B2(_041_),
    .X(_076_));
 sky130_fd_sc_hd__or3b_2 _398_ (.A(_071_),
    .B(_073_),
    .C_N(_076_),
    .X(\result_comb[1] ));
 sky130_fd_sc_hd__mux2_1 _399_ (.A0(_288_),
    .A1(_017_),
    .S(\B_reg[1] ),
    .X(_077_));
 sky130_fd_sc_hd__mux2_1 _400_ (.A0(_295_),
    .A1(_282_),
    .S(\B_reg[1] ),
    .X(_078_));
 sky130_fd_sc_hd__mux2_1 _401_ (.A0(_022_),
    .A1(_028_),
    .S(\B_reg[1] ),
    .X(_079_));
 sky130_fd_sc_hd__mux2_1 _402_ (.A0(_079_),
    .A1(_074_),
    .S(\B_reg[2] ),
    .X(_080_));
 sky130_fd_sc_hd__mux4_2 _403_ (.A0(_078_),
    .A1(_079_),
    .A2(_077_),
    .A3(_074_),
    .S0(\B_reg[3] ),
    .S1(\B_reg[2] ),
    .X(_081_));
 sky130_fd_sc_hd__and3_2 _404_ (.A(\A_reg[1] ),
    .B(_043_),
    .C(_065_),
    .X(_082_));
 sky130_fd_sc_hd__a31o_2 _405_ (.A1(_043_),
    .A2(_066_),
    .A3(_067_),
    .B1(_082_),
    .X(_083_));
 sky130_fd_sc_hd__xor2_2 _406_ (.A(is_sub),
    .B(\B_reg[2] ),
    .X(_084_));
 sky130_fd_sc_hd__nand2_2 _407_ (.A(\A_reg[2] ),
    .B(_084_),
    .Y(_085_));
 sky130_fd_sc_hd__or2_2 _408_ (.A(\A_reg[2] ),
    .B(_084_),
    .X(_086_));
 sky130_fd_sc_hd__and3_2 _409_ (.A(_043_),
    .B(_085_),
    .C(_086_),
    .X(_087_));
 sky130_fd_sc_hd__xnor2_2 _410_ (.A(_083_),
    .B(_087_),
    .Y(_088_));
 sky130_fd_sc_hd__nor2_2 _411_ (.A(\B_reg[2] ),
    .B(\A_reg[2] ),
    .Y(_089_));
 sky130_fd_sc_hd__nand2_2 _412_ (.A(\B_reg[2] ),
    .B(\A_reg[2] ),
    .Y(_090_));
 sky130_fd_sc_hd__a21oi_2 _413_ (.A1(op_xor),
    .A2(_090_),
    .B1(op_or),
    .Y(_091_));
 sky130_fd_sc_hd__o221a_2 _414_ (.A1(_271_),
    .A2(_090_),
    .B1(_091_),
    .B2(_089_),
    .C1(_088_),
    .X(_092_));
 sky130_fd_sc_hd__or2_2 _415_ (.A(\B_reg[2] ),
    .B(_062_),
    .X(_093_));
 sky130_fd_sc_hd__o221a_2 _416_ (.A1(_272_),
    .A2(\A_reg[2] ),
    .B1(_041_),
    .B2(_093_),
    .C1(_092_),
    .X(_094_));
 sky130_fd_sc_hd__o21ai_2 _417_ (.A1(op_sll),
    .A2(_081_),
    .B1(_094_),
    .Y(\result_comb[2] ));
 sky130_fd_sc_hd__mux2_1 _418_ (.A0(_053_),
    .A1(_049_),
    .S(\B_reg[1] ),
    .X(_095_));
 sky130_fd_sc_hd__mux2_1 _419_ (.A0(_050_),
    .A1(_059_),
    .S(\B_reg[1] ),
    .X(_096_));
 sky130_fd_sc_hd__mux2_1 _420_ (.A0(_060_),
    .A1(_061_),
    .S(\B_reg[1] ),
    .X(_097_));
 sky130_fd_sc_hd__inv_2 _421_ (.A(_097_),
    .Y(_098_));
 sky130_fd_sc_hd__mux2_1 _422_ (.A0(_097_),
    .A1(_039_),
    .S(\B_reg[2] ),
    .X(_099_));
 sky130_fd_sc_hd__or2_2 _423_ (.A(\B_reg[2] ),
    .B(_095_),
    .X(_100_));
 sky130_fd_sc_hd__a21oi_2 _424_ (.A1(\B_reg[2] ),
    .A2(_096_),
    .B1(\B_reg[3] ),
    .Y(_101_));
 sky130_fd_sc_hd__a22o_2 _425_ (.A1(\B_reg[3] ),
    .A2(_099_),
    .B1(_100_),
    .B2(_101_),
    .X(_102_));
 sky130_fd_sc_hd__a2bb2o_2 _426_ (.A1_N(_042_),
    .A2_N(_085_),
    .B1(_087_),
    .B2(_083_),
    .X(_103_));
 sky130_fd_sc_hd__xor2_2 _427_ (.A(is_sub),
    .B(\B_reg[3] ),
    .X(_104_));
 sky130_fd_sc_hd__nand2_2 _428_ (.A(\A_reg[3] ),
    .B(_104_),
    .Y(_105_));
 sky130_fd_sc_hd__or2_2 _429_ (.A(\A_reg[3] ),
    .B(_104_),
    .X(_106_));
 sky130_fd_sc_hd__and3_2 _430_ (.A(_043_),
    .B(_105_),
    .C(_106_),
    .X(_107_));
 sky130_fd_sc_hd__xnor2_2 _431_ (.A(_103_),
    .B(_107_),
    .Y(_108_));
 sky130_fd_sc_hd__or2_2 _432_ (.A(\B_reg[2] ),
    .B(_034_),
    .X(_109_));
 sky130_fd_sc_hd__nand2_2 _433_ (.A(\B_reg[3] ),
    .B(\A_reg[3] ),
    .Y(_110_));
 sky130_fd_sc_hd__a21o_2 _434_ (.A1(op_xor),
    .A2(_110_),
    .B1(op_or),
    .X(_111_));
 sky130_fd_sc_hd__o21ai_2 _435_ (.A1(\B_reg[3] ),
    .A2(\A_reg[3] ),
    .B1(_111_),
    .Y(_112_));
 sky130_fd_sc_hd__o221a_2 _436_ (.A1(_272_),
    .A2(\A_reg[3] ),
    .B1(_110_),
    .B2(_271_),
    .C1(_112_),
    .X(_113_));
 sky130_fd_sc_hd__o221a_2 _437_ (.A1(op_sll),
    .A2(_102_),
    .B1(_109_),
    .B2(_041_),
    .C1(_113_),
    .X(_114_));
 sky130_fd_sc_hd__nand2_2 _438_ (.A(_108_),
    .B(_114_),
    .Y(\result_comb[3] ));
 sky130_fd_sc_hd__xor2_2 _439_ (.A(is_sub),
    .B(\B_reg[4] ),
    .X(_115_));
 sky130_fd_sc_hd__nand2_2 _440_ (.A(\A_reg[4] ),
    .B(_115_),
    .Y(_116_));
 sky130_fd_sc_hd__or2_2 _441_ (.A(\A_reg[4] ),
    .B(_115_),
    .X(_117_));
 sky130_fd_sc_hd__and3_2 _442_ (.A(_043_),
    .B(_116_),
    .C(_117_),
    .X(_118_));
 sky130_fd_sc_hd__a2bb2o_2 _443_ (.A1_N(_042_),
    .A2_N(_105_),
    .B1(_107_),
    .B2(_103_),
    .X(_119_));
 sky130_fd_sc_hd__nand2_2 _444_ (.A(_118_),
    .B(_119_),
    .Y(_120_));
 sky130_fd_sc_hd__or2_2 _445_ (.A(_118_),
    .B(_119_),
    .X(_121_));
 sky130_fd_sc_hd__nor2_2 _446_ (.A(_041_),
    .B(_099_),
    .Y(_122_));
 sky130_fd_sc_hd__a21boi_2 _447_ (.A1(\A_reg[4] ),
    .A2(\B_reg[4] ),
    .B1_N(op_xor),
    .Y(_123_));
 sky130_fd_sc_hd__o22a_2 _448_ (.A1(\A_reg[4] ),
    .A2(\B_reg[4] ),
    .B1(_123_),
    .B2(op_or),
    .X(_124_));
 sky130_fd_sc_hd__nor2_2 _449_ (.A(\B_reg[2] ),
    .B(_289_),
    .Y(_125_));
 sky130_fd_sc_hd__a21o_2 _450_ (.A1(\B_reg[2] ),
    .A2(_023_),
    .B1(_125_),
    .X(_126_));
 sky130_fd_sc_hd__mux2_1 _451_ (.A0(_126_),
    .A1(_109_),
    .S(\B_reg[3] ),
    .X(_127_));
 sky130_fd_sc_hd__a31o_2 _452_ (.A1(op_and),
    .A2(\A_reg[4] ),
    .A3(\B_reg[4] ),
    .B1(_124_),
    .X(_128_));
 sky130_fd_sc_hd__a211o_2 _453_ (.A1(_120_),
    .A2(_121_),
    .B1(_122_),
    .C1(_128_),
    .X(_129_));
 sky130_fd_sc_hd__o22ai_2 _454_ (.A1(_272_),
    .A2(\A_reg[4] ),
    .B1(_127_),
    .B2(op_sll),
    .Y(_130_));
 sky130_fd_sc_hd__or2_2 _455_ (.A(_129_),
    .B(_130_),
    .X(\result_comb[4] ));
 sky130_fd_sc_hd__xor2_2 _456_ (.A(is_sub),
    .B(\B_reg[5] ),
    .X(_131_));
 sky130_fd_sc_hd__nand2_2 _457_ (.A(\A_reg[5] ),
    .B(_131_),
    .Y(_132_));
 sky130_fd_sc_hd__or2_2 _458_ (.A(\A_reg[5] ),
    .B(_131_),
    .X(_133_));
 sky130_fd_sc_hd__and3_2 _459_ (.A(_043_),
    .B(_132_),
    .C(_133_),
    .X(_134_));
 sky130_fd_sc_hd__a2bb2o_2 _460_ (.A1_N(_042_),
    .A2_N(_116_),
    .B1(_118_),
    .B2(_119_),
    .X(_135_));
 sky130_fd_sc_hd__xnor2_2 _461_ (.A(_134_),
    .B(_135_),
    .Y(_136_));
 sky130_fd_sc_hd__a21boi_2 _462_ (.A1(\A_reg[5] ),
    .A2(\B_reg[5] ),
    .B1_N(op_xor),
    .Y(_137_));
 sky130_fd_sc_hd__o22a_2 _463_ (.A1(\A_reg[5] ),
    .A2(\B_reg[5] ),
    .B1(_137_),
    .B2(op_or),
    .X(_138_));
 sky130_fd_sc_hd__mux4_2 _464_ (.A0(_049_),
    .A1(_051_),
    .A2(_058_),
    .A3(_060_),
    .S0(\B_reg[1] ),
    .S1(\B_reg[2] ),
    .X(_139_));
 sky130_fd_sc_hd__mux2_1 _465_ (.A0(_139_),
    .A1(_093_),
    .S(\B_reg[3] ),
    .X(_140_));
 sky130_fd_sc_hd__a31oi_2 _466_ (.A1(op_and),
    .A2(\A_reg[5] ),
    .A3(\B_reg[5] ),
    .B1(_138_),
    .Y(_141_));
 sky130_fd_sc_hd__o221a_2 _467_ (.A1(_041_),
    .A2(_080_),
    .B1(_140_),
    .B2(op_sll),
    .C1(_141_),
    .X(_142_));
 sky130_fd_sc_hd__o211ai_2 _468_ (.A1(_272_),
    .A2(\A_reg[5] ),
    .B1(_136_),
    .C1(_142_),
    .Y(\result_comb[5] ));
 sky130_fd_sc_hd__xor2_2 _469_ (.A(is_sub),
    .B(\B_reg[6] ),
    .X(_143_));
 sky130_fd_sc_hd__nand2_2 _470_ (.A(\A_reg[6] ),
    .B(_143_),
    .Y(_144_));
 sky130_fd_sc_hd__or2_2 _471_ (.A(\A_reg[6] ),
    .B(_143_),
    .X(_145_));
 sky130_fd_sc_hd__and3_2 _472_ (.A(_043_),
    .B(_144_),
    .C(_145_),
    .X(_146_));
 sky130_fd_sc_hd__a2bb2o_2 _473_ (.A1_N(_042_),
    .A2_N(_132_),
    .B1(_134_),
    .B2(_135_),
    .X(_147_));
 sky130_fd_sc_hd__xor2_2 _474_ (.A(_146_),
    .B(_147_),
    .X(_148_));
 sky130_fd_sc_hd__a21boi_2 _475_ (.A1(\A_reg[6] ),
    .A2(\B_reg[6] ),
    .B1_N(op_xor),
    .Y(_149_));
 sky130_fd_sc_hd__o22a_2 _476_ (.A1(\A_reg[6] ),
    .A2(\B_reg[6] ),
    .B1(_149_),
    .B2(op_or),
    .X(_150_));
 sky130_fd_sc_hd__nand3_2 _477_ (.A(op_and),
    .B(\A_reg[6] ),
    .C(\B_reg[6] ),
    .Y(_151_));
 sky130_fd_sc_hd__o221a_2 _478_ (.A1(_272_),
    .A2(\A_reg[6] ),
    .B1(_041_),
    .B2(_063_),
    .C1(_151_),
    .X(_152_));
 sky130_fd_sc_hd__mux2_1 _479_ (.A0(_077_),
    .A1(_079_),
    .S(\B_reg[2] ),
    .X(_153_));
 sky130_fd_sc_hd__mux2_1 _480_ (.A0(_153_),
    .A1(_075_),
    .S(\B_reg[3] ),
    .X(_154_));
 sky130_fd_sc_hd__nor2_2 _481_ (.A(op_sll),
    .B(_154_),
    .Y(_155_));
 sky130_fd_sc_hd__or4b_2 _482_ (.A(_148_),
    .B(_150_),
    .C(_155_),
    .D_N(_152_),
    .X(\result_comb[6] ));
 sky130_fd_sc_hd__xor2_2 _483_ (.A(is_sub),
    .B(\B_reg[7] ),
    .X(_156_));
 sky130_fd_sc_hd__nand2_2 _484_ (.A(\A_reg[7] ),
    .B(_156_),
    .Y(_157_));
 sky130_fd_sc_hd__or2_2 _485_ (.A(\A_reg[7] ),
    .B(_156_),
    .X(_158_));
 sky130_fd_sc_hd__and3_2 _486_ (.A(_043_),
    .B(_157_),
    .C(_158_),
    .X(_159_));
 sky130_fd_sc_hd__a2bb2o_2 _487_ (.A1_N(_042_),
    .A2_N(_144_),
    .B1(_146_),
    .B2(_147_),
    .X(_160_));
 sky130_fd_sc_hd__xor2_2 _488_ (.A(_159_),
    .B(_160_),
    .X(_161_));
 sky130_fd_sc_hd__a21boi_2 _489_ (.A1(\A_reg[7] ),
    .A2(\B_reg[7] ),
    .B1_N(op_xor),
    .Y(_162_));
 sky130_fd_sc_hd__o22a_2 _490_ (.A1(\A_reg[7] ),
    .A2(\B_reg[7] ),
    .B1(_162_),
    .B2(op_or),
    .X(_163_));
 sky130_fd_sc_hd__nand3_2 _491_ (.A(op_and),
    .B(\A_reg[7] ),
    .C(\B_reg[7] ),
    .Y(_164_));
 sky130_fd_sc_hd__o221a_2 _492_ (.A1(_272_),
    .A2(\A_reg[7] ),
    .B1(_035_),
    .B2(_041_),
    .C1(_164_),
    .X(_165_));
 sky130_fd_sc_hd__mux2_1 _493_ (.A0(_096_),
    .A1(_098_),
    .S(\B_reg[2] ),
    .X(_166_));
 sky130_fd_sc_hd__nor2_2 _494_ (.A(\B_reg[3] ),
    .B(_166_),
    .Y(_167_));
 sky130_fd_sc_hd__a211oi_2 _495_ (.A1(\B_reg[3] ),
    .A2(_040_),
    .B1(_167_),
    .C1(op_sll),
    .Y(_168_));
 sky130_fd_sc_hd__or4b_2 _496_ (.A(_161_),
    .B(_163_),
    .C(_168_),
    .D_N(_165_),
    .X(\result_comb[7] ));
 sky130_fd_sc_hd__xor2_2 _497_ (.A(is_sub),
    .B(\B_reg[8] ),
    .X(_169_));
 sky130_fd_sc_hd__nand2_2 _498_ (.A(\A_reg[8] ),
    .B(_169_),
    .Y(_170_));
 sky130_fd_sc_hd__or2_2 _499_ (.A(\A_reg[8] ),
    .B(_169_),
    .X(_171_));
 sky130_fd_sc_hd__and3_2 _500_ (.A(_043_),
    .B(_170_),
    .C(_171_),
    .X(_172_));
 sky130_fd_sc_hd__a2bb2o_2 _501_ (.A1_N(_042_),
    .A2_N(_157_),
    .B1(_159_),
    .B2(_160_),
    .X(_173_));
 sky130_fd_sc_hd__xor2_2 _502_ (.A(_172_),
    .B(_173_),
    .X(_174_));
 sky130_fd_sc_hd__or2_2 _503_ (.A(\B_reg[3] ),
    .B(op_sll),
    .X(_175_));
 sky130_fd_sc_hd__a21boi_2 _504_ (.A1(\A_reg[8] ),
    .A2(\B_reg[8] ),
    .B1_N(op_xor),
    .Y(_176_));
 sky130_fd_sc_hd__o22a_2 _505_ (.A1(\A_reg[8] ),
    .A2(\B_reg[8] ),
    .B1(_176_),
    .B2(op_or),
    .X(_177_));
 sky130_fd_sc_hd__nand3_2 _506_ (.A(op_and),
    .B(\A_reg[8] ),
    .C(\B_reg[8] ),
    .Y(_178_));
 sky130_fd_sc_hd__o221a_2 _507_ (.A1(_272_),
    .A2(\A_reg[8] ),
    .B1(_035_),
    .B2(_175_),
    .C1(_178_),
    .X(_179_));
 sky130_fd_sc_hd__a211oi_2 _508_ (.A1(\B_reg[3] ),
    .A2(_040_),
    .B1(_167_),
    .C1(_273_),
    .Y(_180_));
 sky130_fd_sc_hd__or4b_2 _509_ (.A(_174_),
    .B(_177_),
    .C(_180_),
    .D_N(_179_),
    .X(\result_comb[8] ));
 sky130_fd_sc_hd__xor2_2 _510_ (.A(is_sub),
    .B(\B_reg[9] ),
    .X(_181_));
 sky130_fd_sc_hd__nand2_2 _511_ (.A(\A_reg[9] ),
    .B(_181_),
    .Y(_182_));
 sky130_fd_sc_hd__or2_2 _512_ (.A(\A_reg[9] ),
    .B(_181_),
    .X(_183_));
 sky130_fd_sc_hd__and3_2 _513_ (.A(_043_),
    .B(_182_),
    .C(_183_),
    .X(_184_));
 sky130_fd_sc_hd__a2bb2o_2 _514_ (.A1_N(_042_),
    .A2_N(_170_),
    .B1(_172_),
    .B2(_173_),
    .X(_185_));
 sky130_fd_sc_hd__and2_2 _515_ (.A(_184_),
    .B(_185_),
    .X(_186_));
 sky130_fd_sc_hd__nor2_2 _516_ (.A(_184_),
    .B(_185_),
    .Y(_187_));
 sky130_fd_sc_hd__a21boi_2 _517_ (.A1(\A_reg[9] ),
    .A2(\B_reg[9] ),
    .B1_N(op_xor),
    .Y(_188_));
 sky130_fd_sc_hd__o22ai_2 _518_ (.A1(\A_reg[9] ),
    .A2(\B_reg[9] ),
    .B1(_188_),
    .B2(op_or),
    .Y(_189_));
 sky130_fd_sc_hd__o221a_2 _519_ (.A1(_272_),
    .A2(\A_reg[9] ),
    .B1(_063_),
    .B2(_175_),
    .C1(_189_),
    .X(_190_));
 sky130_fd_sc_hd__o221ai_2 _520_ (.A1(_273_),
    .A2(_154_),
    .B1(_186_),
    .B2(_187_),
    .C1(_190_),
    .Y(_191_));
 sky130_fd_sc_hd__a31o_2 _521_ (.A1(op_and),
    .A2(\A_reg[9] ),
    .A3(\B_reg[9] ),
    .B1(_191_),
    .X(\result_comb[9] ));
 sky130_fd_sc_hd__xor2_2 _522_ (.A(is_sub),
    .B(\B_reg[10] ),
    .X(_192_));
 sky130_fd_sc_hd__nand2_2 _523_ (.A(\A_reg[10] ),
    .B(_192_),
    .Y(_193_));
 sky130_fd_sc_hd__or2_2 _524_ (.A(\A_reg[10] ),
    .B(_192_),
    .X(_194_));
 sky130_fd_sc_hd__and3_2 _525_ (.A(_043_),
    .B(_193_),
    .C(_194_),
    .X(_195_));
 sky130_fd_sc_hd__a2bb2o_2 _526_ (.A1_N(_042_),
    .A2_N(_182_),
    .B1(_184_),
    .B2(_185_),
    .X(_196_));
 sky130_fd_sc_hd__and2_2 _527_ (.A(_195_),
    .B(_196_),
    .X(_197_));
 sky130_fd_sc_hd__nor2_2 _528_ (.A(_195_),
    .B(_196_),
    .Y(_198_));
 sky130_fd_sc_hd__a21boi_2 _529_ (.A1(\A_reg[10] ),
    .A2(\B_reg[10] ),
    .B1_N(op_xor),
    .Y(_199_));
 sky130_fd_sc_hd__o22ai_2 _530_ (.A1(\A_reg[10] ),
    .A2(\B_reg[10] ),
    .B1(_199_),
    .B2(op_or),
    .Y(_200_));
 sky130_fd_sc_hd__o221a_2 _531_ (.A1(_272_),
    .A2(\A_reg[10] ),
    .B1(_080_),
    .B2(_175_),
    .C1(_200_),
    .X(_201_));
 sky130_fd_sc_hd__o221ai_2 _532_ (.A1(_273_),
    .A2(_140_),
    .B1(_197_),
    .B2(_198_),
    .C1(_201_),
    .Y(_202_));
 sky130_fd_sc_hd__a31o_2 _533_ (.A1(op_and),
    .A2(\A_reg[10] ),
    .A3(\B_reg[10] ),
    .B1(_202_),
    .X(\result_comb[10] ));
 sky130_fd_sc_hd__xor2_2 _534_ (.A(is_sub),
    .B(\B_reg[11] ),
    .X(_203_));
 sky130_fd_sc_hd__nand2_2 _535_ (.A(\A_reg[11] ),
    .B(_203_),
    .Y(_204_));
 sky130_fd_sc_hd__or2_2 _536_ (.A(\A_reg[11] ),
    .B(_203_),
    .X(_205_));
 sky130_fd_sc_hd__and3_2 _537_ (.A(_043_),
    .B(_204_),
    .C(_205_),
    .X(_206_));
 sky130_fd_sc_hd__a2bb2o_2 _538_ (.A1_N(_042_),
    .A2_N(_193_),
    .B1(_195_),
    .B2(_196_),
    .X(_207_));
 sky130_fd_sc_hd__xor2_2 _539_ (.A(_206_),
    .B(_207_),
    .X(_208_));
 sky130_fd_sc_hd__a21boi_2 _540_ (.A1(\A_reg[11] ),
    .A2(\B_reg[11] ),
    .B1_N(op_xor),
    .Y(_209_));
 sky130_fd_sc_hd__o22a_2 _541_ (.A1(\A_reg[11] ),
    .A2(\B_reg[11] ),
    .B1(_209_),
    .B2(op_or),
    .X(_210_));
 sky130_fd_sc_hd__nand3_2 _542_ (.A(op_and),
    .B(\A_reg[11] ),
    .C(\B_reg[11] ),
    .Y(_211_));
 sky130_fd_sc_hd__o221a_2 _543_ (.A1(_272_),
    .A2(\A_reg[11] ),
    .B1(_099_),
    .B2(_175_),
    .C1(_211_),
    .X(_212_));
 sky130_fd_sc_hd__nor2_2 _544_ (.A(_273_),
    .B(_127_),
    .Y(_213_));
 sky130_fd_sc_hd__or4b_2 _545_ (.A(_208_),
    .B(_210_),
    .C(_213_),
    .D_N(_212_),
    .X(\result_comb[11] ));
 sky130_fd_sc_hd__xor2_2 _546_ (.A(is_sub),
    .B(\B_reg[12] ),
    .X(_214_));
 sky130_fd_sc_hd__nand2_2 _547_ (.A(\A_reg[12] ),
    .B(_214_),
    .Y(_215_));
 sky130_fd_sc_hd__or2_2 _548_ (.A(\A_reg[12] ),
    .B(_214_),
    .X(_216_));
 sky130_fd_sc_hd__and3_2 _549_ (.A(_043_),
    .B(_215_),
    .C(_216_),
    .X(_217_));
 sky130_fd_sc_hd__a2bb2o_2 _550_ (.A1_N(_042_),
    .A2_N(_204_),
    .B1(_206_),
    .B2(_207_),
    .X(_218_));
 sky130_fd_sc_hd__xor2_2 _551_ (.A(_217_),
    .B(_218_),
    .X(_219_));
 sky130_fd_sc_hd__a21boi_2 _552_ (.A1(\A_reg[12] ),
    .A2(\B_reg[12] ),
    .B1_N(op_xor),
    .Y(_220_));
 sky130_fd_sc_hd__o22a_2 _553_ (.A1(\A_reg[12] ),
    .A2(\B_reg[12] ),
    .B1(_220_),
    .B2(op_or),
    .X(_221_));
 sky130_fd_sc_hd__a31o_2 _554_ (.A1(op_and),
    .A2(\A_reg[12] ),
    .A3(\B_reg[12] ),
    .B1(_221_),
    .X(_222_));
 sky130_fd_sc_hd__o22a_2 _555_ (.A1(_272_),
    .A2(\A_reg[12] ),
    .B1(_109_),
    .B2(_175_),
    .X(_223_));
 sky130_fd_sc_hd__nor2_2 _556_ (.A(_273_),
    .B(_102_),
    .Y(_224_));
 sky130_fd_sc_hd__or4b_2 _557_ (.A(_219_),
    .B(_222_),
    .C(_224_),
    .D_N(_223_),
    .X(\result_comb[12] ));
 sky130_fd_sc_hd__xor2_2 _558_ (.A(is_sub),
    .B(\B_reg[13] ),
    .X(_225_));
 sky130_fd_sc_hd__nand2_2 _559_ (.A(\A_reg[13] ),
    .B(_225_),
    .Y(_226_));
 sky130_fd_sc_hd__or2_2 _560_ (.A(\A_reg[13] ),
    .B(_225_),
    .X(_227_));
 sky130_fd_sc_hd__and3_2 _561_ (.A(_043_),
    .B(_226_),
    .C(_227_),
    .X(_228_));
 sky130_fd_sc_hd__a2bb2o_2 _562_ (.A1_N(_042_),
    .A2_N(_215_),
    .B1(_217_),
    .B2(_218_),
    .X(_229_));
 sky130_fd_sc_hd__xor2_2 _563_ (.A(_228_),
    .B(_229_),
    .X(_230_));
 sky130_fd_sc_hd__a21boi_2 _564_ (.A1(\A_reg[13] ),
    .A2(\B_reg[13] ),
    .B1_N(op_xor),
    .Y(_231_));
 sky130_fd_sc_hd__o22a_2 _565_ (.A1(\A_reg[13] ),
    .A2(\B_reg[13] ),
    .B1(_231_),
    .B2(op_or),
    .X(_232_));
 sky130_fd_sc_hd__nand3_2 _566_ (.A(op_and),
    .B(\A_reg[13] ),
    .C(\B_reg[13] ),
    .Y(_233_));
 sky130_fd_sc_hd__o221a_2 _567_ (.A1(_272_),
    .A2(\A_reg[13] ),
    .B1(_093_),
    .B2(_175_),
    .C1(_233_),
    .X(_234_));
 sky130_fd_sc_hd__nor2_2 _568_ (.A(_273_),
    .B(_081_),
    .Y(_235_));
 sky130_fd_sc_hd__or4b_2 _569_ (.A(_230_),
    .B(_232_),
    .C(_235_),
    .D_N(_234_),
    .X(\result_comb[13] ));
 sky130_fd_sc_hd__xor2_2 _570_ (.A(is_sub),
    .B(\B_reg[14] ),
    .X(_236_));
 sky130_fd_sc_hd__nand2_2 _571_ (.A(\A_reg[14] ),
    .B(_236_),
    .Y(_237_));
 sky130_fd_sc_hd__or2_2 _572_ (.A(\A_reg[14] ),
    .B(_236_),
    .X(_238_));
 sky130_fd_sc_hd__and3_2 _573_ (.A(_043_),
    .B(_237_),
    .C(_238_),
    .X(_239_));
 sky130_fd_sc_hd__a2bb2o_2 _574_ (.A1_N(_042_),
    .A2_N(_226_),
    .B1(_228_),
    .B2(_229_),
    .X(_240_));
 sky130_fd_sc_hd__xor2_2 _575_ (.A(_239_),
    .B(_240_),
    .X(_241_));
 sky130_fd_sc_hd__a21boi_2 _576_ (.A1(\A_reg[14] ),
    .A2(\B_reg[14] ),
    .B1_N(op_xor),
    .Y(_242_));
 sky130_fd_sc_hd__o22a_2 _577_ (.A1(\A_reg[14] ),
    .A2(\B_reg[14] ),
    .B1(_242_),
    .B2(op_or),
    .X(_243_));
 sky130_fd_sc_hd__nand3_2 _578_ (.A(op_and),
    .B(\A_reg[14] ),
    .C(\B_reg[14] ),
    .Y(_244_));
 sky130_fd_sc_hd__o221a_2 _579_ (.A1(_272_),
    .A2(\A_reg[14] ),
    .B1(_075_),
    .B2(_175_),
    .C1(_244_),
    .X(_245_));
 sky130_fd_sc_hd__nor2_2 _580_ (.A(_273_),
    .B(_064_),
    .Y(_246_));
 sky130_fd_sc_hd__or4b_2 _581_ (.A(_241_),
    .B(_243_),
    .C(_246_),
    .D_N(_245_),
    .X(\result_comb[14] ));
 sky130_fd_sc_hd__o2bb2a_2 _582_ (.A1_N(_239_),
    .A2_N(_240_),
    .B1(_042_),
    .B2(_237_),
    .X(_247_));
 sky130_fd_sc_hd__xor2_2 _583_ (.A(\A_reg[15] ),
    .B(\B_reg[15] ),
    .X(_248_));
 sky130_fd_sc_hd__nand2_2 _584_ (.A(op_add),
    .B(_248_),
    .Y(_249_));
 sky130_fd_sc_hd__mux2_1 _585_ (.A0(_249_),
    .A1(_248_),
    .S(is_sub),
    .X(_250_));
 sky130_fd_sc_hd__nor2_2 _586_ (.A(_247_),
    .B(_250_),
    .Y(_251_));
 sky130_fd_sc_hd__xor2_2 _587_ (.A(_247_),
    .B(_250_),
    .X(_252_));
 sky130_fd_sc_hd__nor2_2 _588_ (.A(_040_),
    .B(_175_),
    .Y(_253_));
 sky130_fd_sc_hd__o21a_2 _589_ (.A1(\A_reg[15] ),
    .A2(\B_reg[15] ),
    .B1(op_or),
    .X(_254_));
 sky130_fd_sc_hd__a31o_2 _590_ (.A1(op_and),
    .A2(\A_reg[15] ),
    .A3(\B_reg[15] ),
    .B1(_254_),
    .X(_255_));
 sky130_fd_sc_hd__a211o_2 _591_ (.A1(op_xor),
    .A2(_248_),
    .B1(_253_),
    .C1(_255_),
    .X(_256_));
 sky130_fd_sc_hd__o311a_2 _592_ (.A1(\B_reg[3] ),
    .A2(_290_),
    .A3(_011_),
    .B1(_036_),
    .C1(op_sll),
    .X(_257_));
 sky130_fd_sc_hd__a2111o_2 _593_ (.A1(op_not),
    .A2(_274_),
    .B1(_252_),
    .C1(_256_),
    .D1(_257_),
    .X(\result_comb[15] ));
 sky130_fd_sc_hd__nor3_2 _594_ (.A(opcode[2]),
    .B(opcode[1]),
    .C(opcode[0]),
    .Y(_001_));
 sky130_fd_sc_hd__nor3b_2 _595_ (.A(opcode[2]),
    .B(opcode[1]),
    .C_N(opcode[0]),
    .Y(_007_));
 sky130_fd_sc_hd__nor3b_2 _596_ (.A(opcode[2]),
    .B(opcode[0]),
    .C_N(opcode[1]),
    .Y(_002_));
 sky130_fd_sc_hd__and3b_2 _597_ (.A_N(opcode[2]),
    .B(opcode[1]),
    .C(opcode[0]),
    .X(_004_));
 sky130_fd_sc_hd__nor3b_2 _598_ (.A(opcode[1]),
    .B(opcode[0]),
    .C_N(opcode[2]),
    .Y(_008_));
 sky130_fd_sc_hd__and3b_2 _599_ (.A_N(opcode[1]),
    .B(opcode[0]),
    .C(opcode[2]),
    .X(_003_));
 sky130_fd_sc_hd__and3b_2 _600_ (.A_N(opcode[0]),
    .B(opcode[1]),
    .C(opcode[2]),
    .X(_005_));
 sky130_fd_sc_hd__and3_2 _601_ (.A(opcode[2]),
    .B(opcode[1]),
    .C(opcode[0]),
    .X(_006_));
 sky130_fd_sc_hd__or4_2 _602_ (.A(\result_comb[0] ),
    .B(\result_comb[1] ),
    .C(\result_comb[2] ),
    .D(\result_comb[3] ),
    .X(_258_));
 sky130_fd_sc_hd__or4_2 _603_ (.A(\result_comb[4] ),
    .B(\result_comb[5] ),
    .C(\result_comb[6] ),
    .D(_258_),
    .X(_259_));
 sky130_fd_sc_hd__or3_2 _604_ (.A(\result_comb[7] ),
    .B(\result_comb[8] ),
    .C(_259_),
    .X(_260_));
 sky130_fd_sc_hd__or4_2 _605_ (.A(\result_comb[9] ),
    .B(\result_comb[10] ),
    .C(\result_comb[11] ),
    .D(_260_),
    .X(_261_));
 sky130_fd_sc_hd__or3_2 _606_ (.A(\result_comb[12] ),
    .B(\result_comb[13] ),
    .C(_261_),
    .X(_262_));
 sky130_fd_sc_hd__nor3_2 _607_ (.A(\result_comb[14] ),
    .B(\result_comb[15] ),
    .C(_262_),
    .Y(_000_));
 sky130_fd_sc_hd__nand2_2 _608_ (.A(is_sub),
    .B(\B_reg[15] ),
    .Y(_263_));
 sky130_fd_sc_hd__or2_2 _609_ (.A(is_sub),
    .B(\B_reg[15] ),
    .X(_264_));
 sky130_fd_sc_hd__and3b_2 _610_ (.A_N(\B_reg[1] ),
    .B(_299_),
    .C(\B_reg[0] ),
    .X(_265_));
 sky130_fd_sc_hd__a211oi_2 _611_ (.A1(\B_reg[1] ),
    .A2(_055_),
    .B1(_265_),
    .C1(\B_reg[2] ),
    .Y(_266_));
 sky130_fd_sc_hd__a211oi_2 _612_ (.A1(\B_reg[2] ),
    .A2(_095_),
    .B1(_266_),
    .C1(\B_reg[3] ),
    .Y(_267_));
 sky130_fd_sc_hd__a41o_2 _613_ (.A1(\A_reg[15] ),
    .A2(_043_),
    .A3(_263_),
    .A4(_264_),
    .B1(_267_),
    .X(_268_));
 sky130_fd_sc_hd__a211o_2 _614_ (.A1(\B_reg[3] ),
    .A2(_166_),
    .B1(_251_),
    .C1(_268_),
    .X(carry_comb));
 sky130_fd_sc_hd__mux2_1 _615_ (.A0(op_add),
    .A1(is_sub),
    .S(_248_),
    .X(_269_));
 sky130_fd_sc_hd__a21boi_2 _616_ (.A1(\A_reg[15] ),
    .A2(_252_),
    .B1_N(_269_),
    .Y(_270_));
 sky130_fd_sc_hd__o21a_2 _617_ (.A1(\A_reg[15] ),
    .A2(_252_),
    .B1(_270_),
    .X(overflow_comb));
 sky130_fd_sc_hd__dfxtp_2 _618_ (.CLK(clk),
    .D(\result_comb[15] ),
    .Q(N));
 sky130_fd_sc_hd__dfxtp_2 _619_ (.CLK(clk),
    .D(overflow_comb),
    .Q(V));
 sky130_fd_sc_hd__dfxtp_2 _620_ (.CLK(clk),
    .D(\result_comb[0] ),
    .Q(Y[0]));
 sky130_fd_sc_hd__dfxtp_2 _621_ (.CLK(clk),
    .D(\result_comb[1] ),
    .Q(Y[1]));
 sky130_fd_sc_hd__dfxtp_2 _622_ (.CLK(clk),
    .D(\result_comb[2] ),
    .Q(Y[2]));
 sky130_fd_sc_hd__dfxtp_2 _623_ (.CLK(clk),
    .D(\result_comb[3] ),
    .Q(Y[3]));
 sky130_fd_sc_hd__dfxtp_2 _624_ (.CLK(clk),
    .D(\result_comb[4] ),
    .Q(Y[4]));
 sky130_fd_sc_hd__dfxtp_2 _625_ (.CLK(clk),
    .D(\result_comb[5] ),
    .Q(Y[5]));
 sky130_fd_sc_hd__dfxtp_2 _626_ (.CLK(clk),
    .D(\result_comb[6] ),
    .Q(Y[6]));
 sky130_fd_sc_hd__dfxtp_2 _627_ (.CLK(clk),
    .D(\result_comb[7] ),
    .Q(Y[7]));
 sky130_fd_sc_hd__dfxtp_2 _628_ (.CLK(clk),
    .D(\result_comb[8] ),
    .Q(Y[8]));
 sky130_fd_sc_hd__dfxtp_2 _629_ (.CLK(clk),
    .D(\result_comb[9] ),
    .Q(Y[9]));
 sky130_fd_sc_hd__dfxtp_2 _630_ (.CLK(clk),
    .D(\result_comb[10] ),
    .Q(Y[10]));
 sky130_fd_sc_hd__dfxtp_2 _631_ (.CLK(clk),
    .D(\result_comb[11] ),
    .Q(Y[11]));
 sky130_fd_sc_hd__dfxtp_2 _632_ (.CLK(clk),
    .D(\result_comb[12] ),
    .Q(Y[12]));
 sky130_fd_sc_hd__dfxtp_2 _633_ (.CLK(clk),
    .D(\result_comb[13] ),
    .Q(Y[13]));
 sky130_fd_sc_hd__dfxtp_2 _634_ (.CLK(clk),
    .D(\result_comb[14] ),
    .Q(Y[14]));
 sky130_fd_sc_hd__dfxtp_2 _635_ (.CLK(clk),
    .D(_000_),
    .Q(Z));
 sky130_fd_sc_hd__dfxtp_2 _636_ (.CLK(clk),
    .D(A[0]),
    .Q(\A_reg[0] ));
 sky130_fd_sc_hd__dfxtp_2 _637_ (.CLK(clk),
    .D(A[1]),
    .Q(\A_reg[1] ));
 sky130_fd_sc_hd__dfxtp_2 _638_ (.CLK(clk),
    .D(A[2]),
    .Q(\A_reg[2] ));
 sky130_fd_sc_hd__dfxtp_2 _639_ (.CLK(clk),
    .D(A[3]),
    .Q(\A_reg[3] ));
 sky130_fd_sc_hd__dfxtp_2 _640_ (.CLK(clk),
    .D(A[4]),
    .Q(\A_reg[4] ));
 sky130_fd_sc_hd__dfxtp_2 _641_ (.CLK(clk),
    .D(A[5]),
    .Q(\A_reg[5] ));
 sky130_fd_sc_hd__dfxtp_2 _642_ (.CLK(clk),
    .D(A[6]),
    .Q(\A_reg[6] ));
 sky130_fd_sc_hd__dfxtp_2 _643_ (.CLK(clk),
    .D(A[7]),
    .Q(\A_reg[7] ));
 sky130_fd_sc_hd__dfxtp_2 _644_ (.CLK(clk),
    .D(A[8]),
    .Q(\A_reg[8] ));
 sky130_fd_sc_hd__dfxtp_2 _645_ (.CLK(clk),
    .D(A[9]),
    .Q(\A_reg[9] ));
 sky130_fd_sc_hd__dfxtp_2 _646_ (.CLK(clk),
    .D(A[10]),
    .Q(\A_reg[10] ));
 sky130_fd_sc_hd__dfxtp_2 _647_ (.CLK(clk),
    .D(A[11]),
    .Q(\A_reg[11] ));
 sky130_fd_sc_hd__dfxtp_2 _648_ (.CLK(clk),
    .D(A[12]),
    .Q(\A_reg[12] ));
 sky130_fd_sc_hd__dfxtp_2 _649_ (.CLK(clk),
    .D(A[13]),
    .Q(\A_reg[13] ));
 sky130_fd_sc_hd__dfxtp_2 _650_ (.CLK(clk),
    .D(A[14]),
    .Q(\A_reg[14] ));
 sky130_fd_sc_hd__dfxtp_2 _651_ (.CLK(clk),
    .D(A[15]),
    .Q(\A_reg[15] ));
 sky130_fd_sc_hd__dfxtp_2 _652_ (.CLK(clk),
    .D(B[0]),
    .Q(\B_reg[0] ));
 sky130_fd_sc_hd__dfxtp_2 _653_ (.CLK(clk),
    .D(B[1]),
    .Q(\B_reg[1] ));
 sky130_fd_sc_hd__dfxtp_2 _654_ (.CLK(clk),
    .D(B[2]),
    .Q(\B_reg[2] ));
 sky130_fd_sc_hd__dfxtp_2 _655_ (.CLK(clk),
    .D(B[3]),
    .Q(\B_reg[3] ));
 sky130_fd_sc_hd__dfxtp_2 _656_ (.CLK(clk),
    .D(B[4]),
    .Q(\B_reg[4] ));
 sky130_fd_sc_hd__dfxtp_2 _657_ (.CLK(clk),
    .D(B[5]),
    .Q(\B_reg[5] ));
 sky130_fd_sc_hd__dfxtp_2 _658_ (.CLK(clk),
    .D(B[6]),
    .Q(\B_reg[6] ));
 sky130_fd_sc_hd__dfxtp_2 _659_ (.CLK(clk),
    .D(B[7]),
    .Q(\B_reg[7] ));
 sky130_fd_sc_hd__dfxtp_2 _660_ (.CLK(clk),
    .D(B[8]),
    .Q(\B_reg[8] ));
 sky130_fd_sc_hd__dfxtp_2 _661_ (.CLK(clk),
    .D(B[9]),
    .Q(\B_reg[9] ));
 sky130_fd_sc_hd__dfxtp_2 _662_ (.CLK(clk),
    .D(B[10]),
    .Q(\B_reg[10] ));
 sky130_fd_sc_hd__dfxtp_2 _663_ (.CLK(clk),
    .D(B[11]),
    .Q(\B_reg[11] ));
 sky130_fd_sc_hd__dfxtp_2 _664_ (.CLK(clk),
    .D(B[12]),
    .Q(\B_reg[12] ));
 sky130_fd_sc_hd__dfxtp_2 _665_ (.CLK(clk),
    .D(B[13]),
    .Q(\B_reg[13] ));
 sky130_fd_sc_hd__dfxtp_2 _666_ (.CLK(clk),
    .D(B[14]),
    .Q(\B_reg[14] ));
 sky130_fd_sc_hd__dfxtp_2 _667_ (.CLK(clk),
    .D(B[15]),
    .Q(\B_reg[15] ));
 sky130_fd_sc_hd__dfxtp_2 _668_ (.CLK(clk),
    .D(_001_),
    .Q(op_add));
 sky130_fd_sc_hd__dfxtp_2 _669_ (.CLK(clk),
    .D(_007_),
    .Q(is_sub));
 sky130_fd_sc_hd__dfxtp_2 _670_ (.CLK(clk),
    .D(_002_),
    .Q(op_and));
 sky130_fd_sc_hd__dfxtp_2 _671_ (.CLK(clk),
    .D(_004_),
    .Q(op_or));
 sky130_fd_sc_hd__dfxtp_2 _672_ (.CLK(clk),
    .D(_008_),
    .Q(op_xor));
 sky130_fd_sc_hd__dfxtp_2 _673_ (.CLK(clk),
    .D(_003_),
    .Q(op_not));
 sky130_fd_sc_hd__dfxtp_2 _674_ (.CLK(clk),
    .D(_005_),
    .Q(op_sll));
 sky130_fd_sc_hd__dfxtp_2 _675_ (.CLK(clk),
    .D(_006_),
    .Q(op_srl));
 sky130_fd_sc_hd__dfxtp_2 _676_ (.CLK(clk),
    .D(carry_comb),
    .Q(C));
 sky130_fd_sc_hd__buf_2 _677_ (.A(N),
    .X(Y[15]));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_0_Right_0 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_1_Right_1 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_2_Right_2 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_3_Right_3 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_4_Right_4 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_5_Right_5 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_6_Right_6 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_7_Right_7 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_8_Right_8 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_9_Right_9 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_10_Right_10 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_11_Right_11 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_12_Right_12 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_13_Right_13 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_14_Right_14 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_15_Right_15 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_16_Right_16 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_17_Right_17 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_18_Right_18 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_19_Right_19 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_20_Right_20 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_21_Right_21 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_22_Right_22 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_23_Right_23 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_24_Right_24 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_25_Right_25 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_Right_26 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_Right_27 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_Right_28 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_Right_29 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_Right_30 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_31_Right_31 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_32_Right_32 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_33_Right_33 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_34_Right_34 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_35_Right_35 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_36_Right_36 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_37_Right_37 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_38_Right_38 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_39_Right_39 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_40_Right_40 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_0_Left_41 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_1_Left_42 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_2_Left_43 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_3_Left_44 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_4_Left_45 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_5_Left_46 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_6_Left_47 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_7_Left_48 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_8_Left_49 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_9_Left_50 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_10_Left_51 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_11_Left_52 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_12_Left_53 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_13_Left_54 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_14_Left_55 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_15_Left_56 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_16_Left_57 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_17_Left_58 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_18_Left_59 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_19_Left_60 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_20_Left_61 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_21_Left_62 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_22_Left_63 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_23_Left_64 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_24_Left_65 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_25_Left_66 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_Left_67 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_Left_68 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_Left_69 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_Left_70 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_Left_71 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_31_Left_72 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_32_Left_73 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_33_Left_74 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_34_Left_75 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_35_Left_76 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_36_Left_77 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_37_Left_78 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_38_Left_79 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_39_Left_80 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_40_Left_81 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_82 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_83 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_84 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_85 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_86 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_87 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_88 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_89 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_90 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_91 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_92 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_93 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_94 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_95 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_96 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_97 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_98 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_99 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_100 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_101 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_102 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_103 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_104 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_105 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_106 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_107 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_108 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_109 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_110 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_111 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_112 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_113 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_114 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_115 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_116 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_117 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_118 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_119 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_120 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_121 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_122 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_123 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_124 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_125 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_126 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_127 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_128 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_129 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_130 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_131 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_132 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_133 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_134 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_135 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_136 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_137 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_138 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_139 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_140 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_141 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_142 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_143 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_144 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_145 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_146 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_147 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_148 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_149 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_150 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_151 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_152 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_153 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_154 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_155 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_156 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_157 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_158 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_159 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_160 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_161 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_162 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_163 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_164 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_165 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_166 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_167 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_168 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_169 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_170 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_171 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_172 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_173 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_174 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_175 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_176 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_177 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_178 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_179 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_180 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_181 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_182 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_183 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_184 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_185 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_186 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_187 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_188 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_189 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_190 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_191 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_192 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_193 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_194 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_195 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_196 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_197 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_198 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_199 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_200 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_201 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_202 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_203 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_204 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_205 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_206 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_207 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_208 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_209 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_210 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_211 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_212 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_213 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_214 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_215 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_216 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_217 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_218 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_219 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_220 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_221 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_222 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_223 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_224 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_225 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_226 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_227 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_228 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_229 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_230 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_231 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_232 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_233 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_234 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_235 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_236 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_237 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_238 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_239 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_240 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_241 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_242 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_243 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_244 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_245 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_246 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_247 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_248 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_249 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_250 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_251 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_252 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_253 ();
endmodule
