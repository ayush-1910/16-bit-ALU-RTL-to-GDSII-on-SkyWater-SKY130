module alu16 (C,
    N,
    V,
    Z,
    clk,
    A,
    B,
    Y,
    opcode,
    VPWR,
    VGND);
 output C;
 output N;
 output V;
 output Z;
 input clk;
 input [15:0] A;
 input [15:0] B;
 output [15:0] Y;
 input [2:0] opcode;
 inout VPWR;
 inout VGND;

 wire \A_reg[0] ;
 wire \A_reg[10] ;
 wire \A_reg[11] ;
 wire \A_reg[12] ;
 wire \A_reg[13] ;
 wire \A_reg[14] ;
 wire \A_reg[15] ;
 wire \A_reg[1] ;
 wire \A_reg[2] ;
 wire \A_reg[3] ;
 wire \A_reg[4] ;
 wire \A_reg[5] ;
 wire \A_reg[6] ;
 wire \A_reg[7] ;
 wire \A_reg[8] ;
 wire \A_reg[9] ;
 wire \B_reg[0] ;
 wire \B_reg[10] ;
 wire \B_reg[11] ;
 wire \B_reg[12] ;
 wire \B_reg[13] ;
 wire \B_reg[14] ;
 wire \B_reg[15] ;
 wire \B_reg[1] ;
 wire \B_reg[2] ;
 wire \B_reg[3] ;
 wire \B_reg[4] ;
 wire \B_reg[5] ;
 wire \B_reg[6] ;
 wire \B_reg[7] ;
 wire \B_reg[8] ;
 wire \B_reg[9] ;
 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _070_;
 wire _071_;
 wire _072_;
 wire _073_;
 wire _074_;
 wire _075_;
 wire _076_;
 wire _077_;
 wire _078_;
 wire _079_;
 wire _080_;
 wire _081_;
 wire _082_;
 wire _083_;
 wire _084_;
 wire _085_;
 wire _086_;
 wire _087_;
 wire _088_;
 wire _089_;
 wire _090_;
 wire _091_;
 wire _092_;
 wire _093_;
 wire _094_;
 wire _095_;
 wire _096_;
 wire _097_;
 wire _098_;
 wire _099_;
 wire _100_;
 wire _101_;
 wire _102_;
 wire _103_;
 wire _104_;
 wire _105_;
 wire _106_;
 wire _107_;
 wire _108_;
 wire _109_;
 wire _110_;
 wire _111_;
 wire _112_;
 wire _113_;
 wire _114_;
 wire _115_;
 wire _116_;
 wire _117_;
 wire _118_;
 wire _119_;
 wire _120_;
 wire _121_;
 wire _122_;
 wire _123_;
 wire _124_;
 wire _125_;
 wire _126_;
 wire _127_;
 wire _128_;
 wire _129_;
 wire _130_;
 wire _131_;
 wire _132_;
 wire _133_;
 wire _134_;
 wire _135_;
 wire _136_;
 wire _137_;
 wire _138_;
 wire _139_;
 wire _140_;
 wire _141_;
 wire _142_;
 wire _143_;
 wire _144_;
 wire _145_;
 wire _146_;
 wire _147_;
 wire _148_;
 wire _149_;
 wire _150_;
 wire _151_;
 wire _152_;
 wire _153_;
 wire _154_;
 wire _155_;
 wire _156_;
 wire _157_;
 wire _158_;
 wire _159_;
 wire _160_;
 wire _161_;
 wire _162_;
 wire _163_;
 wire _164_;
 wire _165_;
 wire _166_;
 wire _167_;
 wire _168_;
 wire _169_;
 wire _170_;
 wire _171_;
 wire _172_;
 wire _173_;
 wire _174_;
 wire _175_;
 wire _176_;
 wire _177_;
 wire _178_;
 wire _179_;
 wire _180_;
 wire _181_;
 wire _182_;
 wire _183_;
 wire _184_;
 wire _185_;
 wire _186_;
 wire _187_;
 wire _188_;
 wire _189_;
 wire _190_;
 wire _191_;
 wire _192_;
 wire _193_;
 wire _194_;
 wire _195_;
 wire _196_;
 wire _197_;
 wire _198_;
 wire _199_;
 wire _200_;
 wire _201_;
 wire _202_;
 wire _203_;
 wire _204_;
 wire _205_;
 wire _206_;
 wire _207_;
 wire _208_;
 wire _209_;
 wire _210_;
 wire _211_;
 wire _212_;
 wire _213_;
 wire _214_;
 wire _215_;
 wire _216_;
 wire _217_;
 wire _218_;
 wire _219_;
 wire _220_;
 wire _221_;
 wire _222_;
 wire _223_;
 wire _224_;
 wire _225_;
 wire _226_;
 wire _227_;
 wire _228_;
 wire _229_;
 wire _230_;
 wire _231_;
 wire _232_;
 wire _233_;
 wire _234_;
 wire _235_;
 wire _236_;
 wire _237_;
 wire _238_;
 wire _239_;
 wire _240_;
 wire _241_;
 wire _242_;
 wire _243_;
 wire _244_;
 wire _245_;
 wire _246_;
 wire _247_;
 wire _248_;
 wire _249_;
 wire _250_;
 wire _251_;
 wire _252_;
 wire _253_;
 wire _254_;
 wire _255_;
 wire _256_;
 wire _257_;
 wire _258_;
 wire _259_;
 wire _260_;
 wire _261_;
 wire _262_;
 wire _263_;
 wire _264_;
 wire _265_;
 wire _266_;
 wire _267_;
 wire _268_;
 wire _269_;
 wire _270_;
 wire _271_;
 wire _272_;
 wire _273_;
 wire _274_;
 wire _275_;
 wire _276_;
 wire _277_;
 wire _278_;
 wire _279_;
 wire _280_;
 wire _281_;
 wire _282_;
 wire _283_;
 wire _284_;
 wire _285_;
 wire _286_;
 wire _287_;
 wire _288_;
 wire _289_;
 wire _290_;
 wire _291_;
 wire _292_;
 wire _293_;
 wire _294_;
 wire _295_;
 wire _296_;
 wire _297_;
 wire _298_;
 wire _299_;
 wire _300_;
 wire _301_;
 wire carry_comb;
 wire \opcode_reg[0] ;
 wire \opcode_reg[1] ;
 wire \opcode_reg[2] ;
 wire overflow_comb;
 wire \result_comb[0] ;
 wire \result_comb[10] ;
 wire \result_comb[11] ;
 wire \result_comb[12] ;
 wire \result_comb[13] ;
 wire \result_comb[14] ;
 wire \result_comb[15] ;
 wire \result_comb[1] ;
 wire \result_comb[2] ;
 wire \result_comb[3] ;
 wire \result_comb[4] ;
 wire \result_comb[5] ;
 wire \result_comb[6] ;
 wire \result_comb[7] ;
 wire \result_comb[8] ;
 wire \result_comb[9] ;

 sky130_fd_sc_hd__inv_2 _302_ (.A(\B_reg[0] ),
    .Y(_257_));
 sky130_fd_sc_hd__inv_2 _303_ (.A(\A_reg[15] ),
    .Y(_258_));
 sky130_fd_sc_hd__inv_2 _304_ (.A(\B_reg[1] ),
    .Y(_259_));
 sky130_fd_sc_hd__inv_2 _305_ (.A(\B_reg[2] ),
    .Y(_260_));
 sky130_fd_sc_hd__inv_2 _306_ (.A(\B_reg[3] ),
    .Y(_261_));
 sky130_fd_sc_hd__and3b_2 _307_ (.A_N(\opcode_reg[0] ),
    .B(\opcode_reg[2] ),
    .C(\opcode_reg[1] ),
    .X(_262_));
 sky130_fd_sc_hd__nand3b_2 _308_ (.A_N(\opcode_reg[0] ),
    .B(\opcode_reg[2] ),
    .C(\opcode_reg[1] ),
    .Y(_263_));
 sky130_fd_sc_hd__nand2_2 _309_ (.A(\opcode_reg[1] ),
    .B(\opcode_reg[0] ),
    .Y(_264_));
 sky130_fd_sc_hd__and3_2 _310_ (.A(\opcode_reg[1] ),
    .B(\opcode_reg[0] ),
    .C(\opcode_reg[2] ),
    .X(_265_));
 sky130_fd_sc_hd__a22oi_2 _311_ (.A1(\A_reg[11] ),
    .A2(_262_),
    .B1(_265_),
    .B2(\A_reg[4] ),
    .Y(_266_));
 sky130_fd_sc_hd__a22oi_2 _312_ (.A1(\A_reg[10] ),
    .A2(_262_),
    .B1(_265_),
    .B2(\A_reg[5] ),
    .Y(_267_));
 sky130_fd_sc_hd__mux2_1 _313_ (.A0(_266_),
    .A1(_267_),
    .S(\B_reg[0] ),
    .X(_268_));
 sky130_fd_sc_hd__inv_2 _314_ (.A(_268_),
    .Y(_269_));
 sky130_fd_sc_hd__a22oi_2 _315_ (.A1(\A_reg[9] ),
    .A2(_262_),
    .B1(_265_),
    .B2(\A_reg[6] ),
    .Y(_270_));
 sky130_fd_sc_hd__a22o_2 _316_ (.A1(\A_reg[8] ),
    .A2(_262_),
    .B1(_265_),
    .B2(\A_reg[7] ),
    .X(_271_));
 sky130_fd_sc_hd__nor2_2 _317_ (.A(_257_),
    .B(_271_),
    .Y(_272_));
 sky130_fd_sc_hd__a21oi_2 _318_ (.A1(_257_),
    .A2(_270_),
    .B1(_272_),
    .Y(_273_));
 sky130_fd_sc_hd__mux2_1 _319_ (.A0(_269_),
    .A1(_273_),
    .S(\B_reg[1] ),
    .X(_274_));
 sky130_fd_sc_hd__a22oi_2 _320_ (.A1(\A_reg[13] ),
    .A2(_262_),
    .B1(_265_),
    .B2(\A_reg[2] ),
    .Y(_275_));
 sky130_fd_sc_hd__a22oi_2 _321_ (.A1(\A_reg[12] ),
    .A2(_262_),
    .B1(_265_),
    .B2(\A_reg[3] ),
    .Y(_276_));
 sky130_fd_sc_hd__mux2_1 _322_ (.A0(_275_),
    .A1(_276_),
    .S(\B_reg[0] ),
    .X(_277_));
 sky130_fd_sc_hd__a22o_2 _323_ (.A1(\A_reg[14] ),
    .A2(_262_),
    .B1(_265_),
    .B2(\A_reg[1] ),
    .X(_278_));
 sky130_fd_sc_hd__inv_2 _324_ (.A(_278_),
    .Y(_279_));
 sky130_fd_sc_hd__a22o_2 _325_ (.A1(\A_reg[15] ),
    .A2(_262_),
    .B1(_265_),
    .B2(\A_reg[0] ),
    .X(_280_));
 sky130_fd_sc_hd__nand2_2 _326_ (.A(_257_),
    .B(_280_),
    .Y(_281_));
 sky130_fd_sc_hd__o211a_2 _327_ (.A1(_257_),
    .A2(_279_),
    .B1(_281_),
    .C1(_259_),
    .X(_282_));
 sky130_fd_sc_hd__a211o_2 _328_ (.A1(\B_reg[1] ),
    .A2(_277_),
    .B1(_282_),
    .C1(\B_reg[2] ),
    .X(_283_));
 sky130_fd_sc_hd__a21oi_2 _329_ (.A1(\B_reg[2] ),
    .A2(_274_),
    .B1(\B_reg[3] ),
    .Y(_284_));
 sky130_fd_sc_hd__a22o_2 _330_ (.A1(\A_reg[6] ),
    .A2(_262_),
    .B1(_265_),
    .B2(\A_reg[9] ),
    .X(_285_));
 sky130_fd_sc_hd__a22o_2 _331_ (.A1(\A_reg[7] ),
    .A2(_262_),
    .B1(_265_),
    .B2(\A_reg[8] ),
    .X(_286_));
 sky130_fd_sc_hd__mux2_1 _332_ (.A0(_285_),
    .A1(_286_),
    .S(_257_),
    .X(_287_));
 sky130_fd_sc_hd__inv_2 _333_ (.A(_287_),
    .Y(_288_));
 sky130_fd_sc_hd__a21o_2 _334_ (.A1(\A_reg[10] ),
    .A2(_265_),
    .B1(_262_),
    .X(_289_));
 sky130_fd_sc_hd__o21ai_2 _335_ (.A1(\A_reg[5] ),
    .A2(_263_),
    .B1(_289_),
    .Y(_290_));
 sky130_fd_sc_hd__a22oi_2 _336_ (.A1(\A_reg[4] ),
    .A2(_262_),
    .B1(_265_),
    .B2(\A_reg[11] ),
    .Y(_291_));
 sky130_fd_sc_hd__mux2_1 _337_ (.A0(_290_),
    .A1(_291_),
    .S(\B_reg[0] ),
    .X(_292_));
 sky130_fd_sc_hd__mux2_1 _338_ (.A0(_288_),
    .A1(_292_),
    .S(\B_reg[1] ),
    .X(_293_));
 sky130_fd_sc_hd__a22oi_2 _339_ (.A1(\A_reg[3] ),
    .A2(_262_),
    .B1(_265_),
    .B2(\A_reg[12] ),
    .Y(_294_));
 sky130_fd_sc_hd__a22oi_2 _340_ (.A1(\A_reg[2] ),
    .A2(_262_),
    .B1(_265_),
    .B2(\A_reg[13] ),
    .Y(_295_));
 sky130_fd_sc_hd__mux2_1 _341_ (.A0(_294_),
    .A1(_295_),
    .S(\B_reg[0] ),
    .X(_296_));
 sky130_fd_sc_hd__a22oi_2 _342_ (.A1(\A_reg[0] ),
    .A2(_262_),
    .B1(_265_),
    .B2(\A_reg[15] ),
    .Y(_297_));
 sky130_fd_sc_hd__a22oi_2 _343_ (.A1(\A_reg[1] ),
    .A2(_262_),
    .B1(_265_),
    .B2(\A_reg[14] ),
    .Y(_298_));
 sky130_fd_sc_hd__mux2_1 _344_ (.A0(_297_),
    .A1(_298_),
    .S(_257_),
    .X(_299_));
 sky130_fd_sc_hd__mux2_1 _345_ (.A0(_296_),
    .A1(_299_),
    .S(\B_reg[1] ),
    .X(_300_));
 sky130_fd_sc_hd__mux2_1 _346_ (.A0(_293_),
    .A1(_300_),
    .S(\B_reg[2] ),
    .X(_301_));
 sky130_fd_sc_hd__a22oi_2 _347_ (.A1(_283_),
    .A2(_284_),
    .B1(_301_),
    .B2(\B_reg[3] ),
    .Y(_001_));
 sky130_fd_sc_hd__nand3b_2 _348_ (.A_N(\opcode_reg[1] ),
    .B(\opcode_reg[0] ),
    .C(\opcode_reg[2] ),
    .Y(_002_));
 sky130_fd_sc_hd__nand2_2 _349_ (.A(\A_reg[0] ),
    .B(\B_reg[0] ),
    .Y(_003_));
 sky130_fd_sc_hd__a21oi_2 _350_ (.A1(\A_reg[0] ),
    .A2(\B_reg[0] ),
    .B1(\opcode_reg[0] ),
    .Y(_004_));
 sky130_fd_sc_hd__o22a_2 _351_ (.A1(\opcode_reg[1] ),
    .A2(\opcode_reg[0] ),
    .B1(\opcode_reg[2] ),
    .B2(_004_),
    .X(_005_));
 sky130_fd_sc_hd__o21ba_2 _352_ (.A1(\A_reg[0] ),
    .A2(\B_reg[0] ),
    .B1_N(_005_),
    .X(_006_));
 sky130_fd_sc_hd__o21ai_2 _353_ (.A1(\opcode_reg[1] ),
    .A2(_003_),
    .B1(_006_),
    .Y(_007_));
 sky130_fd_sc_hd__or3_2 _354_ (.A(\B_reg[0] ),
    .B(\B_reg[1] ),
    .C(_297_),
    .X(_008_));
 sky130_fd_sc_hd__or2_2 _355_ (.A(\B_reg[2] ),
    .B(_008_),
    .X(_009_));
 sky130_fd_sc_hd__inv_2 _356_ (.A(_009_),
    .Y(_010_));
 sky130_fd_sc_hd__nand2_2 _357_ (.A(_261_),
    .B(_262_),
    .Y(_011_));
 sky130_fd_sc_hd__o221a_2 _358_ (.A1(\A_reg[0] ),
    .A2(_002_),
    .B1(_009_),
    .B2(_011_),
    .C1(_007_),
    .X(_012_));
 sky130_fd_sc_hd__a21bo_2 _359_ (.A1(_263_),
    .A2(_001_),
    .B1_N(_012_),
    .X(\result_comb[0] ));
 sky130_fd_sc_hd__mux2_1 _360_ (.A0(_267_),
    .A1(_270_),
    .S(\B_reg[0] ),
    .X(_013_));
 sky130_fd_sc_hd__inv_2 _361_ (.A(_013_),
    .Y(_014_));
 sky130_fd_sc_hd__mux2_1 _362_ (.A0(_271_),
    .A1(_286_),
    .S(\B_reg[0] ),
    .X(_015_));
 sky130_fd_sc_hd__mux2_1 _363_ (.A0(_014_),
    .A1(_015_),
    .S(\B_reg[1] ),
    .X(_016_));
 sky130_fd_sc_hd__inv_2 _364_ (.A(_016_),
    .Y(_017_));
 sky130_fd_sc_hd__nand2_2 _365_ (.A(\B_reg[0] ),
    .B(_275_),
    .Y(_018_));
 sky130_fd_sc_hd__mux4_2 _366_ (.A0(_266_),
    .A1(_275_),
    .A2(_276_),
    .A3(_279_),
    .S0(_259_),
    .S1(_257_),
    .X(_019_));
 sky130_fd_sc_hd__nand2_2 _367_ (.A(_257_),
    .B(_285_),
    .Y(_020_));
 sky130_fd_sc_hd__o21a_2 _368_ (.A1(_257_),
    .A2(_290_),
    .B1(_020_),
    .X(_021_));
 sky130_fd_sc_hd__inv_2 _369_ (.A(_021_),
    .Y(_022_));
 sky130_fd_sc_hd__mux2_1 _370_ (.A0(_291_),
    .A1(_294_),
    .S(\B_reg[0] ),
    .X(_023_));
 sky130_fd_sc_hd__mux2_1 _371_ (.A0(_021_),
    .A1(_023_),
    .S(\B_reg[1] ),
    .X(_024_));
 sky130_fd_sc_hd__or3_2 _372_ (.A(\B_reg[0] ),
    .B(_259_),
    .C(_297_),
    .X(_025_));
 sky130_fd_sc_hd__mux2_1 _373_ (.A0(_295_),
    .A1(_298_),
    .S(\B_reg[0] ),
    .X(_026_));
 sky130_fd_sc_hd__o21a_2 _374_ (.A1(\B_reg[1] ),
    .A2(_026_),
    .B1(_025_),
    .X(_027_));
 sky130_fd_sc_hd__mux2_1 _375_ (.A0(_024_),
    .A1(_027_),
    .S(\B_reg[2] ),
    .X(_028_));
 sky130_fd_sc_hd__mux4_2 _376_ (.A0(_017_),
    .A1(_019_),
    .A2(_027_),
    .A3(_024_),
    .S0(_260_),
    .S1(\B_reg[3] ),
    .X(_029_));
 sky130_fd_sc_hd__nor3_2 _377_ (.A(\opcode_reg[1] ),
    .B(\opcode_reg[0] ),
    .C(\opcode_reg[2] ),
    .Y(_030_));
 sky130_fd_sc_hd__nor3b_2 _378_ (.A(\opcode_reg[1] ),
    .B(\opcode_reg[2] ),
    .C_N(\opcode_reg[0] ),
    .Y(_031_));
 sky130_fd_sc_hd__or2_2 _379_ (.A(\opcode_reg[1] ),
    .B(\opcode_reg[2] ),
    .X(_032_));
 sky130_fd_sc_hd__nor2_2 _380_ (.A(\opcode_reg[1] ),
    .B(\opcode_reg[2] ),
    .Y(_033_));
 sky130_fd_sc_hd__nor4b_2 _381_ (.A(\opcode_reg[1] ),
    .B(\opcode_reg[0] ),
    .C(\opcode_reg[2] ),
    .D_N(\B_reg[1] ),
    .Y(_034_));
 sky130_fd_sc_hd__o31ai_2 _382_ (.A1(\opcode_reg[1] ),
    .A2(\opcode_reg[0] ),
    .A3(\opcode_reg[2] ),
    .B1(\B_reg[1] ),
    .Y(_035_));
 sky130_fd_sc_hd__o211a_2 _383_ (.A1(\B_reg[1] ),
    .A2(_031_),
    .B1(_035_),
    .C1(\A_reg[1] ),
    .X(_036_));
 sky130_fd_sc_hd__a211o_2 _384_ (.A1(_259_),
    .A2(_031_),
    .B1(_034_),
    .C1(\A_reg[1] ),
    .X(_037_));
 sky130_fd_sc_hd__and2b_2 _385_ (.A_N(_036_),
    .B(_037_),
    .X(_038_));
 sky130_fd_sc_hd__nand2_2 _386_ (.A(_033_),
    .B(_038_),
    .Y(_039_));
 sky130_fd_sc_hd__or4b_2 _387_ (.A(\opcode_reg[1] ),
    .B(\opcode_reg[2] ),
    .C(\B_reg[0] ),
    .D_N(\opcode_reg[0] ),
    .X(_040_));
 sky130_fd_sc_hd__a21oi_2 _388_ (.A1(_003_),
    .A2(_040_),
    .B1(_032_),
    .Y(_041_));
 sky130_fd_sc_hd__mux2_1 _389_ (.A0(_039_),
    .A1(_038_),
    .S(_041_),
    .X(_042_));
 sky130_fd_sc_hd__nor3b_2 _390_ (.A(\opcode_reg[0] ),
    .B(\opcode_reg[2] ),
    .C_N(\opcode_reg[1] ),
    .Y(_043_));
 sky130_fd_sc_hd__or3b_2 _391_ (.A(\opcode_reg[0] ),
    .B(\opcode_reg[2] ),
    .C_N(\opcode_reg[1] ),
    .X(_044_));
 sky130_fd_sc_hd__nor2_2 _392_ (.A(\opcode_reg[2] ),
    .B(_264_),
    .Y(_045_));
 sky130_fd_sc_hd__or2_2 _393_ (.A(\opcode_reg[2] ),
    .B(_264_),
    .X(_046_));
 sky130_fd_sc_hd__or3b_2 _394_ (.A(\opcode_reg[1] ),
    .B(\opcode_reg[0] ),
    .C_N(\opcode_reg[2] ),
    .X(_047_));
 sky130_fd_sc_hd__a21o_2 _395_ (.A1(\B_reg[1] ),
    .A2(\A_reg[1] ),
    .B1(_047_),
    .X(_048_));
 sky130_fd_sc_hd__a2bb2o_2 _396_ (.A1_N(\B_reg[1] ),
    .A2_N(\A_reg[1] ),
    .B1(_046_),
    .B2(_048_),
    .X(_049_));
 sky130_fd_sc_hd__or2_2 _397_ (.A(\B_reg[1] ),
    .B(_299_),
    .X(_050_));
 sky130_fd_sc_hd__or2_2 _398_ (.A(\B_reg[2] ),
    .B(_050_),
    .X(_051_));
 sky130_fd_sc_hd__o211a_2 _399_ (.A1(\A_reg[1] ),
    .A2(_002_),
    .B1(_042_),
    .C1(_049_),
    .X(_052_));
 sky130_fd_sc_hd__o221ai_2 _400_ (.A1(_262_),
    .A2(_029_),
    .B1(_051_),
    .B2(_011_),
    .C1(_052_),
    .Y(_053_));
 sky130_fd_sc_hd__a31o_2 _401_ (.A1(\B_reg[1] ),
    .A2(\A_reg[1] ),
    .A3(_043_),
    .B1(_053_),
    .X(\result_comb[1] ));
 sky130_fd_sc_hd__mux2_1 _402_ (.A0(_273_),
    .A1(_287_),
    .S(\B_reg[1] ),
    .X(_054_));
 sky130_fd_sc_hd__mux2_1 _403_ (.A0(_268_),
    .A1(_277_),
    .S(_259_),
    .X(_055_));
 sky130_fd_sc_hd__nor2_2 _404_ (.A(_260_),
    .B(_054_),
    .Y(_056_));
 sky130_fd_sc_hd__a21o_2 _405_ (.A1(_260_),
    .A2(_055_),
    .B1(\B_reg[3] ),
    .X(_057_));
 sky130_fd_sc_hd__mux2_1 _406_ (.A0(_292_),
    .A1(_296_),
    .S(\B_reg[1] ),
    .X(_058_));
 sky130_fd_sc_hd__mux2_1 _407_ (.A0(_050_),
    .A1(_058_),
    .S(_260_),
    .X(_059_));
 sky130_fd_sc_hd__o22a_2 _408_ (.A1(_056_),
    .A2(_057_),
    .B1(_059_),
    .B2(_261_),
    .X(_060_));
 sky130_fd_sc_hd__or2_2 _409_ (.A(_262_),
    .B(_060_),
    .X(_061_));
 sky130_fd_sc_hd__a21o_2 _410_ (.A1(_037_),
    .A2(_041_),
    .B1(_036_),
    .X(_062_));
 sky130_fd_sc_hd__mux2_1 _411_ (.A0(_030_),
    .A1(_031_),
    .S(_260_),
    .X(_063_));
 sky130_fd_sc_hd__or2_2 _412_ (.A(\A_reg[2] ),
    .B(_063_),
    .X(_064_));
 sky130_fd_sc_hd__and2_2 _413_ (.A(\A_reg[2] ),
    .B(_063_),
    .X(_065_));
 sky130_fd_sc_hd__nor2_2 _414_ (.A(_032_),
    .B(_065_),
    .Y(_066_));
 sky130_fd_sc_hd__and3_2 _415_ (.A(_062_),
    .B(_064_),
    .C(_066_),
    .X(_067_));
 sky130_fd_sc_hd__a21oi_2 _416_ (.A1(_064_),
    .A2(_066_),
    .B1(_062_),
    .Y(_068_));
 sky130_fd_sc_hd__nand2_2 _417_ (.A(\B_reg[2] ),
    .B(\A_reg[2] ),
    .Y(_069_));
 sky130_fd_sc_hd__and2b_2 _418_ (.A_N(_047_),
    .B(_069_),
    .X(_070_));
 sky130_fd_sc_hd__o22a_2 _419_ (.A1(\B_reg[2] ),
    .A2(\A_reg[2] ),
    .B1(_045_),
    .B2(_070_),
    .X(_071_));
 sky130_fd_sc_hd__o21ba_2 _420_ (.A1(_067_),
    .A2(_068_),
    .B1_N(_071_),
    .X(_072_));
 sky130_fd_sc_hd__o221a_2 _421_ (.A1(\A_reg[2] ),
    .A2(_002_),
    .B1(_044_),
    .B2(_069_),
    .C1(_072_),
    .X(_073_));
 sky130_fd_sc_hd__or2_2 _422_ (.A(\B_reg[2] ),
    .B(_027_),
    .X(_074_));
 sky130_fd_sc_hd__o211ai_2 _423_ (.A1(_011_),
    .A2(_074_),
    .B1(_073_),
    .C1(_061_),
    .Y(\result_comb[2] ));
 sky130_fd_sc_hd__mux4_2 _424_ (.A0(_266_),
    .A1(_270_),
    .A2(_276_),
    .A3(_267_),
    .S0(\B_reg[1] ),
    .S1(_257_),
    .X(_075_));
 sky130_fd_sc_hd__mux2_1 _425_ (.A0(_015_),
    .A1(_022_),
    .S(\B_reg[1] ),
    .X(_076_));
 sky130_fd_sc_hd__mux2_1 _426_ (.A0(_023_),
    .A1(_026_),
    .S(\B_reg[1] ),
    .X(_077_));
 sky130_fd_sc_hd__inv_2 _427_ (.A(_077_),
    .Y(_078_));
 sky130_fd_sc_hd__mux2_1 _428_ (.A0(_008_),
    .A1(_077_),
    .S(_260_),
    .X(_079_));
 sky130_fd_sc_hd__or2_2 _429_ (.A(\B_reg[2] ),
    .B(_075_),
    .X(_080_));
 sky130_fd_sc_hd__a21oi_2 _430_ (.A1(\B_reg[2] ),
    .A2(_076_),
    .B1(\B_reg[3] ),
    .Y(_081_));
 sky130_fd_sc_hd__a22o_2 _431_ (.A1(\B_reg[3] ),
    .A2(_079_),
    .B1(_080_),
    .B2(_081_),
    .X(_082_));
 sky130_fd_sc_hd__a31o_2 _432_ (.A1(_033_),
    .A2(_062_),
    .A3(_064_),
    .B1(_065_),
    .X(_083_));
 sky130_fd_sc_hd__mux2_1 _433_ (.A0(_030_),
    .A1(_031_),
    .S(_261_),
    .X(_084_));
 sky130_fd_sc_hd__a21oi_2 _434_ (.A1(\A_reg[3] ),
    .A2(_084_),
    .B1(_032_),
    .Y(_085_));
 sky130_fd_sc_hd__o21a_2 _435_ (.A1(\A_reg[3] ),
    .A2(_084_),
    .B1(_085_),
    .X(_086_));
 sky130_fd_sc_hd__xnor2_2 _436_ (.A(_083_),
    .B(_086_),
    .Y(_087_));
 sky130_fd_sc_hd__or2_2 _437_ (.A(\B_reg[2] ),
    .B(_300_),
    .X(_088_));
 sky130_fd_sc_hd__nand2_2 _438_ (.A(\B_reg[3] ),
    .B(\A_reg[3] ),
    .Y(_089_));
 sky130_fd_sc_hd__nand2b_2 _439_ (.A_N(_047_),
    .B(_089_),
    .Y(_090_));
 sky130_fd_sc_hd__a2bb2o_2 _440_ (.A1_N(\B_reg[3] ),
    .A2_N(\A_reg[3] ),
    .B1(_046_),
    .B2(_090_),
    .X(_091_));
 sky130_fd_sc_hd__o221a_2 _441_ (.A1(\A_reg[3] ),
    .A2(_002_),
    .B1(_044_),
    .B2(_089_),
    .C1(_091_),
    .X(_092_));
 sky130_fd_sc_hd__o211a_2 _442_ (.A1(_011_),
    .A2(_088_),
    .B1(_092_),
    .C1(_087_),
    .X(_093_));
 sky130_fd_sc_hd__o21ai_2 _443_ (.A1(_262_),
    .A2(_082_),
    .B1(_093_),
    .Y(\result_comb[3] ));
 sky130_fd_sc_hd__a22o_2 _444_ (.A1(\A_reg[3] ),
    .A2(_084_),
    .B1(_086_),
    .B2(_083_),
    .X(_094_));
 sky130_fd_sc_hd__mux2_1 _445_ (.A0(_031_),
    .A1(_030_),
    .S(\B_reg[4] ),
    .X(_095_));
 sky130_fd_sc_hd__a21oi_2 _446_ (.A1(\A_reg[4] ),
    .A2(_095_),
    .B1(_032_),
    .Y(_096_));
 sky130_fd_sc_hd__o21ai_2 _447_ (.A1(\A_reg[4] ),
    .A2(_095_),
    .B1(_096_),
    .Y(_097_));
 sky130_fd_sc_hd__inv_2 _448_ (.A(_097_),
    .Y(_098_));
 sky130_fd_sc_hd__xnor2_2 _449_ (.A(_094_),
    .B(_098_),
    .Y(_099_));
 sky130_fd_sc_hd__nor2_2 _450_ (.A(\B_reg[2] ),
    .B(_274_),
    .Y(_100_));
 sky130_fd_sc_hd__a21o_2 _451_ (.A1(\B_reg[2] ),
    .A2(_293_),
    .B1(\B_reg[3] ),
    .X(_101_));
 sky130_fd_sc_hd__o22a_2 _452_ (.A1(_261_),
    .A2(_088_),
    .B1(_100_),
    .B2(_101_),
    .X(_102_));
 sky130_fd_sc_hd__nand2_2 _453_ (.A(\A_reg[4] ),
    .B(\B_reg[4] ),
    .Y(_103_));
 sky130_fd_sc_hd__nand2b_2 _454_ (.A_N(_047_),
    .B(_103_),
    .Y(_104_));
 sky130_fd_sc_hd__a2bb2o_2 _455_ (.A1_N(\A_reg[4] ),
    .A2_N(\B_reg[4] ),
    .B1(_046_),
    .B2(_104_),
    .X(_105_));
 sky130_fd_sc_hd__o221a_2 _456_ (.A1(\A_reg[4] ),
    .A2(_002_),
    .B1(_044_),
    .B2(_103_),
    .C1(_105_),
    .X(_106_));
 sky130_fd_sc_hd__o21a_2 _457_ (.A1(_262_),
    .A2(_102_),
    .B1(_106_),
    .X(_107_));
 sky130_fd_sc_hd__o211ai_2 _458_ (.A1(_011_),
    .A2(_079_),
    .B1(_099_),
    .C1(_107_),
    .Y(\result_comb[4] ));
 sky130_fd_sc_hd__a22o_2 _459_ (.A1(\A_reg[4] ),
    .A2(_095_),
    .B1(_098_),
    .B2(_094_),
    .X(_108_));
 sky130_fd_sc_hd__mux2_1 _460_ (.A0(_031_),
    .A1(_030_),
    .S(\B_reg[5] ),
    .X(_109_));
 sky130_fd_sc_hd__and2_2 _461_ (.A(\A_reg[5] ),
    .B(_109_),
    .X(_110_));
 sky130_fd_sc_hd__nor2_2 _462_ (.A(_032_),
    .B(_110_),
    .Y(_111_));
 sky130_fd_sc_hd__o21a_2 _463_ (.A1(\A_reg[5] ),
    .A2(_109_),
    .B1(_111_),
    .X(_112_));
 sky130_fd_sc_hd__nand2_2 _464_ (.A(_108_),
    .B(_112_),
    .Y(_113_));
 sky130_fd_sc_hd__or2_2 _465_ (.A(_108_),
    .B(_112_),
    .X(_114_));
 sky130_fd_sc_hd__nor2_2 _466_ (.A(\B_reg[2] ),
    .B(_016_),
    .Y(_115_));
 sky130_fd_sc_hd__a211o_2 _467_ (.A1(\B_reg[2] ),
    .A2(_024_),
    .B1(_115_),
    .C1(\B_reg[3] ),
    .X(_116_));
 sky130_fd_sc_hd__o21ai_2 _468_ (.A1(_261_),
    .A2(_074_),
    .B1(_116_),
    .Y(_117_));
 sky130_fd_sc_hd__nor2_2 _469_ (.A(\B_reg[3] ),
    .B(_059_),
    .Y(_118_));
 sky130_fd_sc_hd__nor2_2 _470_ (.A(\A_reg[5] ),
    .B(_002_),
    .Y(_119_));
 sky130_fd_sc_hd__a21oi_2 _471_ (.A1(\A_reg[5] ),
    .A2(\B_reg[5] ),
    .B1(_047_),
    .Y(_120_));
 sky130_fd_sc_hd__o22a_2 _472_ (.A1(\A_reg[5] ),
    .A2(\B_reg[5] ),
    .B1(_045_),
    .B2(_120_),
    .X(_121_));
 sky130_fd_sc_hd__a311o_2 _473_ (.A1(\A_reg[5] ),
    .A2(\B_reg[5] ),
    .A3(_043_),
    .B1(_119_),
    .C1(_121_),
    .X(_122_));
 sky130_fd_sc_hd__a221o_2 _474_ (.A1(_113_),
    .A2(_114_),
    .B1(_118_),
    .B2(_262_),
    .C1(_122_),
    .X(_123_));
 sky130_fd_sc_hd__a21o_2 _475_ (.A1(_263_),
    .A2(_117_),
    .B1(_123_),
    .X(\result_comb[5] ));
 sky130_fd_sc_hd__a21o_2 _476_ (.A1(_108_),
    .A2(_112_),
    .B1(_110_),
    .X(_124_));
 sky130_fd_sc_hd__mux2_1 _477_ (.A0(_031_),
    .A1(_030_),
    .S(\B_reg[6] ),
    .X(_125_));
 sky130_fd_sc_hd__or2_2 _478_ (.A(\A_reg[6] ),
    .B(_125_),
    .X(_126_));
 sky130_fd_sc_hd__and2_2 _479_ (.A(\A_reg[6] ),
    .B(_125_),
    .X(_127_));
 sky130_fd_sc_hd__nor2_2 _480_ (.A(_032_),
    .B(_127_),
    .Y(_128_));
 sky130_fd_sc_hd__nand2_2 _481_ (.A(_126_),
    .B(_128_),
    .Y(_129_));
 sky130_fd_sc_hd__xor2_2 _482_ (.A(_124_),
    .B(_129_),
    .X(_130_));
 sky130_fd_sc_hd__nor2_2 _483_ (.A(\B_reg[2] ),
    .B(_054_),
    .Y(_131_));
 sky130_fd_sc_hd__a211o_2 _484_ (.A1(\B_reg[2] ),
    .A2(_058_),
    .B1(_131_),
    .C1(\B_reg[3] ),
    .X(_132_));
 sky130_fd_sc_hd__o21a_2 _485_ (.A1(_261_),
    .A2(_051_),
    .B1(_132_),
    .X(_133_));
 sky130_fd_sc_hd__nand2_2 _486_ (.A(\A_reg[6] ),
    .B(\B_reg[6] ),
    .Y(_134_));
 sky130_fd_sc_hd__nor2_2 _487_ (.A(\B_reg[3] ),
    .B(_028_),
    .Y(_135_));
 sky130_fd_sc_hd__nand2b_2 _488_ (.A_N(_047_),
    .B(_134_),
    .Y(_136_));
 sky130_fd_sc_hd__a2bb2o_2 _489_ (.A1_N(\A_reg[6] ),
    .A2_N(\B_reg[6] ),
    .B1(_046_),
    .B2(_136_),
    .X(_137_));
 sky130_fd_sc_hd__o221a_2 _490_ (.A1(\A_reg[6] ),
    .A2(_002_),
    .B1(_044_),
    .B2(_134_),
    .C1(_137_),
    .X(_138_));
 sky130_fd_sc_hd__o211a_2 _491_ (.A1(_262_),
    .A2(_133_),
    .B1(_138_),
    .C1(_130_),
    .X(_139_));
 sky130_fd_sc_hd__o21ai_2 _492_ (.A1(_011_),
    .A2(_028_),
    .B1(_139_),
    .Y(\result_comb[6] ));
 sky130_fd_sc_hd__a31o_2 _493_ (.A1(_033_),
    .A2(_124_),
    .A3(_126_),
    .B1(_127_),
    .X(_140_));
 sky130_fd_sc_hd__mux2_1 _494_ (.A0(_031_),
    .A1(_030_),
    .S(\B_reg[7] ),
    .X(_141_));
 sky130_fd_sc_hd__or2_2 _495_ (.A(\A_reg[7] ),
    .B(_141_),
    .X(_142_));
 sky130_fd_sc_hd__and2_2 _496_ (.A(\A_reg[7] ),
    .B(_141_),
    .X(_143_));
 sky130_fd_sc_hd__nor2_2 _497_ (.A(_032_),
    .B(_143_),
    .Y(_144_));
 sky130_fd_sc_hd__nand2_2 _498_ (.A(_142_),
    .B(_144_),
    .Y(_145_));
 sky130_fd_sc_hd__xnor2_2 _499_ (.A(_140_),
    .B(_145_),
    .Y(_146_));
 sky130_fd_sc_hd__mux2_1 _500_ (.A0(_076_),
    .A1(_078_),
    .S(\B_reg[2] ),
    .X(_147_));
 sky130_fd_sc_hd__mux2_1 _501_ (.A0(_010_),
    .A1(_147_),
    .S(_261_),
    .X(_148_));
 sky130_fd_sc_hd__nor2_2 _502_ (.A(\B_reg[3] ),
    .B(_301_),
    .Y(_149_));
 sky130_fd_sc_hd__nor2_2 _503_ (.A(\A_reg[7] ),
    .B(_002_),
    .Y(_150_));
 sky130_fd_sc_hd__a21oi_2 _504_ (.A1(\A_reg[7] ),
    .A2(\B_reg[7] ),
    .B1(_047_),
    .Y(_151_));
 sky130_fd_sc_hd__o22a_2 _505_ (.A1(\A_reg[7] ),
    .A2(\B_reg[7] ),
    .B1(_045_),
    .B2(_151_),
    .X(_152_));
 sky130_fd_sc_hd__mux2_1 _506_ (.A0(_148_),
    .A1(_149_),
    .S(_262_),
    .X(_153_));
 sky130_fd_sc_hd__or3_2 _507_ (.A(_146_),
    .B(_152_),
    .C(_153_),
    .X(_154_));
 sky130_fd_sc_hd__a311o_2 _508_ (.A1(\A_reg[7] ),
    .A2(\B_reg[7] ),
    .A3(_043_),
    .B1(_150_),
    .C1(_154_),
    .X(\result_comb[7] ));
 sky130_fd_sc_hd__a31o_2 _509_ (.A1(_033_),
    .A2(_140_),
    .A3(_142_),
    .B1(_143_),
    .X(_155_));
 sky130_fd_sc_hd__mux2_1 _510_ (.A0(_031_),
    .A1(_030_),
    .S(\B_reg[8] ),
    .X(_156_));
 sky130_fd_sc_hd__a21oi_2 _511_ (.A1(\A_reg[8] ),
    .A2(_156_),
    .B1(_032_),
    .Y(_157_));
 sky130_fd_sc_hd__o21a_2 _512_ (.A1(\A_reg[8] ),
    .A2(_156_),
    .B1(_157_),
    .X(_158_));
 sky130_fd_sc_hd__xor2_2 _513_ (.A(_155_),
    .B(_158_),
    .X(_159_));
 sky130_fd_sc_hd__nand2_2 _514_ (.A(_261_),
    .B(_263_),
    .Y(_160_));
 sky130_fd_sc_hd__nand2_2 _515_ (.A(\A_reg[8] ),
    .B(\B_reg[8] ),
    .Y(_161_));
 sky130_fd_sc_hd__nand2b_2 _516_ (.A_N(_047_),
    .B(_161_),
    .Y(_162_));
 sky130_fd_sc_hd__a2bb2o_2 _517_ (.A1_N(\A_reg[8] ),
    .A2_N(\B_reg[8] ),
    .B1(_046_),
    .B2(_162_),
    .X(_163_));
 sky130_fd_sc_hd__o221a_2 _518_ (.A1(\A_reg[8] ),
    .A2(_002_),
    .B1(_044_),
    .B2(_161_),
    .C1(_163_),
    .X(_164_));
 sky130_fd_sc_hd__o21ai_2 _519_ (.A1(_301_),
    .A2(_160_),
    .B1(_164_),
    .Y(_165_));
 sky130_fd_sc_hd__a211o_2 _520_ (.A1(_262_),
    .A2(_148_),
    .B1(_159_),
    .C1(_165_),
    .X(\result_comb[8] ));
 sky130_fd_sc_hd__a22o_2 _521_ (.A1(\A_reg[8] ),
    .A2(_156_),
    .B1(_158_),
    .B2(_155_),
    .X(_166_));
 sky130_fd_sc_hd__mux2_1 _522_ (.A0(_031_),
    .A1(_030_),
    .S(\B_reg[9] ),
    .X(_167_));
 sky130_fd_sc_hd__a21oi_2 _523_ (.A1(\A_reg[9] ),
    .A2(_167_),
    .B1(_032_),
    .Y(_168_));
 sky130_fd_sc_hd__o21a_2 _524_ (.A1(\A_reg[9] ),
    .A2(_167_),
    .B1(_168_),
    .X(_169_));
 sky130_fd_sc_hd__nor2_2 _525_ (.A(_166_),
    .B(_169_),
    .Y(_170_));
 sky130_fd_sc_hd__and2_2 _526_ (.A(_166_),
    .B(_169_),
    .X(_171_));
 sky130_fd_sc_hd__a21oi_2 _527_ (.A1(\A_reg[9] ),
    .A2(\B_reg[9] ),
    .B1(_047_),
    .Y(_172_));
 sky130_fd_sc_hd__o22a_2 _528_ (.A1(\A_reg[9] ),
    .A2(\B_reg[9] ),
    .B1(_045_),
    .B2(_172_),
    .X(_173_));
 sky130_fd_sc_hd__a31o_2 _529_ (.A1(\A_reg[9] ),
    .A2(\B_reg[9] ),
    .A3(_043_),
    .B1(_173_),
    .X(_174_));
 sky130_fd_sc_hd__a21oi_2 _530_ (.A1(_263_),
    .A2(_135_),
    .B1(_174_),
    .Y(_175_));
 sky130_fd_sc_hd__o221a_2 _531_ (.A1(_263_),
    .A2(_133_),
    .B1(_170_),
    .B2(_171_),
    .C1(_175_),
    .X(_176_));
 sky130_fd_sc_hd__o21ai_2 _532_ (.A1(\A_reg[9] ),
    .A2(_002_),
    .B1(_176_),
    .Y(\result_comb[9] ));
 sky130_fd_sc_hd__a22o_2 _533_ (.A1(\A_reg[9] ),
    .A2(_167_),
    .B1(_169_),
    .B2(_166_),
    .X(_177_));
 sky130_fd_sc_hd__mux2_1 _534_ (.A0(_031_),
    .A1(_030_),
    .S(\B_reg[10] ),
    .X(_178_));
 sky130_fd_sc_hd__a21oi_2 _535_ (.A1(\A_reg[10] ),
    .A2(_178_),
    .B1(_032_),
    .Y(_179_));
 sky130_fd_sc_hd__o21a_2 _536_ (.A1(\A_reg[10] ),
    .A2(_178_),
    .B1(_179_),
    .X(_180_));
 sky130_fd_sc_hd__xor2_2 _537_ (.A(_177_),
    .B(_180_),
    .X(_181_));
 sky130_fd_sc_hd__a21oi_2 _538_ (.A1(\A_reg[10] ),
    .A2(\B_reg[10] ),
    .B1(_047_),
    .Y(_182_));
 sky130_fd_sc_hd__o22a_2 _539_ (.A1(\A_reg[10] ),
    .A2(\B_reg[10] ),
    .B1(_045_),
    .B2(_182_),
    .X(_183_));
 sky130_fd_sc_hd__nor2_2 _540_ (.A(\A_reg[10] ),
    .B(_002_),
    .Y(_184_));
 sky130_fd_sc_hd__a31o_2 _541_ (.A1(\A_reg[10] ),
    .A2(\B_reg[10] ),
    .A3(_043_),
    .B1(_184_),
    .X(_185_));
 sky130_fd_sc_hd__a211o_2 _542_ (.A1(_263_),
    .A2(_118_),
    .B1(_183_),
    .C1(_185_),
    .X(_186_));
 sky130_fd_sc_hd__a211o_2 _543_ (.A1(_262_),
    .A2(_117_),
    .B1(_181_),
    .C1(_186_),
    .X(\result_comb[10] ));
 sky130_fd_sc_hd__a22o_2 _544_ (.A1(\A_reg[10] ),
    .A2(_178_),
    .B1(_180_),
    .B2(_177_),
    .X(_187_));
 sky130_fd_sc_hd__mux2_1 _545_ (.A0(_031_),
    .A1(_030_),
    .S(\B_reg[11] ),
    .X(_188_));
 sky130_fd_sc_hd__a21oi_2 _546_ (.A1(\A_reg[11] ),
    .A2(_188_),
    .B1(_032_),
    .Y(_189_));
 sky130_fd_sc_hd__o21a_2 _547_ (.A1(\A_reg[11] ),
    .A2(_188_),
    .B1(_189_),
    .X(_190_));
 sky130_fd_sc_hd__xnor2_2 _548_ (.A(_187_),
    .B(_190_),
    .Y(_191_));
 sky130_fd_sc_hd__nand2_2 _549_ (.A(\A_reg[11] ),
    .B(\B_reg[11] ),
    .Y(_192_));
 sky130_fd_sc_hd__nand2b_2 _550_ (.A_N(_047_),
    .B(_192_),
    .Y(_193_));
 sky130_fd_sc_hd__a2bb2o_2 _551_ (.A1_N(\A_reg[11] ),
    .A2_N(\B_reg[11] ),
    .B1(_046_),
    .B2(_193_),
    .X(_194_));
 sky130_fd_sc_hd__o221a_2 _552_ (.A1(\A_reg[11] ),
    .A2(_002_),
    .B1(_044_),
    .B2(_192_),
    .C1(_194_),
    .X(_195_));
 sky130_fd_sc_hd__o21a_2 _553_ (.A1(_079_),
    .A2(_160_),
    .B1(_195_),
    .X(_196_));
 sky130_fd_sc_hd__o211ai_2 _554_ (.A1(_263_),
    .A2(_102_),
    .B1(_191_),
    .C1(_196_),
    .Y(\result_comb[11] ));
 sky130_fd_sc_hd__a22o_2 _555_ (.A1(\A_reg[11] ),
    .A2(_188_),
    .B1(_190_),
    .B2(_187_),
    .X(_197_));
 sky130_fd_sc_hd__mux2_1 _556_ (.A0(_031_),
    .A1(_030_),
    .S(\B_reg[12] ),
    .X(_198_));
 sky130_fd_sc_hd__a21oi_2 _557_ (.A1(\A_reg[12] ),
    .A2(_198_),
    .B1(_032_),
    .Y(_199_));
 sky130_fd_sc_hd__o21a_2 _558_ (.A1(\A_reg[12] ),
    .A2(_198_),
    .B1(_199_),
    .X(_200_));
 sky130_fd_sc_hd__and2_2 _559_ (.A(_197_),
    .B(_200_),
    .X(_201_));
 sky130_fd_sc_hd__nor2_2 _560_ (.A(_197_),
    .B(_200_),
    .Y(_202_));
 sky130_fd_sc_hd__a21oi_2 _561_ (.A1(\A_reg[12] ),
    .A2(\B_reg[12] ),
    .B1(_047_),
    .Y(_203_));
 sky130_fd_sc_hd__o22a_2 _562_ (.A1(\A_reg[12] ),
    .A2(\B_reg[12] ),
    .B1(_045_),
    .B2(_203_),
    .X(_204_));
 sky130_fd_sc_hd__a31o_2 _563_ (.A1(\A_reg[12] ),
    .A2(\B_reg[12] ),
    .A3(_043_),
    .B1(_204_),
    .X(_205_));
 sky130_fd_sc_hd__o21ba_2 _564_ (.A1(_088_),
    .A2(_160_),
    .B1_N(_205_),
    .X(_206_));
 sky130_fd_sc_hd__o221a_2 _565_ (.A1(_263_),
    .A2(_082_),
    .B1(_201_),
    .B2(_202_),
    .C1(_206_),
    .X(_207_));
 sky130_fd_sc_hd__o21ai_2 _566_ (.A1(\A_reg[12] ),
    .A2(_002_),
    .B1(_207_),
    .Y(\result_comb[12] ));
 sky130_fd_sc_hd__a22o_2 _567_ (.A1(\A_reg[12] ),
    .A2(_198_),
    .B1(_200_),
    .B2(_197_),
    .X(_208_));
 sky130_fd_sc_hd__mux2_1 _568_ (.A0(_031_),
    .A1(_030_),
    .S(\B_reg[13] ),
    .X(_209_));
 sky130_fd_sc_hd__and2_2 _569_ (.A(\A_reg[13] ),
    .B(_209_),
    .X(_210_));
 sky130_fd_sc_hd__nor2_2 _570_ (.A(_032_),
    .B(_210_),
    .Y(_211_));
 sky130_fd_sc_hd__o21a_2 _571_ (.A1(\A_reg[13] ),
    .A2(_209_),
    .B1(_211_),
    .X(_212_));
 sky130_fd_sc_hd__xnor2_2 _572_ (.A(_208_),
    .B(_212_),
    .Y(_213_));
 sky130_fd_sc_hd__nand2_2 _573_ (.A(\A_reg[13] ),
    .B(\B_reg[13] ),
    .Y(_214_));
 sky130_fd_sc_hd__nand2b_2 _574_ (.A_N(_047_),
    .B(_214_),
    .Y(_215_));
 sky130_fd_sc_hd__a2bb2o_2 _575_ (.A1_N(\A_reg[13] ),
    .A2_N(\B_reg[13] ),
    .B1(_046_),
    .B2(_215_),
    .X(_216_));
 sky130_fd_sc_hd__o221a_2 _576_ (.A1(\A_reg[13] ),
    .A2(_002_),
    .B1(_044_),
    .B2(_214_),
    .C1(_216_),
    .X(_217_));
 sky130_fd_sc_hd__o21a_2 _577_ (.A1(_074_),
    .A2(_160_),
    .B1(_217_),
    .X(_218_));
 sky130_fd_sc_hd__o211ai_2 _578_ (.A1(_263_),
    .A2(_060_),
    .B1(_213_),
    .C1(_218_),
    .Y(\result_comb[13] ));
 sky130_fd_sc_hd__a21o_2 _579_ (.A1(_208_),
    .A2(_212_),
    .B1(_210_),
    .X(_219_));
 sky130_fd_sc_hd__mux2_1 _580_ (.A0(_031_),
    .A1(_030_),
    .S(\B_reg[14] ),
    .X(_220_));
 sky130_fd_sc_hd__a21oi_2 _581_ (.A1(\A_reg[14] ),
    .A2(_220_),
    .B1(_032_),
    .Y(_221_));
 sky130_fd_sc_hd__o21ai_2 _582_ (.A1(\A_reg[14] ),
    .A2(_220_),
    .B1(_221_),
    .Y(_222_));
 sky130_fd_sc_hd__inv_2 _583_ (.A(_222_),
    .Y(_223_));
 sky130_fd_sc_hd__xnor2_2 _584_ (.A(_219_),
    .B(_223_),
    .Y(_224_));
 sky130_fd_sc_hd__nand2_2 _585_ (.A(\A_reg[14] ),
    .B(\B_reg[14] ),
    .Y(_225_));
 sky130_fd_sc_hd__nand2b_2 _586_ (.A_N(_047_),
    .B(_225_),
    .Y(_226_));
 sky130_fd_sc_hd__a2bb2o_2 _587_ (.A1_N(\A_reg[14] ),
    .A2_N(\B_reg[14] ),
    .B1(_046_),
    .B2(_226_),
    .X(_227_));
 sky130_fd_sc_hd__o221a_2 _588_ (.A1(\A_reg[14] ),
    .A2(_002_),
    .B1(_044_),
    .B2(_225_),
    .C1(_227_),
    .X(_228_));
 sky130_fd_sc_hd__o21a_2 _589_ (.A1(_051_),
    .A2(_160_),
    .B1(_228_),
    .X(_229_));
 sky130_fd_sc_hd__o211ai_2 _590_ (.A1(_263_),
    .A2(_029_),
    .B1(_224_),
    .C1(_229_),
    .Y(\result_comb[14] ));
 sky130_fd_sc_hd__a22o_2 _591_ (.A1(\A_reg[14] ),
    .A2(_220_),
    .B1(_223_),
    .B2(_219_),
    .X(_230_));
 sky130_fd_sc_hd__mux2_1 _592_ (.A0(_031_),
    .A1(_030_),
    .S(\B_reg[15] ),
    .X(_231_));
 sky130_fd_sc_hd__and2_2 _593_ (.A(\A_reg[15] ),
    .B(_231_),
    .X(_232_));
 sky130_fd_sc_hd__nor2_2 _594_ (.A(_032_),
    .B(_232_),
    .Y(_233_));
 sky130_fd_sc_hd__o21ai_2 _595_ (.A1(\A_reg[15] ),
    .A2(_231_),
    .B1(_233_),
    .Y(_234_));
 sky130_fd_sc_hd__inv_2 _596_ (.A(_234_),
    .Y(_235_));
 sky130_fd_sc_hd__a221oi_2 _597_ (.A1(\A_reg[14] ),
    .A2(_220_),
    .B1(_223_),
    .B2(_219_),
    .C1(_235_),
    .Y(_236_));
 sky130_fd_sc_hd__xnor2_2 _598_ (.A(_230_),
    .B(_234_),
    .Y(_237_));
 sky130_fd_sc_hd__nor2_2 _599_ (.A(\A_reg[15] ),
    .B(\B_reg[15] ),
    .Y(_238_));
 sky130_fd_sc_hd__nand2_2 _600_ (.A(\A_reg[15] ),
    .B(\B_reg[15] ),
    .Y(_239_));
 sky130_fd_sc_hd__nand2b_2 _601_ (.A_N(_238_),
    .B(_239_),
    .Y(_240_));
 sky130_fd_sc_hd__o22a_2 _602_ (.A1(\A_reg[15] ),
    .A2(_002_),
    .B1(_044_),
    .B2(_239_),
    .X(_241_));
 sky130_fd_sc_hd__o221a_2 _603_ (.A1(_046_),
    .A2(_238_),
    .B1(_240_),
    .B2(_047_),
    .C1(_241_),
    .X(_242_));
 sky130_fd_sc_hd__nand2_2 _604_ (.A(_262_),
    .B(_001_),
    .Y(_243_));
 sky130_fd_sc_hd__o211a_2 _605_ (.A1(_009_),
    .A2(_160_),
    .B1(_242_),
    .C1(_243_),
    .X(_244_));
 sky130_fd_sc_hd__nand2b_2 _606_ (.A_N(_237_),
    .B(_244_),
    .Y(\result_comb[15] ));
 sky130_fd_sc_hd__or4_2 _607_ (.A(\result_comb[0] ),
    .B(\result_comb[1] ),
    .C(\result_comb[2] ),
    .D(\result_comb[3] ),
    .X(_245_));
 sky130_fd_sc_hd__or4_2 _608_ (.A(\result_comb[4] ),
    .B(\result_comb[5] ),
    .C(\result_comb[6] ),
    .D(_245_),
    .X(_246_));
 sky130_fd_sc_hd__or2_2 _609_ (.A(\result_comb[7] ),
    .B(_246_),
    .X(_247_));
 sky130_fd_sc_hd__or4_2 _610_ (.A(\result_comb[8] ),
    .B(\result_comb[9] ),
    .C(\result_comb[10] ),
    .D(_247_),
    .X(_248_));
 sky130_fd_sc_hd__or4_2 _611_ (.A(\result_comb[11] ),
    .B(\result_comb[12] ),
    .C(\result_comb[13] ),
    .D(_248_),
    .X(_249_));
 sky130_fd_sc_hd__nor4b_2 _612_ (.A(\result_comb[14] ),
    .B(_249_),
    .C(_237_),
    .D_N(_244_),
    .Y(_000_));
 sky130_fd_sc_hd__o211a_2 _613_ (.A1(\B_reg[0] ),
    .A2(_278_),
    .B1(_018_),
    .C1(\B_reg[1] ),
    .X(_250_));
 sky130_fd_sc_hd__nand2_2 _614_ (.A(\B_reg[2] ),
    .B(_075_),
    .Y(_251_));
 sky130_fd_sc_hd__a311o_2 _615_ (.A1(\B_reg[0] ),
    .A2(_259_),
    .A3(_280_),
    .B1(_250_),
    .C1(\B_reg[2] ),
    .X(_252_));
 sky130_fd_sc_hd__a31o_2 _616_ (.A1(_261_),
    .A2(_251_),
    .A3(_252_),
    .B1(_232_),
    .X(_253_));
 sky130_fd_sc_hd__a22o_2 _617_ (.A1(\B_reg[3] ),
    .A2(_147_),
    .B1(_230_),
    .B2(_235_),
    .X(_254_));
 sky130_fd_sc_hd__or2_2 _618_ (.A(_253_),
    .B(_254_),
    .X(carry_comb));
 sky130_fd_sc_hd__a211o_2 _619_ (.A1(_230_),
    .A2(_233_),
    .B1(_236_),
    .C1(_258_),
    .X(_255_));
 sky130_fd_sc_hd__mux2_1 _620_ (.A0(_031_),
    .A1(_030_),
    .S(_240_),
    .X(_256_));
 sky130_fd_sc_hd__o211a_2 _621_ (.A1(\A_reg[15] ),
    .A2(_237_),
    .B1(_255_),
    .C1(_256_),
    .X(overflow_comb));
 sky130_fd_sc_hd__dfxtp_2 _622_ (.CLK(clk),
    .D(\result_comb[15] ),
    .Q(N));
 sky130_fd_sc_hd__dfxtp_2 _623_ (.CLK(clk),
    .D(overflow_comb),
    .Q(V));
 sky130_fd_sc_hd__dfxtp_2 _624_ (.CLK(clk),
    .D(\result_comb[0] ),
    .Q(Y[0]));
 sky130_fd_sc_hd__dfxtp_2 _625_ (.CLK(clk),
    .D(\result_comb[1] ),
    .Q(Y[1]));
 sky130_fd_sc_hd__dfxtp_2 _626_ (.CLK(clk),
    .D(\result_comb[2] ),
    .Q(Y[2]));
 sky130_fd_sc_hd__dfxtp_2 _627_ (.CLK(clk),
    .D(\result_comb[3] ),
    .Q(Y[3]));
 sky130_fd_sc_hd__dfxtp_2 _628_ (.CLK(clk),
    .D(\result_comb[4] ),
    .Q(Y[4]));
 sky130_fd_sc_hd__dfxtp_2 _629_ (.CLK(clk),
    .D(\result_comb[5] ),
    .Q(Y[5]));
 sky130_fd_sc_hd__dfxtp_2 _630_ (.CLK(clk),
    .D(\result_comb[6] ),
    .Q(Y[6]));
 sky130_fd_sc_hd__dfxtp_2 _631_ (.CLK(clk),
    .D(\result_comb[7] ),
    .Q(Y[7]));
 sky130_fd_sc_hd__dfxtp_2 _632_ (.CLK(clk),
    .D(\result_comb[8] ),
    .Q(Y[8]));
 sky130_fd_sc_hd__dfxtp_2 _633_ (.CLK(clk),
    .D(\result_comb[9] ),
    .Q(Y[9]));
 sky130_fd_sc_hd__dfxtp_2 _634_ (.CLK(clk),
    .D(\result_comb[10] ),
    .Q(Y[10]));
 sky130_fd_sc_hd__dfxtp_2 _635_ (.CLK(clk),
    .D(\result_comb[11] ),
    .Q(Y[11]));
 sky130_fd_sc_hd__dfxtp_2 _636_ (.CLK(clk),
    .D(\result_comb[12] ),
    .Q(Y[12]));
 sky130_fd_sc_hd__dfxtp_2 _637_ (.CLK(clk),
    .D(\result_comb[13] ),
    .Q(Y[13]));
 sky130_fd_sc_hd__dfxtp_2 _638_ (.CLK(clk),
    .D(\result_comb[14] ),
    .Q(Y[14]));
 sky130_fd_sc_hd__dfxtp_2 _639_ (.CLK(clk),
    .D(_000_),
    .Q(Z));
 sky130_fd_sc_hd__dfxtp_2 _640_ (.CLK(clk),
    .D(A[0]),
    .Q(\A_reg[0] ));
 sky130_fd_sc_hd__dfxtp_2 _641_ (.CLK(clk),
    .D(A[1]),
    .Q(\A_reg[1] ));
 sky130_fd_sc_hd__dfxtp_2 _642_ (.CLK(clk),
    .D(A[2]),
    .Q(\A_reg[2] ));
 sky130_fd_sc_hd__dfxtp_2 _643_ (.CLK(clk),
    .D(A[3]),
    .Q(\A_reg[3] ));
 sky130_fd_sc_hd__dfxtp_2 _644_ (.CLK(clk),
    .D(A[4]),
    .Q(\A_reg[4] ));
 sky130_fd_sc_hd__dfxtp_2 _645_ (.CLK(clk),
    .D(A[5]),
    .Q(\A_reg[5] ));
 sky130_fd_sc_hd__dfxtp_2 _646_ (.CLK(clk),
    .D(A[6]),
    .Q(\A_reg[6] ));
 sky130_fd_sc_hd__dfxtp_2 _647_ (.CLK(clk),
    .D(A[7]),
    .Q(\A_reg[7] ));
 sky130_fd_sc_hd__dfxtp_2 _648_ (.CLK(clk),
    .D(A[8]),
    .Q(\A_reg[8] ));
 sky130_fd_sc_hd__dfxtp_2 _649_ (.CLK(clk),
    .D(A[9]),
    .Q(\A_reg[9] ));
 sky130_fd_sc_hd__dfxtp_2 _650_ (.CLK(clk),
    .D(A[10]),
    .Q(\A_reg[10] ));
 sky130_fd_sc_hd__dfxtp_2 _651_ (.CLK(clk),
    .D(A[11]),
    .Q(\A_reg[11] ));
 sky130_fd_sc_hd__dfxtp_2 _652_ (.CLK(clk),
    .D(A[12]),
    .Q(\A_reg[12] ));
 sky130_fd_sc_hd__dfxtp_2 _653_ (.CLK(clk),
    .D(A[13]),
    .Q(\A_reg[13] ));
 sky130_fd_sc_hd__dfxtp_2 _654_ (.CLK(clk),
    .D(A[14]),
    .Q(\A_reg[14] ));
 sky130_fd_sc_hd__dfxtp_2 _655_ (.CLK(clk),
    .D(A[15]),
    .Q(\A_reg[15] ));
 sky130_fd_sc_hd__dfxtp_2 _656_ (.CLK(clk),
    .D(B[0]),
    .Q(\B_reg[0] ));
 sky130_fd_sc_hd__dfxtp_2 _657_ (.CLK(clk),
    .D(B[1]),
    .Q(\B_reg[1] ));
 sky130_fd_sc_hd__dfxtp_2 _658_ (.CLK(clk),
    .D(B[2]),
    .Q(\B_reg[2] ));
 sky130_fd_sc_hd__dfxtp_2 _659_ (.CLK(clk),
    .D(B[3]),
    .Q(\B_reg[3] ));
 sky130_fd_sc_hd__dfxtp_2 _660_ (.CLK(clk),
    .D(B[4]),
    .Q(\B_reg[4] ));
 sky130_fd_sc_hd__dfxtp_2 _661_ (.CLK(clk),
    .D(B[5]),
    .Q(\B_reg[5] ));
 sky130_fd_sc_hd__dfxtp_2 _662_ (.CLK(clk),
    .D(B[6]),
    .Q(\B_reg[6] ));
 sky130_fd_sc_hd__dfxtp_2 _663_ (.CLK(clk),
    .D(B[7]),
    .Q(\B_reg[7] ));
 sky130_fd_sc_hd__dfxtp_2 _664_ (.CLK(clk),
    .D(B[8]),
    .Q(\B_reg[8] ));
 sky130_fd_sc_hd__dfxtp_2 _665_ (.CLK(clk),
    .D(B[9]),
    .Q(\B_reg[9] ));
 sky130_fd_sc_hd__dfxtp_2 _666_ (.CLK(clk),
    .D(B[10]),
    .Q(\B_reg[10] ));
 sky130_fd_sc_hd__dfxtp_2 _667_ (.CLK(clk),
    .D(B[11]),
    .Q(\B_reg[11] ));
 sky130_fd_sc_hd__dfxtp_2 _668_ (.CLK(clk),
    .D(B[12]),
    .Q(\B_reg[12] ));
 sky130_fd_sc_hd__dfxtp_2 _669_ (.CLK(clk),
    .D(B[13]),
    .Q(\B_reg[13] ));
 sky130_fd_sc_hd__dfxtp_2 _670_ (.CLK(clk),
    .D(B[14]),
    .Q(\B_reg[14] ));
 sky130_fd_sc_hd__dfxtp_2 _671_ (.CLK(clk),
    .D(B[15]),
    .Q(\B_reg[15] ));
 sky130_fd_sc_hd__dfxtp_2 _672_ (.CLK(clk),
    .D(opcode[0]),
    .Q(\opcode_reg[0] ));
 sky130_fd_sc_hd__dfxtp_2 _673_ (.CLK(clk),
    .D(opcode[1]),
    .Q(\opcode_reg[1] ));
 sky130_fd_sc_hd__dfxtp_2 _674_ (.CLK(clk),
    .D(opcode[2]),
    .Q(\opcode_reg[2] ));
 sky130_fd_sc_hd__dfxtp_2 _675_ (.CLK(clk),
    .D(carry_comb),
    .Q(C));
 sky130_fd_sc_hd__buf_2 _676_ (.A(N),
    .X(Y[15]));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_0_Right_0 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_1_Right_1 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_2_Right_2 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_3_Right_3 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_4_Right_4 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_5_Right_5 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_6_Right_6 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_7_Right_7 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_8_Right_8 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_9_Right_9 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_10_Right_10 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_11_Right_11 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_12_Right_12 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_13_Right_13 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_14_Right_14 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_15_Right_15 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_16_Right_16 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_17_Right_17 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_18_Right_18 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_19_Right_19 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_20_Right_20 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_21_Right_21 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_22_Right_22 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_23_Right_23 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_24_Right_24 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_25_Right_25 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_Right_26 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_Right_27 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_Right_28 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_Right_29 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_Right_30 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_31_Right_31 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_32_Right_32 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_33_Right_33 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_34_Right_34 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_35_Right_35 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_36_Right_36 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_37_Right_37 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_38_Right_38 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_39_Right_39 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_0_Left_40 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_1_Left_41 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_2_Left_42 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_3_Left_43 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_4_Left_44 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_5_Left_45 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_6_Left_46 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_7_Left_47 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_8_Left_48 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_9_Left_49 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_10_Left_50 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_11_Left_51 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_12_Left_52 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_13_Left_53 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_14_Left_54 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_15_Left_55 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_16_Left_56 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_17_Left_57 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_18_Left_58 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_19_Left_59 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_20_Left_60 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_21_Left_61 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_22_Left_62 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_23_Left_63 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_24_Left_64 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_25_Left_65 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_Left_66 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_Left_67 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_Left_68 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_Left_69 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_Left_70 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_31_Left_71 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_32_Left_72 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_33_Left_73 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_34_Left_74 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_35_Left_75 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_36_Left_76 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_37_Left_77 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_38_Left_78 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_39_Left_79 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_80 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_81 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_82 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_83 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_84 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_85 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_86 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_87 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_88 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_89 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_90 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_91 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_92 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_93 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_94 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_95 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_96 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_97 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_98 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_99 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_100 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_101 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_102 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_103 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_104 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_105 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_106 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_107 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_108 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_109 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_110 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_111 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_112 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_113 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_114 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_115 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_116 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_117 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_118 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_119 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_120 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_121 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_122 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_123 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_124 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_125 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_126 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_127 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_128 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_129 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_130 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_131 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_132 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_133 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_134 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_135 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_136 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_137 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_138 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_139 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_140 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_141 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_142 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_143 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_144 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_145 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_146 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_147 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_148 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_149 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_150 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_151 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_152 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_153 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_154 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_155 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_156 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_157 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_158 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_159 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_160 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_161 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_162 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_163 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_164 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_165 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_166 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_167 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_168 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_169 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_170 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_171 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_172 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_173 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_174 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_175 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_176 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_177 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_178 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_179 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_180 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_181 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_182 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_183 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_184 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_185 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_186 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_187 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_188 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_189 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_190 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_191 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_192 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_193 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_194 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_195 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_196 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_197 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_198 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_199 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_200 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_201 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_202 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_203 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_204 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_205 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_206 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_207 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_208 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_209 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_210 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_211 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_212 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_213 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_214 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_215 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_216 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_217 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_218 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_219 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_220 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_221 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_222 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_223 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_224 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_225 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_226 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_227 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_228 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_229 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_230 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_231 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_232 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_233 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_234 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_235 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_236 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_237 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_238 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_239 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_240 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_241 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_242 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_243 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_244 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_245 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_246 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_247 ();
endmodule
