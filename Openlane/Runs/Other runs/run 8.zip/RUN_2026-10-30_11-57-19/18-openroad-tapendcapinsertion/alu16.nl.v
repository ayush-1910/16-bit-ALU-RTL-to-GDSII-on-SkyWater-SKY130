module alu16 (C,
    N,
    V,
    Z,
    clk,
    A,
    B,
    Y,
    opcode);
 output C;
 output N;
 output V;
 output Z;
 input clk;
 input [15:0] A;
 input [15:0] B;
 output [15:0] Y;
 input [2:0] opcode;

 wire \A_reg[0] ;
 wire \A_reg[10] ;
 wire \A_reg[11] ;
 wire \A_reg[12] ;
 wire \A_reg[13] ;
 wire \A_reg[14] ;
 wire \A_reg[15] ;
 wire \A_reg[1] ;
 wire \A_reg[2] ;
 wire \A_reg[3] ;
 wire \A_reg[4] ;
 wire \A_reg[5] ;
 wire \A_reg[6] ;
 wire \A_reg[7] ;
 wire \A_reg[8] ;
 wire \A_reg[9] ;
 wire \B_reg[0] ;
 wire \B_reg[10] ;
 wire \B_reg[11] ;
 wire \B_reg[12] ;
 wire \B_reg[13] ;
 wire \B_reg[14] ;
 wire \B_reg[15] ;
 wire \B_reg[1] ;
 wire \B_reg[2] ;
 wire \B_reg[3] ;
 wire \B_reg[4] ;
 wire \B_reg[5] ;
 wire \B_reg[6] ;
 wire \B_reg[7] ;
 wire \B_reg[8] ;
 wire \B_reg[9] ;
 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _070_;
 wire _071_;
 wire _072_;
 wire _073_;
 wire _074_;
 wire _075_;
 wire _076_;
 wire _077_;
 wire _078_;
 wire _079_;
 wire _080_;
 wire _081_;
 wire _082_;
 wire _083_;
 wire _084_;
 wire _085_;
 wire _086_;
 wire _087_;
 wire _088_;
 wire _089_;
 wire _090_;
 wire _091_;
 wire _092_;
 wire _093_;
 wire _094_;
 wire _095_;
 wire _096_;
 wire _097_;
 wire _098_;
 wire _099_;
 wire _100_;
 wire _101_;
 wire _102_;
 wire _103_;
 wire _104_;
 wire _105_;
 wire _106_;
 wire _107_;
 wire _108_;
 wire _109_;
 wire _110_;
 wire _111_;
 wire _112_;
 wire _113_;
 wire _114_;
 wire _115_;
 wire _116_;
 wire _117_;
 wire _118_;
 wire _119_;
 wire _120_;
 wire _121_;
 wire _122_;
 wire _123_;
 wire _124_;
 wire _125_;
 wire _126_;
 wire _127_;
 wire _128_;
 wire _129_;
 wire _130_;
 wire _131_;
 wire _132_;
 wire _133_;
 wire _134_;
 wire _135_;
 wire _136_;
 wire _137_;
 wire _138_;
 wire _139_;
 wire _140_;
 wire _141_;
 wire _142_;
 wire _143_;
 wire _144_;
 wire _145_;
 wire _146_;
 wire _147_;
 wire _148_;
 wire _149_;
 wire _150_;
 wire _151_;
 wire _152_;
 wire _153_;
 wire _154_;
 wire _155_;
 wire _156_;
 wire _157_;
 wire _158_;
 wire _159_;
 wire _160_;
 wire _161_;
 wire _162_;
 wire _163_;
 wire _164_;
 wire _165_;
 wire _166_;
 wire _167_;
 wire _168_;
 wire _169_;
 wire _170_;
 wire _171_;
 wire _172_;
 wire _173_;
 wire _174_;
 wire _175_;
 wire _176_;
 wire _177_;
 wire _178_;
 wire _179_;
 wire _180_;
 wire _181_;
 wire _182_;
 wire _183_;
 wire _184_;
 wire _185_;
 wire _186_;
 wire _187_;
 wire _188_;
 wire _189_;
 wire _190_;
 wire _191_;
 wire _192_;
 wire _193_;
 wire _194_;
 wire _195_;
 wire _196_;
 wire _197_;
 wire _198_;
 wire _199_;
 wire _200_;
 wire _201_;
 wire _202_;
 wire _203_;
 wire _204_;
 wire _205_;
 wire _206_;
 wire _207_;
 wire _208_;
 wire _209_;
 wire _210_;
 wire _211_;
 wire _212_;
 wire _213_;
 wire _214_;
 wire _215_;
 wire _216_;
 wire _217_;
 wire _218_;
 wire _219_;
 wire _220_;
 wire _221_;
 wire _222_;
 wire _223_;
 wire _224_;
 wire _225_;
 wire _226_;
 wire _227_;
 wire _228_;
 wire _229_;
 wire _230_;
 wire _231_;
 wire _232_;
 wire _233_;
 wire _234_;
 wire _235_;
 wire _236_;
 wire _237_;
 wire _238_;
 wire _239_;
 wire _240_;
 wire _241_;
 wire _242_;
 wire _243_;
 wire _244_;
 wire _245_;
 wire _246_;
 wire _247_;
 wire _248_;
 wire _249_;
 wire _250_;
 wire _251_;
 wire _252_;
 wire _253_;
 wire _254_;
 wire _255_;
 wire _256_;
 wire _257_;
 wire _258_;
 wire _259_;
 wire _260_;
 wire _261_;
 wire _262_;
 wire _263_;
 wire _264_;
 wire _265_;
 wire _266_;
 wire _267_;
 wire _268_;
 wire _269_;
 wire _270_;
 wire _271_;
 wire _272_;
 wire _273_;
 wire _274_;
 wire _275_;
 wire _276_;
 wire _277_;
 wire _278_;
 wire _279_;
 wire _280_;
 wire _281_;
 wire _282_;
 wire _283_;
 wire _284_;
 wire _285_;
 wire _286_;
 wire _287_;
 wire _288_;
 wire _289_;
 wire _290_;
 wire _291_;
 wire _292_;
 wire _293_;
 wire _294_;
 wire _295_;
 wire _296_;
 wire _297_;
 wire _298_;
 wire _299_;
 wire _300_;
 wire _301_;
 wire _302_;
 wire _303_;
 wire _304_;
 wire _305_;
 wire _306_;
 wire _307_;
 wire _308_;
 wire _309_;
 wire _310_;
 wire _311_;
 wire _312_;
 wire _313_;
 wire _314_;
 wire _315_;
 wire _316_;
 wire _317_;
 wire carry_comb;
 wire \opcode_reg[0] ;
 wire \opcode_reg[1] ;
 wire \opcode_reg[2] ;
 wire \result_comb[0] ;
 wire \result_comb[10] ;
 wire \result_comb[11] ;
 wire \result_comb[12] ;
 wire \result_comb[13] ;
 wire \result_comb[14] ;
 wire \result_comb[15] ;
 wire \result_comb[1] ;
 wire \result_comb[2] ;
 wire \result_comb[3] ;
 wire \result_comb[4] ;
 wire \result_comb[5] ;
 wire \result_comb[6] ;
 wire \result_comb[7] ;
 wire \result_comb[8] ;
 wire \result_comb[9] ;

 sky130_fd_sc_hd__inv_2 _318_ (.A(\B_reg[3] ),
    .Y(_273_));
 sky130_fd_sc_hd__inv_2 _319_ (.A(\B_reg[2] ),
    .Y(_274_));
 sky130_fd_sc_hd__inv_2 _320_ (.A(\B_reg[1] ),
    .Y(_275_));
 sky130_fd_sc_hd__inv_2 _321_ (.A(\A_reg[1] ),
    .Y(_276_));
 sky130_fd_sc_hd__inv_2 _322_ (.A(\A_reg[14] ),
    .Y(_277_));
 sky130_fd_sc_hd__inv_2 _323_ (.A(\A_reg[15] ),
    .Y(_278_));
 sky130_fd_sc_hd__or2_2 _324_ (.A(\A_reg[0] ),
    .B(\B_reg[0] ),
    .X(_279_));
 sky130_fd_sc_hd__nand2_2 _325_ (.A(\A_reg[0] ),
    .B(\B_reg[0] ),
    .Y(_280_));
 sky130_fd_sc_hd__nor2_2 _326_ (.A(\opcode_reg[1] ),
    .B(\opcode_reg[2] ),
    .Y(_281_));
 sky130_fd_sc_hd__or2_2 _327_ (.A(\opcode_reg[1] ),
    .B(\opcode_reg[2] ),
    .X(_282_));
 sky130_fd_sc_hd__a21o_2 _328_ (.A1(_279_),
    .A2(_280_),
    .B1(_282_),
    .X(_283_));
 sky130_fd_sc_hd__mux4_2 _329_ (.A0(\A_reg[8] ),
    .A1(\A_reg[9] ),
    .A2(\A_reg[10] ),
    .A3(\A_reg[11] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .X(_284_));
 sky130_fd_sc_hd__mux2_1 _330_ (.A0(_277_),
    .A1(_278_),
    .S(\B_reg[0] ),
    .X(_285_));
 sky130_fd_sc_hd__mux4_2 _331_ (.A0(\A_reg[12] ),
    .A1(\A_reg[13] ),
    .A2(\A_reg[14] ),
    .A3(\A_reg[15] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .X(_286_));
 sky130_fd_sc_hd__mux2_1 _332_ (.A0(_284_),
    .A1(_286_),
    .S(\B_reg[2] ),
    .X(_287_));
 sky130_fd_sc_hd__nand2_2 _333_ (.A(\opcode_reg[1] ),
    .B(\opcode_reg[2] ),
    .Y(_288_));
 sky130_fd_sc_hd__and3_2 _334_ (.A(\opcode_reg[0] ),
    .B(\opcode_reg[1] ),
    .C(\opcode_reg[2] ),
    .X(_289_));
 sky130_fd_sc_hd__nand2_2 _335_ (.A(\B_reg[3] ),
    .B(_289_),
    .Y(_290_));
 sky130_fd_sc_hd__and3_2 _336_ (.A(\B_reg[3] ),
    .B(_287_),
    .C(_289_),
    .X(_291_));
 sky130_fd_sc_hd__or2_2 _337_ (.A(\B_reg[0] ),
    .B(\B_reg[1] ),
    .X(_292_));
 sky130_fd_sc_hd__nor2_2 _338_ (.A(\B_reg[2] ),
    .B(_292_),
    .Y(_293_));
 sky130_fd_sc_hd__or2_2 _339_ (.A(\B_reg[2] ),
    .B(_292_),
    .X(_294_));
 sky130_fd_sc_hd__nor2_2 _340_ (.A(\B_reg[3] ),
    .B(_294_),
    .Y(_295_));
 sky130_fd_sc_hd__and2b_2 _341_ (.A_N(\opcode_reg[1] ),
    .B(\opcode_reg[2] ),
    .X(_296_));
 sky130_fd_sc_hd__and2b_2 _342_ (.A_N(\opcode_reg[0] ),
    .B(_296_),
    .X(_297_));
 sky130_fd_sc_hd__and3_2 _343_ (.A(_279_),
    .B(_280_),
    .C(_297_),
    .X(_298_));
 sky130_fd_sc_hd__and2b_2 _344_ (.A_N(\opcode_reg[2] ),
    .B(\opcode_reg[0] ),
    .X(_299_));
 sky130_fd_sc_hd__nor3b_2 _345_ (.A(\opcode_reg[0] ),
    .B(\opcode_reg[2] ),
    .C_N(\opcode_reg[1] ),
    .Y(_300_));
 sky130_fd_sc_hd__nand2_2 _346_ (.A(\opcode_reg[0] ),
    .B(_296_),
    .Y(_301_));
 sky130_fd_sc_hd__inv_2 _347_ (.A(_301_),
    .Y(_302_));
 sky130_fd_sc_hd__nor2_2 _348_ (.A(\A_reg[0] ),
    .B(_301_),
    .Y(_303_));
 sky130_fd_sc_hd__a31o_2 _349_ (.A1(\A_reg[0] ),
    .A2(\B_reg[0] ),
    .A3(_300_),
    .B1(_303_),
    .X(_304_));
 sky130_fd_sc_hd__a2111o_2 _350_ (.A1(_279_),
    .A2(_299_),
    .B1(_304_),
    .C1(_281_),
    .D1(_298_),
    .X(_305_));
 sky130_fd_sc_hd__a41o_2 _351_ (.A1(\opcode_reg[1] ),
    .A2(\opcode_reg[2] ),
    .A3(\A_reg[0] ),
    .A4(_295_),
    .B1(_305_),
    .X(_306_));
 sky130_fd_sc_hd__mux2_1 _352_ (.A0(\A_reg[2] ),
    .A1(\A_reg[3] ),
    .S(\B_reg[0] ),
    .X(_307_));
 sky130_fd_sc_hd__or2_2 _353_ (.A(\B_reg[1] ),
    .B(\A_reg[1] ),
    .X(_308_));
 sky130_fd_sc_hd__o211a_2 _354_ (.A1(_275_),
    .A2(_307_),
    .B1(_308_),
    .C1(_292_),
    .X(_309_));
 sky130_fd_sc_hd__and2_2 _355_ (.A(_273_),
    .B(_289_),
    .X(_310_));
 sky130_fd_sc_hd__nand2_2 _356_ (.A(_273_),
    .B(_289_),
    .Y(_311_));
 sky130_fd_sc_hd__nor2_2 _357_ (.A(\B_reg[2] ),
    .B(_311_),
    .Y(_312_));
 sky130_fd_sc_hd__mux4_2 _358_ (.A0(\A_reg[4] ),
    .A1(\A_reg[5] ),
    .A2(\A_reg[6] ),
    .A3(\A_reg[7] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .X(_313_));
 sky130_fd_sc_hd__nor2_2 _359_ (.A(_274_),
    .B(_311_),
    .Y(_314_));
 sky130_fd_sc_hd__a221o_2 _360_ (.A1(_309_),
    .A2(_312_),
    .B1(_313_),
    .B2(_314_),
    .C1(_306_),
    .X(_315_));
 sky130_fd_sc_hd__and2_2 _361_ (.A(\opcode_reg[1] ),
    .B(_299_),
    .X(_316_));
 sky130_fd_sc_hd__or2_2 _362_ (.A(\opcode_reg[0] ),
    .B(_288_),
    .X(_317_));
 sky130_fd_sc_hd__nor2_2 _363_ (.A(\B_reg[3] ),
    .B(_317_),
    .Y(_002_));
 sky130_fd_sc_hd__or2_2 _364_ (.A(\B_reg[3] ),
    .B(_317_),
    .X(_003_));
 sky130_fd_sc_hd__o21a_2 _365_ (.A1(_291_),
    .A2(_315_),
    .B1(_283_),
    .X(\result_comb[0] ));
 sky130_fd_sc_hd__or3b_2 _366_ (.A(\opcode_reg[1] ),
    .B(\opcode_reg[2] ),
    .C_N(\opcode_reg[0] ),
    .X(_004_));
 sky130_fd_sc_hd__xnor2_2 _367_ (.A(_275_),
    .B(_004_),
    .Y(_005_));
 sky130_fd_sc_hd__nor2_2 _368_ (.A(_276_),
    .B(_005_),
    .Y(_006_));
 sky130_fd_sc_hd__xnor2_2 _369_ (.A(\A_reg[1] ),
    .B(_005_),
    .Y(_007_));
 sky130_fd_sc_hd__o21ai_2 _370_ (.A1(\B_reg[0] ),
    .A2(_004_),
    .B1(_280_),
    .Y(_008_));
 sky130_fd_sc_hd__xor2_2 _371_ (.A(_007_),
    .B(_008_),
    .X(_009_));
 sky130_fd_sc_hd__mux4_2 _372_ (.A0(\A_reg[1] ),
    .A1(\A_reg[2] ),
    .A2(\A_reg[3] ),
    .A3(\A_reg[4] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .X(_010_));
 sky130_fd_sc_hd__mux4_2 _373_ (.A0(\A_reg[5] ),
    .A1(\A_reg[6] ),
    .A2(\A_reg[7] ),
    .A3(\A_reg[8] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .X(_011_));
 sky130_fd_sc_hd__a22o_2 _374_ (.A1(_312_),
    .A2(_010_),
    .B1(_011_),
    .B2(_314_),
    .X(_012_));
 sky130_fd_sc_hd__o21a_2 _375_ (.A1(\B_reg[0] ),
    .A2(_276_),
    .B1(_280_),
    .X(_013_));
 sky130_fd_sc_hd__nor2_2 _376_ (.A(\B_reg[1] ),
    .B(_013_),
    .Y(_014_));
 sky130_fd_sc_hd__nor2_2 _377_ (.A(\B_reg[2] ),
    .B(_003_),
    .Y(_015_));
 sky130_fd_sc_hd__a221o_2 _378_ (.A1(_276_),
    .A2(_302_),
    .B1(_308_),
    .B2(_299_),
    .C1(_281_),
    .X(_016_));
 sky130_fd_sc_hd__a211o_2 _379_ (.A1(_014_),
    .A2(_015_),
    .B1(_016_),
    .C1(_012_),
    .X(_017_));
 sky130_fd_sc_hd__a21o_2 _380_ (.A1(_300_),
    .A2(_006_),
    .B1(_017_),
    .X(_018_));
 sky130_fd_sc_hd__mux2_1 _381_ (.A0(\A_reg[11] ),
    .A1(\A_reg[12] ),
    .S(\B_reg[0] ),
    .X(_019_));
 sky130_fd_sc_hd__mux4_2 _382_ (.A0(\A_reg[9] ),
    .A1(\A_reg[10] ),
    .A2(\A_reg[11] ),
    .A3(\A_reg[12] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .X(_020_));
 sky130_fd_sc_hd__or2_2 _383_ (.A(\B_reg[2] ),
    .B(_020_),
    .X(_021_));
 sky130_fd_sc_hd__mux2_1 _384_ (.A0(\A_reg[13] ),
    .A1(\A_reg[14] ),
    .S(\B_reg[0] ),
    .X(_022_));
 sky130_fd_sc_hd__nand2_2 _385_ (.A(\B_reg[1] ),
    .B(\A_reg[15] ),
    .Y(_023_));
 sky130_fd_sc_hd__a2bb2o_2 _386_ (.A1_N(\B_reg[0] ),
    .A2_N(_023_),
    .B1(_022_),
    .B2(_275_),
    .X(_024_));
 sky130_fd_sc_hd__o21ai_2 _387_ (.A1(_274_),
    .A2(_024_),
    .B1(_021_),
    .Y(_025_));
 sky130_fd_sc_hd__o2bb2ai_2 _388_ (.A1_N(_297_),
    .A2_N(_007_),
    .B1(_025_),
    .B2(_290_),
    .Y(_026_));
 sky130_fd_sc_hd__o22a_2 _389_ (.A1(_282_),
    .A2(_009_),
    .B1(_018_),
    .B2(_026_),
    .X(\result_comb[1] ));
 sky130_fd_sc_hd__xnor2_2 _390_ (.A(_274_),
    .B(_004_),
    .Y(_027_));
 sky130_fd_sc_hd__and2b_2 _391_ (.A_N(_027_),
    .B(\A_reg[2] ),
    .X(_028_));
 sky130_fd_sc_hd__and2b_2 _392_ (.A_N(\A_reg[2] ),
    .B(_027_),
    .X(_029_));
 sky130_fd_sc_hd__nor2_2 _393_ (.A(_028_),
    .B(_029_),
    .Y(_030_));
 sky130_fd_sc_hd__a21o_2 _394_ (.A1(_007_),
    .A2(_008_),
    .B1(_006_),
    .X(_031_));
 sky130_fd_sc_hd__xor2_2 _395_ (.A(_030_),
    .B(_031_),
    .X(_032_));
 sky130_fd_sc_hd__mux4_2 _396_ (.A0(\A_reg[10] ),
    .A1(\A_reg[11] ),
    .A2(\A_reg[12] ),
    .A3(\A_reg[13] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .X(_033_));
 sky130_fd_sc_hd__nor2_2 _397_ (.A(\B_reg[1] ),
    .B(_285_),
    .Y(_034_));
 sky130_fd_sc_hd__mux2_1 _398_ (.A0(_033_),
    .A1(_034_),
    .S(\B_reg[2] ),
    .X(_035_));
 sky130_fd_sc_hd__o21ai_2 _399_ (.A1(\B_reg[2] ),
    .A2(\A_reg[2] ),
    .B1(_299_),
    .Y(_036_));
 sky130_fd_sc_hd__o211ai_2 _400_ (.A1(\A_reg[2] ),
    .A2(_301_),
    .B1(_036_),
    .C1(_282_),
    .Y(_037_));
 sky130_fd_sc_hd__mux4_2 _401_ (.A0(\A_reg[6] ),
    .A1(\A_reg[7] ),
    .A2(\A_reg[8] ),
    .A3(\A_reg[9] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .X(_038_));
 sky130_fd_sc_hd__mux2_1 _402_ (.A0(\A_reg[2] ),
    .A1(\A_reg[1] ),
    .S(\B_reg[0] ),
    .X(_039_));
 sky130_fd_sc_hd__and3b_2 _403_ (.A_N(\B_reg[0] ),
    .B(\B_reg[1] ),
    .C(\A_reg[0] ),
    .X(_040_));
 sky130_fd_sc_hd__a21oi_2 _404_ (.A1(_275_),
    .A2(_039_),
    .B1(_040_),
    .Y(_041_));
 sky130_fd_sc_hd__inv_2 _405_ (.A(_041_),
    .Y(_042_));
 sky130_fd_sc_hd__mux4_2 _406_ (.A0(\A_reg[2] ),
    .A1(\A_reg[3] ),
    .A2(\A_reg[4] ),
    .A3(\A_reg[5] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .X(_043_));
 sky130_fd_sc_hd__a32o_2 _407_ (.A1(\B_reg[3] ),
    .A2(_289_),
    .A3(_035_),
    .B1(_038_),
    .B2(_314_),
    .X(_044_));
 sky130_fd_sc_hd__a221o_2 _408_ (.A1(_300_),
    .A2(_028_),
    .B1(_042_),
    .B2(_015_),
    .C1(_037_),
    .X(_045_));
 sky130_fd_sc_hd__a221o_2 _409_ (.A1(_297_),
    .A2(_030_),
    .B1(_043_),
    .B2(_312_),
    .C1(_045_),
    .X(_046_));
 sky130_fd_sc_hd__o22a_2 _410_ (.A1(_282_),
    .A2(_032_),
    .B1(_044_),
    .B2(_046_),
    .X(\result_comb[2] ));
 sky130_fd_sc_hd__xnor2_2 _411_ (.A(_273_),
    .B(_004_),
    .Y(_047_));
 sky130_fd_sc_hd__and2b_2 _412_ (.A_N(_047_),
    .B(\A_reg[3] ),
    .X(_048_));
 sky130_fd_sc_hd__and2b_2 _413_ (.A_N(\A_reg[3] ),
    .B(_047_),
    .X(_049_));
 sky130_fd_sc_hd__nor2_2 _414_ (.A(_048_),
    .B(_049_),
    .Y(_050_));
 sky130_fd_sc_hd__a21o_2 _415_ (.A1(_030_),
    .A2(_031_),
    .B1(_028_),
    .X(_051_));
 sky130_fd_sc_hd__xor2_2 _416_ (.A(_050_),
    .B(_051_),
    .X(_052_));
 sky130_fd_sc_hd__mux2_1 _417_ (.A0(_019_),
    .A1(_022_),
    .S(\B_reg[1] ),
    .X(_053_));
 sky130_fd_sc_hd__nor2_2 _418_ (.A(_274_),
    .B(_292_),
    .Y(_054_));
 sky130_fd_sc_hd__a22oi_2 _419_ (.A1(_274_),
    .A2(_053_),
    .B1(_054_),
    .B2(\A_reg[15] ),
    .Y(_055_));
 sky130_fd_sc_hd__nand2_2 _420_ (.A(_300_),
    .B(_048_),
    .Y(_056_));
 sky130_fd_sc_hd__o21ai_2 _421_ (.A1(\B_reg[3] ),
    .A2(\A_reg[3] ),
    .B1(_299_),
    .Y(_057_));
 sky130_fd_sc_hd__mux4_2 _422_ (.A0(\A_reg[3] ),
    .A1(\A_reg[4] ),
    .A2(\A_reg[5] ),
    .A3(\A_reg[6] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .X(_058_));
 sky130_fd_sc_hd__mux4_2 _423_ (.A0(\A_reg[3] ),
    .A1(\A_reg[2] ),
    .A2(\A_reg[1] ),
    .A3(\A_reg[0] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .X(_059_));
 sky130_fd_sc_hd__mux4_2 _424_ (.A0(\A_reg[7] ),
    .A1(\A_reg[8] ),
    .A2(\A_reg[9] ),
    .A3(\A_reg[10] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .X(_060_));
 sky130_fd_sc_hd__a22o_2 _425_ (.A1(_312_),
    .A2(_058_),
    .B1(_060_),
    .B2(_314_),
    .X(_061_));
 sky130_fd_sc_hd__a221o_2 _426_ (.A1(_297_),
    .A2(_050_),
    .B1(_059_),
    .B2(_015_),
    .C1(_061_),
    .X(_062_));
 sky130_fd_sc_hd__o2111a_2 _427_ (.A1(\A_reg[3] ),
    .A2(_301_),
    .B1(_056_),
    .C1(_057_),
    .D1(_282_),
    .X(_063_));
 sky130_fd_sc_hd__o21ai_2 _428_ (.A1(_290_),
    .A2(_055_),
    .B1(_063_),
    .Y(_064_));
 sky130_fd_sc_hd__o22a_2 _429_ (.A1(_282_),
    .A2(_052_),
    .B1(_062_),
    .B2(_064_),
    .X(\result_comb[3] ));
 sky130_fd_sc_hd__xor2_2 _430_ (.A(\B_reg[4] ),
    .B(_004_),
    .X(_065_));
 sky130_fd_sc_hd__and2b_2 _431_ (.A_N(_065_),
    .B(\A_reg[4] ),
    .X(_066_));
 sky130_fd_sc_hd__and2b_2 _432_ (.A_N(\A_reg[4] ),
    .B(_065_),
    .X(_067_));
 sky130_fd_sc_hd__nor2_2 _433_ (.A(_066_),
    .B(_067_),
    .Y(_068_));
 sky130_fd_sc_hd__a21o_2 _434_ (.A1(_050_),
    .A2(_051_),
    .B1(_048_),
    .X(_069_));
 sky130_fd_sc_hd__xor2_2 _435_ (.A(_068_),
    .B(_069_),
    .X(_070_));
 sky130_fd_sc_hd__mux2_1 _436_ (.A0(\A_reg[4] ),
    .A1(\A_reg[3] ),
    .S(\B_reg[0] ),
    .X(_071_));
 sky130_fd_sc_hd__mux2_1 _437_ (.A0(_039_),
    .A1(_071_),
    .S(_275_),
    .X(_072_));
 sky130_fd_sc_hd__a22o_2 _438_ (.A1(\A_reg[0] ),
    .A2(_054_),
    .B1(_072_),
    .B2(_274_),
    .X(_073_));
 sky130_fd_sc_hd__o21ai_2 _439_ (.A1(\A_reg[4] ),
    .A2(\B_reg[4] ),
    .B1(_299_),
    .Y(_074_));
 sky130_fd_sc_hd__o211ai_2 _440_ (.A1(\A_reg[4] ),
    .A2(_301_),
    .B1(_074_),
    .C1(_282_),
    .Y(_075_));
 sky130_fd_sc_hd__nor2_2 _441_ (.A(\B_reg[2] ),
    .B(_290_),
    .Y(_076_));
 sky130_fd_sc_hd__a22o_2 _442_ (.A1(_312_),
    .A2(_313_),
    .B1(_314_),
    .B2(_284_),
    .X(_077_));
 sky130_fd_sc_hd__a221o_2 _443_ (.A1(_297_),
    .A2(_068_),
    .B1(_076_),
    .B2(_286_),
    .C1(_077_),
    .X(_078_));
 sky130_fd_sc_hd__a221o_2 _444_ (.A1(_300_),
    .A2(_066_),
    .B1(_073_),
    .B2(_002_),
    .C1(_075_),
    .X(_079_));
 sky130_fd_sc_hd__o22a_2 _445_ (.A1(_282_),
    .A2(_070_),
    .B1(_078_),
    .B2(_079_),
    .X(\result_comb[4] ));
 sky130_fd_sc_hd__xor2_2 _446_ (.A(\B_reg[5] ),
    .B(_004_),
    .X(_080_));
 sky130_fd_sc_hd__and2b_2 _447_ (.A_N(_080_),
    .B(\A_reg[5] ),
    .X(_081_));
 sky130_fd_sc_hd__and2b_2 _448_ (.A_N(\A_reg[5] ),
    .B(_080_),
    .X(_082_));
 sky130_fd_sc_hd__nor2_2 _449_ (.A(_081_),
    .B(_082_),
    .Y(_083_));
 sky130_fd_sc_hd__a21o_2 _450_ (.A1(_068_),
    .A2(_069_),
    .B1(_066_),
    .X(_084_));
 sky130_fd_sc_hd__xor2_2 _451_ (.A(_083_),
    .B(_084_),
    .X(_085_));
 sky130_fd_sc_hd__mux4_2 _452_ (.A0(\A_reg[5] ),
    .A1(\A_reg[4] ),
    .A2(\A_reg[3] ),
    .A3(\A_reg[2] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .X(_086_));
 sky130_fd_sc_hd__mux2_1 _453_ (.A0(_014_),
    .A1(_086_),
    .S(_274_),
    .X(_087_));
 sky130_fd_sc_hd__a22o_2 _454_ (.A1(_297_),
    .A2(_083_),
    .B1(_087_),
    .B2(_002_),
    .X(_088_));
 sky130_fd_sc_hd__o21ai_2 _455_ (.A1(\A_reg[5] ),
    .A2(\B_reg[5] ),
    .B1(_299_),
    .Y(_089_));
 sky130_fd_sc_hd__o21ai_2 _456_ (.A1(\A_reg[5] ),
    .A2(_301_),
    .B1(_089_),
    .Y(_090_));
 sky130_fd_sc_hd__a211o_2 _457_ (.A1(_024_),
    .A2(_076_),
    .B1(_090_),
    .C1(_281_),
    .X(_091_));
 sky130_fd_sc_hd__a221o_2 _458_ (.A1(_312_),
    .A2(_011_),
    .B1(_020_),
    .B2(_314_),
    .C1(_088_),
    .X(_092_));
 sky130_fd_sc_hd__a211o_2 _459_ (.A1(_300_),
    .A2(_081_),
    .B1(_091_),
    .C1(_092_),
    .X(_093_));
 sky130_fd_sc_hd__o21a_2 _460_ (.A1(_282_),
    .A2(_085_),
    .B1(_093_),
    .X(\result_comb[5] ));
 sky130_fd_sc_hd__xor2_2 _461_ (.A(\B_reg[6] ),
    .B(_004_),
    .X(_094_));
 sky130_fd_sc_hd__and2b_2 _462_ (.A_N(_094_),
    .B(\A_reg[6] ),
    .X(_095_));
 sky130_fd_sc_hd__and2b_2 _463_ (.A_N(\A_reg[6] ),
    .B(_094_),
    .X(_096_));
 sky130_fd_sc_hd__nor2_2 _464_ (.A(_095_),
    .B(_096_),
    .Y(_097_));
 sky130_fd_sc_hd__a21o_2 _465_ (.A1(_083_),
    .A2(_084_),
    .B1(_081_),
    .X(_098_));
 sky130_fd_sc_hd__xor2_2 _466_ (.A(_097_),
    .B(_098_),
    .X(_099_));
 sky130_fd_sc_hd__a22o_2 _467_ (.A1(_314_),
    .A2(_033_),
    .B1(_038_),
    .B2(_312_),
    .X(_100_));
 sky130_fd_sc_hd__o21ai_2 _468_ (.A1(\A_reg[6] ),
    .A2(\B_reg[6] ),
    .B1(_299_),
    .Y(_101_));
 sky130_fd_sc_hd__o21ai_2 _469_ (.A1(\A_reg[6] ),
    .A2(_301_),
    .B1(_101_),
    .Y(_102_));
 sky130_fd_sc_hd__a211o_2 _470_ (.A1(_034_),
    .A2(_076_),
    .B1(_102_),
    .C1(_281_),
    .X(_103_));
 sky130_fd_sc_hd__mux2_1 _471_ (.A0(\A_reg[6] ),
    .A1(\A_reg[5] ),
    .S(\B_reg[0] ),
    .X(_104_));
 sky130_fd_sc_hd__mux2_1 _472_ (.A0(_071_),
    .A1(_104_),
    .S(_275_),
    .X(_105_));
 sky130_fd_sc_hd__inv_2 _473_ (.A(_105_),
    .Y(_106_));
 sky130_fd_sc_hd__mux2_1 _474_ (.A0(_041_),
    .A1(_106_),
    .S(_274_),
    .X(_107_));
 sky130_fd_sc_hd__a221o_2 _475_ (.A1(_300_),
    .A2(_095_),
    .B1(_097_),
    .B2(_297_),
    .C1(_103_),
    .X(_108_));
 sky130_fd_sc_hd__o21bai_2 _476_ (.A1(_003_),
    .A2(_107_),
    .B1_N(_108_),
    .Y(_109_));
 sky130_fd_sc_hd__o22a_2 _477_ (.A1(_282_),
    .A2(_099_),
    .B1(_100_),
    .B2(_109_),
    .X(\result_comb[6] ));
 sky130_fd_sc_hd__xor2_2 _478_ (.A(\B_reg[7] ),
    .B(_004_),
    .X(_110_));
 sky130_fd_sc_hd__and2b_2 _479_ (.A_N(_110_),
    .B(\A_reg[7] ),
    .X(_111_));
 sky130_fd_sc_hd__and2b_2 _480_ (.A_N(\A_reg[7] ),
    .B(_110_),
    .X(_112_));
 sky130_fd_sc_hd__nor2_2 _481_ (.A(_111_),
    .B(_112_),
    .Y(_113_));
 sky130_fd_sc_hd__a21o_2 _482_ (.A1(_097_),
    .A2(_098_),
    .B1(_095_),
    .X(_114_));
 sky130_fd_sc_hd__xnor2_2 _483_ (.A(_113_),
    .B(_114_),
    .Y(_115_));
 sky130_fd_sc_hd__mux4_2 _484_ (.A0(\A_reg[7] ),
    .A1(\A_reg[6] ),
    .A2(\A_reg[5] ),
    .A3(\A_reg[4] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .X(_116_));
 sky130_fd_sc_hd__mux2_1 _485_ (.A0(_059_),
    .A1(_116_),
    .S(_274_),
    .X(_117_));
 sky130_fd_sc_hd__a22o_2 _486_ (.A1(_297_),
    .A2(_113_),
    .B1(_117_),
    .B2(_002_),
    .X(_118_));
 sky130_fd_sc_hd__o21ai_2 _487_ (.A1(\A_reg[7] ),
    .A2(\B_reg[7] ),
    .B1(_299_),
    .Y(_119_));
 sky130_fd_sc_hd__o211a_2 _488_ (.A1(\A_reg[7] ),
    .A2(_301_),
    .B1(_119_),
    .C1(_282_),
    .X(_120_));
 sky130_fd_sc_hd__o31ai_2 _489_ (.A1(_278_),
    .A2(_290_),
    .A3(_294_),
    .B1(_120_),
    .Y(_121_));
 sky130_fd_sc_hd__a221o_2 _490_ (.A1(_314_),
    .A2(_053_),
    .B1(_060_),
    .B2(_312_),
    .C1(_121_),
    .X(_122_));
 sky130_fd_sc_hd__a211o_2 _491_ (.A1(_300_),
    .A2(_111_),
    .B1(_118_),
    .C1(_122_),
    .X(_123_));
 sky130_fd_sc_hd__a21bo_2 _492_ (.A1(_281_),
    .A2(_115_),
    .B1_N(_123_),
    .X(_124_));
 sky130_fd_sc_hd__inv_2 _493_ (.A(_124_),
    .Y(\result_comb[7] ));
 sky130_fd_sc_hd__xor2_2 _494_ (.A(\B_reg[8] ),
    .B(_004_),
    .X(_125_));
 sky130_fd_sc_hd__and2b_2 _495_ (.A_N(_125_),
    .B(\A_reg[8] ),
    .X(_126_));
 sky130_fd_sc_hd__and2b_2 _496_ (.A_N(\A_reg[8] ),
    .B(_125_),
    .X(_127_));
 sky130_fd_sc_hd__nor2_2 _497_ (.A(_126_),
    .B(_127_),
    .Y(_128_));
 sky130_fd_sc_hd__a21o_2 _498_ (.A1(_113_),
    .A2(_114_),
    .B1(_111_),
    .X(_129_));
 sky130_fd_sc_hd__xor2_2 _499_ (.A(_128_),
    .B(_129_),
    .X(_130_));
 sky130_fd_sc_hd__mux2_1 _500_ (.A0(\A_reg[8] ),
    .A1(\A_reg[7] ),
    .S(\B_reg[0] ),
    .X(_131_));
 sky130_fd_sc_hd__mux2_1 _501_ (.A0(_104_),
    .A1(_131_),
    .S(_275_),
    .X(_132_));
 sky130_fd_sc_hd__nor2_2 _502_ (.A(_274_),
    .B(_003_),
    .Y(_133_));
 sky130_fd_sc_hd__o21ai_2 _503_ (.A1(\A_reg[8] ),
    .A2(\B_reg[8] ),
    .B1(_299_),
    .Y(_134_));
 sky130_fd_sc_hd__o211ai_2 _504_ (.A1(\A_reg[8] ),
    .A2(_301_),
    .B1(_134_),
    .C1(_282_),
    .Y(_135_));
 sky130_fd_sc_hd__nor2_2 _505_ (.A(_273_),
    .B(_317_),
    .Y(_136_));
 sky130_fd_sc_hd__or2_2 _506_ (.A(_273_),
    .B(_317_),
    .X(_137_));
 sky130_fd_sc_hd__a31o_2 _507_ (.A1(\A_reg[0] ),
    .A2(_293_),
    .A3(_136_),
    .B1(_135_),
    .X(_138_));
 sky130_fd_sc_hd__a221o_2 _508_ (.A1(_015_),
    .A2(_132_),
    .B1(_133_),
    .B2(_072_),
    .C1(_138_),
    .X(_139_));
 sky130_fd_sc_hd__a21o_2 _509_ (.A1(_300_),
    .A2(_126_),
    .B1(_139_),
    .X(_140_));
 sky130_fd_sc_hd__a22o_2 _510_ (.A1(_287_),
    .A2(_310_),
    .B1(_128_),
    .B2(_297_),
    .X(_141_));
 sky130_fd_sc_hd__o22a_2 _511_ (.A1(_282_),
    .A2(_130_),
    .B1(_140_),
    .B2(_141_),
    .X(\result_comb[8] ));
 sky130_fd_sc_hd__xor2_2 _512_ (.A(\B_reg[9] ),
    .B(_004_),
    .X(_142_));
 sky130_fd_sc_hd__and2b_2 _513_ (.A_N(_142_),
    .B(\A_reg[9] ),
    .X(_143_));
 sky130_fd_sc_hd__and2b_2 _514_ (.A_N(\A_reg[9] ),
    .B(_142_),
    .X(_144_));
 sky130_fd_sc_hd__nor2_2 _515_ (.A(_143_),
    .B(_144_),
    .Y(_145_));
 sky130_fd_sc_hd__a21o_2 _516_ (.A1(_128_),
    .A2(_129_),
    .B1(_126_),
    .X(_146_));
 sky130_fd_sc_hd__xor2_2 _517_ (.A(_145_),
    .B(_146_),
    .X(_147_));
 sky130_fd_sc_hd__a2bb2o_2 _518_ (.A1_N(_311_),
    .A2_N(_025_),
    .B1(_145_),
    .B2(_297_),
    .X(_148_));
 sky130_fd_sc_hd__o21ai_2 _519_ (.A1(\A_reg[9] ),
    .A2(\B_reg[9] ),
    .B1(_299_),
    .Y(_149_));
 sky130_fd_sc_hd__o21ai_2 _520_ (.A1(\A_reg[9] ),
    .A2(_301_),
    .B1(_149_),
    .Y(_150_));
 sky130_fd_sc_hd__mux4_2 _521_ (.A0(\A_reg[9] ),
    .A1(\A_reg[8] ),
    .A2(\A_reg[7] ),
    .A3(\A_reg[6] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .X(_151_));
 sky130_fd_sc_hd__a211o_2 _522_ (.A1(_015_),
    .A2(_151_),
    .B1(_150_),
    .C1(_281_),
    .X(_152_));
 sky130_fd_sc_hd__a32o_2 _523_ (.A1(_274_),
    .A2(_014_),
    .A3(_136_),
    .B1(_133_),
    .B2(_086_),
    .X(_153_));
 sky130_fd_sc_hd__a211o_2 _524_ (.A1(_300_),
    .A2(_143_),
    .B1(_152_),
    .C1(_153_),
    .X(_154_));
 sky130_fd_sc_hd__o22a_2 _525_ (.A1(_282_),
    .A2(_147_),
    .B1(_148_),
    .B2(_154_),
    .X(\result_comb[9] ));
 sky130_fd_sc_hd__xor2_2 _526_ (.A(\B_reg[10] ),
    .B(_004_),
    .X(_155_));
 sky130_fd_sc_hd__and2b_2 _527_ (.A_N(_155_),
    .B(\A_reg[10] ),
    .X(_156_));
 sky130_fd_sc_hd__and2b_2 _528_ (.A_N(\A_reg[10] ),
    .B(_155_),
    .X(_157_));
 sky130_fd_sc_hd__nor2_2 _529_ (.A(_156_),
    .B(_157_),
    .Y(_158_));
 sky130_fd_sc_hd__a21o_2 _530_ (.A1(_145_),
    .A2(_146_),
    .B1(_143_),
    .X(_159_));
 sky130_fd_sc_hd__xor2_2 _531_ (.A(_158_),
    .B(_159_),
    .X(_160_));
 sky130_fd_sc_hd__or3_2 _532_ (.A(\B_reg[2] ),
    .B(_317_),
    .C(_041_),
    .X(_161_));
 sky130_fd_sc_hd__mux2_1 _533_ (.A0(\A_reg[10] ),
    .A1(\A_reg[9] ),
    .S(\B_reg[0] ),
    .X(_162_));
 sky130_fd_sc_hd__mux2_1 _534_ (.A0(_131_),
    .A1(_162_),
    .S(_275_),
    .X(_163_));
 sky130_fd_sc_hd__mux2_1 _535_ (.A0(_105_),
    .A1(_163_),
    .S(_274_),
    .X(_164_));
 sky130_fd_sc_hd__o2bb2a_2 _536_ (.A1_N(_003_),
    .A2_N(_161_),
    .B1(_164_),
    .B2(\B_reg[3] ),
    .X(_165_));
 sky130_fd_sc_hd__o21ai_2 _537_ (.A1(\A_reg[10] ),
    .A2(\B_reg[10] ),
    .B1(_299_),
    .Y(_166_));
 sky130_fd_sc_hd__o21ai_2 _538_ (.A1(\A_reg[10] ),
    .A2(_301_),
    .B1(_166_),
    .Y(_167_));
 sky130_fd_sc_hd__a211o_2 _539_ (.A1(_300_),
    .A2(_156_),
    .B1(_167_),
    .C1(_281_),
    .X(_168_));
 sky130_fd_sc_hd__a221o_2 _540_ (.A1(_310_),
    .A2(_035_),
    .B1(_158_),
    .B2(_297_),
    .C1(_168_),
    .X(_169_));
 sky130_fd_sc_hd__o22a_2 _541_ (.A1(_282_),
    .A2(_160_),
    .B1(_165_),
    .B2(_169_),
    .X(\result_comb[10] ));
 sky130_fd_sc_hd__xor2_2 _542_ (.A(\B_reg[11] ),
    .B(_004_),
    .X(_170_));
 sky130_fd_sc_hd__and2b_2 _543_ (.A_N(_170_),
    .B(\A_reg[11] ),
    .X(_171_));
 sky130_fd_sc_hd__and2b_2 _544_ (.A_N(\A_reg[11] ),
    .B(_170_),
    .X(_172_));
 sky130_fd_sc_hd__nor2_2 _545_ (.A(_171_),
    .B(_172_),
    .Y(_173_));
 sky130_fd_sc_hd__a21o_2 _546_ (.A1(_158_),
    .A2(_159_),
    .B1(_156_),
    .X(_174_));
 sky130_fd_sc_hd__xor2_2 _547_ (.A(_173_),
    .B(_174_),
    .X(_175_));
 sky130_fd_sc_hd__a2bb2o_2 _548_ (.A1_N(_311_),
    .A2_N(_055_),
    .B1(_173_),
    .B2(_297_),
    .X(_176_));
 sky130_fd_sc_hd__o21ai_2 _549_ (.A1(\A_reg[11] ),
    .A2(\B_reg[11] ),
    .B1(_299_),
    .Y(_177_));
 sky130_fd_sc_hd__o211ai_2 _550_ (.A1(\A_reg[11] ),
    .A2(_301_),
    .B1(_177_),
    .C1(_282_),
    .Y(_178_));
 sky130_fd_sc_hd__a31o_2 _551_ (.A1(_274_),
    .A2(_059_),
    .A3(_136_),
    .B1(_178_),
    .X(_179_));
 sky130_fd_sc_hd__mux4_2 _552_ (.A0(\A_reg[11] ),
    .A1(\A_reg[10] ),
    .A2(\A_reg[9] ),
    .A3(\A_reg[8] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .X(_180_));
 sky130_fd_sc_hd__a221o_2 _553_ (.A1(_116_),
    .A2(_133_),
    .B1(_180_),
    .B2(_015_),
    .C1(_179_),
    .X(_181_));
 sky130_fd_sc_hd__a211o_2 _554_ (.A1(_300_),
    .A2(_171_),
    .B1(_176_),
    .C1(_181_),
    .X(_182_));
 sky130_fd_sc_hd__o21a_2 _555_ (.A1(_282_),
    .A2(_175_),
    .B1(_182_),
    .X(\result_comb[11] ));
 sky130_fd_sc_hd__xor2_2 _556_ (.A(\B_reg[12] ),
    .B(_004_),
    .X(_183_));
 sky130_fd_sc_hd__and2b_2 _557_ (.A_N(_183_),
    .B(\A_reg[12] ),
    .X(_184_));
 sky130_fd_sc_hd__and2b_2 _558_ (.A_N(\A_reg[12] ),
    .B(_183_),
    .X(_185_));
 sky130_fd_sc_hd__nor2_2 _559_ (.A(_184_),
    .B(_185_),
    .Y(_186_));
 sky130_fd_sc_hd__a21o_2 _560_ (.A1(_173_),
    .A2(_174_),
    .B1(_171_),
    .X(_187_));
 sky130_fd_sc_hd__xor2_2 _561_ (.A(_186_),
    .B(_187_),
    .X(_188_));
 sky130_fd_sc_hd__o21ai_2 _562_ (.A1(\A_reg[12] ),
    .A2(\B_reg[12] ),
    .B1(_299_),
    .Y(_189_));
 sky130_fd_sc_hd__o21ai_2 _563_ (.A1(\A_reg[12] ),
    .A2(_301_),
    .B1(_189_),
    .Y(_190_));
 sky130_fd_sc_hd__a211o_2 _564_ (.A1(_286_),
    .A2(_312_),
    .B1(_190_),
    .C1(_281_),
    .X(_191_));
 sky130_fd_sc_hd__a221o_2 _565_ (.A1(_073_),
    .A2(_136_),
    .B1(_184_),
    .B2(_300_),
    .C1(_191_),
    .X(_192_));
 sky130_fd_sc_hd__mux2_1 _566_ (.A0(\A_reg[12] ),
    .A1(\A_reg[11] ),
    .S(\B_reg[0] ),
    .X(_193_));
 sky130_fd_sc_hd__mux4_2 _567_ (.A0(_104_),
    .A1(_131_),
    .A2(_162_),
    .A3(_193_),
    .S0(_275_),
    .S1(_274_),
    .X(_194_));
 sky130_fd_sc_hd__a22o_2 _568_ (.A1(_297_),
    .A2(_186_),
    .B1(_194_),
    .B2(_002_),
    .X(_195_));
 sky130_fd_sc_hd__o22a_2 _569_ (.A1(_282_),
    .A2(_188_),
    .B1(_192_),
    .B2(_195_),
    .X(\result_comb[12] ));
 sky130_fd_sc_hd__xor2_2 _570_ (.A(\B_reg[13] ),
    .B(_004_),
    .X(_196_));
 sky130_fd_sc_hd__and2b_2 _571_ (.A_N(_196_),
    .B(\A_reg[13] ),
    .X(_197_));
 sky130_fd_sc_hd__and2b_2 _572_ (.A_N(\A_reg[13] ),
    .B(_196_),
    .X(_198_));
 sky130_fd_sc_hd__nor2_2 _573_ (.A(_197_),
    .B(_198_),
    .Y(_199_));
 sky130_fd_sc_hd__a21o_2 _574_ (.A1(_186_),
    .A2(_187_),
    .B1(_184_),
    .X(_200_));
 sky130_fd_sc_hd__xor2_2 _575_ (.A(_199_),
    .B(_200_),
    .X(_201_));
 sky130_fd_sc_hd__o21ai_2 _576_ (.A1(\A_reg[13] ),
    .A2(\B_reg[13] ),
    .B1(_299_),
    .Y(_202_));
 sky130_fd_sc_hd__o21ai_2 _577_ (.A1(\A_reg[13] ),
    .A2(_301_),
    .B1(_202_),
    .Y(_203_));
 sky130_fd_sc_hd__a211o_2 _578_ (.A1(_312_),
    .A2(_024_),
    .B1(_203_),
    .C1(_281_),
    .X(_204_));
 sky130_fd_sc_hd__a221o_2 _579_ (.A1(_087_),
    .A2(_136_),
    .B1(_197_),
    .B2(_300_),
    .C1(_204_),
    .X(_205_));
 sky130_fd_sc_hd__mux4_2 _580_ (.A0(\A_reg[13] ),
    .A1(\A_reg[12] ),
    .A2(\A_reg[11] ),
    .A3(\A_reg[10] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .X(_206_));
 sky130_fd_sc_hd__mux2_1 _581_ (.A0(_151_),
    .A1(_206_),
    .S(_274_),
    .X(_207_));
 sky130_fd_sc_hd__a22o_2 _582_ (.A1(_297_),
    .A2(_199_),
    .B1(_207_),
    .B2(_002_),
    .X(_208_));
 sky130_fd_sc_hd__o22a_2 _583_ (.A1(_282_),
    .A2(_201_),
    .B1(_205_),
    .B2(_208_),
    .X(\result_comb[13] ));
 sky130_fd_sc_hd__xor2_2 _584_ (.A(\B_reg[14] ),
    .B(_004_),
    .X(_209_));
 sky130_fd_sc_hd__nor2_2 _585_ (.A(_277_),
    .B(_209_),
    .Y(_210_));
 sky130_fd_sc_hd__and2_2 _586_ (.A(_277_),
    .B(_209_),
    .X(_211_));
 sky130_fd_sc_hd__nor2_2 _587_ (.A(_210_),
    .B(_211_),
    .Y(_212_));
 sky130_fd_sc_hd__a21o_2 _588_ (.A1(_199_),
    .A2(_200_),
    .B1(_197_),
    .X(_213_));
 sky130_fd_sc_hd__xor2_2 _589_ (.A(_212_),
    .B(_213_),
    .X(_214_));
 sky130_fd_sc_hd__a2bb2o_2 _590_ (.A1_N(_107_),
    .A2_N(_137_),
    .B1(_212_),
    .B2(_297_),
    .X(_215_));
 sky130_fd_sc_hd__or2_2 _591_ (.A(\A_reg[14] ),
    .B(\B_reg[14] ),
    .X(_216_));
 sky130_fd_sc_hd__a22o_2 _592_ (.A1(_277_),
    .A2(_302_),
    .B1(_216_),
    .B2(_299_),
    .X(_217_));
 sky130_fd_sc_hd__a211o_2 _593_ (.A1(_133_),
    .A2(_163_),
    .B1(_217_),
    .C1(_281_),
    .X(_218_));
 sky130_fd_sc_hd__mux4_2 _594_ (.A0(\A_reg[14] ),
    .A1(\A_reg[13] ),
    .A2(\A_reg[12] ),
    .A3(\A_reg[11] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .X(_219_));
 sky130_fd_sc_hd__a22o_2 _595_ (.A1(_312_),
    .A2(_034_),
    .B1(_219_),
    .B2(_015_),
    .X(_220_));
 sky130_fd_sc_hd__or2_2 _596_ (.A(_218_),
    .B(_220_),
    .X(_221_));
 sky130_fd_sc_hd__a211o_2 _597_ (.A1(_300_),
    .A2(_210_),
    .B1(_215_),
    .C1(_221_),
    .X(_222_));
 sky130_fd_sc_hd__o21a_2 _598_ (.A1(_282_),
    .A2(_214_),
    .B1(_222_),
    .X(\result_comb[14] ));
 sky130_fd_sc_hd__a21o_2 _599_ (.A1(_212_),
    .A2(_213_),
    .B1(_210_),
    .X(_223_));
 sky130_fd_sc_hd__xor2_2 _600_ (.A(\B_reg[15] ),
    .B(_004_),
    .X(_224_));
 sky130_fd_sc_hd__nor2_2 _601_ (.A(_278_),
    .B(_224_),
    .Y(_225_));
 sky130_fd_sc_hd__and2_2 _602_ (.A(_278_),
    .B(_224_),
    .X(_226_));
 sky130_fd_sc_hd__inv_2 _603_ (.A(_226_),
    .Y(_227_));
 sky130_fd_sc_hd__nor2_2 _604_ (.A(_225_),
    .B(_226_),
    .Y(_228_));
 sky130_fd_sc_hd__xnor2_2 _605_ (.A(_223_),
    .B(_228_),
    .Y(_229_));
 sky130_fd_sc_hd__o22a_2 _606_ (.A1(\B_reg[15] ),
    .A2(_302_),
    .B1(_316_),
    .B2(_296_),
    .X(_230_));
 sky130_fd_sc_hd__nand2_2 _607_ (.A(_293_),
    .B(_310_),
    .Y(_231_));
 sky130_fd_sc_hd__nand2_2 _608_ (.A(\A_reg[15] ),
    .B(_231_),
    .Y(_232_));
 sky130_fd_sc_hd__mux2_1 _609_ (.A0(_297_),
    .A1(_300_),
    .S(\B_reg[15] ),
    .X(_233_));
 sky130_fd_sc_hd__o32a_2 _610_ (.A1(_316_),
    .A2(_232_),
    .A3(_233_),
    .B1(_230_),
    .B2(\A_reg[15] ),
    .X(_234_));
 sky130_fd_sc_hd__mux4_2 _611_ (.A0(\A_reg[15] ),
    .A1(\A_reg[14] ),
    .A2(\A_reg[13] ),
    .A3(\A_reg[12] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .X(_235_));
 sky130_fd_sc_hd__a221oi_2 _612_ (.A1(_133_),
    .A2(_180_),
    .B1(_235_),
    .B2(_015_),
    .C1(_234_),
    .Y(_236_));
 sky130_fd_sc_hd__o2bb2a_2 _613_ (.A1_N(_117_),
    .A2_N(_136_),
    .B1(_229_),
    .B2(_282_),
    .X(_237_));
 sky130_fd_sc_hd__nand2_2 _614_ (.A(_236_),
    .B(_237_),
    .Y(\result_comb[15] ));
 sky130_fd_sc_hd__or4_2 _615_ (.A(\result_comb[0] ),
    .B(\result_comb[1] ),
    .C(\result_comb[2] ),
    .D(\result_comb[3] ),
    .X(_238_));
 sky130_fd_sc_hd__or4_2 _616_ (.A(\result_comb[4] ),
    .B(\result_comb[5] ),
    .C(\result_comb[6] ),
    .D(_238_),
    .X(_239_));
 sky130_fd_sc_hd__or4_2 _617_ (.A(\result_comb[7] ),
    .B(\result_comb[8] ),
    .C(\result_comb[9] ),
    .D(_239_),
    .X(_240_));
 sky130_fd_sc_hd__or4_2 _618_ (.A(\result_comb[10] ),
    .B(\result_comb[11] ),
    .C(\result_comb[12] ),
    .D(_240_),
    .X(_241_));
 sky130_fd_sc_hd__nor3_2 _619_ (.A(\result_comb[13] ),
    .B(\result_comb[14] ),
    .C(_241_),
    .Y(_242_));
 sky130_fd_sc_hd__and3_2 _620_ (.A(_236_),
    .B(_237_),
    .C(_242_),
    .X(_000_));
 sky130_fd_sc_hd__o21a_2 _621_ (.A1(_223_),
    .A2(_225_),
    .B1(_281_),
    .X(_243_));
 sky130_fd_sc_hd__xnor2_2 _622_ (.A(\B_reg[0] ),
    .B(_289_),
    .Y(_244_));
 sky130_fd_sc_hd__or2_2 _623_ (.A(\B_reg[1] ),
    .B(_244_),
    .X(_245_));
 sky130_fd_sc_hd__inv_2 _624_ (.A(_245_),
    .Y(_246_));
 sky130_fd_sc_hd__nand2_2 _625_ (.A(\B_reg[1] ),
    .B(_244_),
    .Y(_247_));
 sky130_fd_sc_hd__inv_2 _626_ (.A(_247_),
    .Y(_248_));
 sky130_fd_sc_hd__o22a_2 _627_ (.A1(\B_reg[1] ),
    .A2(\A_reg[8] ),
    .B1(\A_reg[9] ),
    .B2(_244_),
    .X(_249_));
 sky130_fd_sc_hd__mux2_1 _628_ (.A0(\A_reg[11] ),
    .A1(_249_),
    .S(_245_),
    .X(_250_));
 sky130_fd_sc_hd__or2_2 _629_ (.A(\A_reg[10] ),
    .B(_247_),
    .X(_251_));
 sky130_fd_sc_hd__and2_2 _630_ (.A(\B_reg[2] ),
    .B(_292_),
    .X(_252_));
 sky130_fd_sc_hd__nor2_2 _631_ (.A(_293_),
    .B(_252_),
    .Y(_253_));
 sky130_fd_sc_hd__xnor2_2 _632_ (.A(_289_),
    .B(_253_),
    .Y(_254_));
 sky130_fd_sc_hd__nor2_2 _633_ (.A(_273_),
    .B(_289_),
    .Y(_255_));
 sky130_fd_sc_hd__nor2_2 _634_ (.A(_310_),
    .B(_255_),
    .Y(_256_));
 sky130_fd_sc_hd__xnor2_2 _635_ (.A(_293_),
    .B(_256_),
    .Y(_257_));
 sky130_fd_sc_hd__o22a_2 _636_ (.A1(\B_reg[1] ),
    .A2(\A_reg[12] ),
    .B1(\A_reg[13] ),
    .B2(_244_),
    .X(_258_));
 sky130_fd_sc_hd__a221oi_2 _637_ (.A1(_232_),
    .A2(_246_),
    .B1(_248_),
    .B2(_277_),
    .C1(_254_),
    .Y(_259_));
 sky130_fd_sc_hd__o21a_2 _638_ (.A1(_246_),
    .A2(_258_),
    .B1(_259_),
    .X(_260_));
 sky130_fd_sc_hd__a31o_2 _639_ (.A1(_250_),
    .A2(_251_),
    .A3(_254_),
    .B1(_260_),
    .X(_261_));
 sky130_fd_sc_hd__nor2_2 _640_ (.A(_288_),
    .B(_295_),
    .Y(_262_));
 sky130_fd_sc_hd__or2_2 _641_ (.A(\A_reg[0] ),
    .B(\B_reg[1] ),
    .X(_263_));
 sky130_fd_sc_hd__a21o_2 _642_ (.A1(\B_reg[1] ),
    .A2(\A_reg[1] ),
    .B1(_244_),
    .X(_264_));
 sky130_fd_sc_hd__a22o_2 _643_ (.A1(\A_reg[3] ),
    .A2(_246_),
    .B1(_263_),
    .B2(_264_),
    .X(_265_));
 sky130_fd_sc_hd__o211ai_2 _644_ (.A1(\A_reg[2] ),
    .A2(_247_),
    .B1(_254_),
    .C1(_265_),
    .Y(_266_));
 sky130_fd_sc_hd__o21ba_2 _645_ (.A1(_275_),
    .A2(\A_reg[5] ),
    .B1_N(_244_),
    .X(_267_));
 sky130_fd_sc_hd__a221o_2 _646_ (.A1(_275_),
    .A2(\A_reg[4] ),
    .B1(\A_reg[6] ),
    .B2(_248_),
    .C1(_267_),
    .X(_268_));
 sky130_fd_sc_hd__a21o_2 _647_ (.A1(\A_reg[7] ),
    .A2(_231_),
    .B1(_245_),
    .X(_269_));
 sky130_fd_sc_hd__nand2_2 _648_ (.A(_268_),
    .B(_269_),
    .Y(_270_));
 sky130_fd_sc_hd__o211a_2 _649_ (.A1(_254_),
    .A2(_270_),
    .B1(_266_),
    .C1(_257_),
    .X(_271_));
 sky130_fd_sc_hd__o21ba_2 _650_ (.A1(_257_),
    .A2(_261_),
    .B1_N(_271_),
    .X(_272_));
 sky130_fd_sc_hd__a22o_2 _651_ (.A1(_227_),
    .A2(_243_),
    .B1(_262_),
    .B2(_272_),
    .X(carry_comb));
 sky130_fd_sc_hd__a21boi_2 _652_ (.A1(_223_),
    .A2(_227_),
    .B1_N(_243_),
    .Y(_001_));
 sky130_fd_sc_hd__dfxtp_2 _653_ (.CLK(clk),
    .D(_001_),
    .Q(V));
 sky130_fd_sc_hd__dfxtp_2 _654_ (.CLK(clk),
    .D(carry_comb),
    .Q(C));
 sky130_fd_sc_hd__dfxtp_2 _655_ (.CLK(clk),
    .D(\result_comb[15] ),
    .Q(N));
 sky130_fd_sc_hd__dfxtp_2 _656_ (.CLK(clk),
    .D(\result_comb[0] ),
    .Q(Y[0]));
 sky130_fd_sc_hd__dfxtp_2 _657_ (.CLK(clk),
    .D(\result_comb[1] ),
    .Q(Y[1]));
 sky130_fd_sc_hd__dfxtp_2 _658_ (.CLK(clk),
    .D(\result_comb[2] ),
    .Q(Y[2]));
 sky130_fd_sc_hd__dfxtp_2 _659_ (.CLK(clk),
    .D(\result_comb[3] ),
    .Q(Y[3]));
 sky130_fd_sc_hd__dfxtp_2 _660_ (.CLK(clk),
    .D(\result_comb[4] ),
    .Q(Y[4]));
 sky130_fd_sc_hd__dfxtp_2 _661_ (.CLK(clk),
    .D(\result_comb[5] ),
    .Q(Y[5]));
 sky130_fd_sc_hd__dfxtp_2 _662_ (.CLK(clk),
    .D(\result_comb[6] ),
    .Q(Y[6]));
 sky130_fd_sc_hd__dfxtp_2 _663_ (.CLK(clk),
    .D(\result_comb[7] ),
    .Q(Y[7]));
 sky130_fd_sc_hd__dfxtp_2 _664_ (.CLK(clk),
    .D(\result_comb[8] ),
    .Q(Y[8]));
 sky130_fd_sc_hd__dfxtp_2 _665_ (.CLK(clk),
    .D(\result_comb[9] ),
    .Q(Y[9]));
 sky130_fd_sc_hd__dfxtp_2 _666_ (.CLK(clk),
    .D(\result_comb[10] ),
    .Q(Y[10]));
 sky130_fd_sc_hd__dfxtp_2 _667_ (.CLK(clk),
    .D(\result_comb[11] ),
    .Q(Y[11]));
 sky130_fd_sc_hd__dfxtp_2 _668_ (.CLK(clk),
    .D(\result_comb[12] ),
    .Q(Y[12]));
 sky130_fd_sc_hd__dfxtp_2 _669_ (.CLK(clk),
    .D(\result_comb[13] ),
    .Q(Y[13]));
 sky130_fd_sc_hd__dfxtp_2 _670_ (.CLK(clk),
    .D(\result_comb[14] ),
    .Q(Y[14]));
 sky130_fd_sc_hd__dfxtp_2 _671_ (.CLK(clk),
    .D(_000_),
    .Q(Z));
 sky130_fd_sc_hd__dfxtp_2 _672_ (.CLK(clk),
    .D(A[0]),
    .Q(\A_reg[0] ));
 sky130_fd_sc_hd__dfxtp_2 _673_ (.CLK(clk),
    .D(A[1]),
    .Q(\A_reg[1] ));
 sky130_fd_sc_hd__dfxtp_2 _674_ (.CLK(clk),
    .D(A[2]),
    .Q(\A_reg[2] ));
 sky130_fd_sc_hd__dfxtp_2 _675_ (.CLK(clk),
    .D(A[3]),
    .Q(\A_reg[3] ));
 sky130_fd_sc_hd__dfxtp_2 _676_ (.CLK(clk),
    .D(A[4]),
    .Q(\A_reg[4] ));
 sky130_fd_sc_hd__dfxtp_2 _677_ (.CLK(clk),
    .D(A[5]),
    .Q(\A_reg[5] ));
 sky130_fd_sc_hd__dfxtp_2 _678_ (.CLK(clk),
    .D(A[6]),
    .Q(\A_reg[6] ));
 sky130_fd_sc_hd__dfxtp_2 _679_ (.CLK(clk),
    .D(A[7]),
    .Q(\A_reg[7] ));
 sky130_fd_sc_hd__dfxtp_2 _680_ (.CLK(clk),
    .D(A[8]),
    .Q(\A_reg[8] ));
 sky130_fd_sc_hd__dfxtp_2 _681_ (.CLK(clk),
    .D(A[9]),
    .Q(\A_reg[9] ));
 sky130_fd_sc_hd__dfxtp_2 _682_ (.CLK(clk),
    .D(A[10]),
    .Q(\A_reg[10] ));
 sky130_fd_sc_hd__dfxtp_2 _683_ (.CLK(clk),
    .D(A[11]),
    .Q(\A_reg[11] ));
 sky130_fd_sc_hd__dfxtp_2 _684_ (.CLK(clk),
    .D(A[12]),
    .Q(\A_reg[12] ));
 sky130_fd_sc_hd__dfxtp_2 _685_ (.CLK(clk),
    .D(A[13]),
    .Q(\A_reg[13] ));
 sky130_fd_sc_hd__dfxtp_2 _686_ (.CLK(clk),
    .D(A[14]),
    .Q(\A_reg[14] ));
 sky130_fd_sc_hd__dfxtp_2 _687_ (.CLK(clk),
    .D(A[15]),
    .Q(\A_reg[15] ));
 sky130_fd_sc_hd__dfxtp_2 _688_ (.CLK(clk),
    .D(B[0]),
    .Q(\B_reg[0] ));
 sky130_fd_sc_hd__dfxtp_2 _689_ (.CLK(clk),
    .D(B[1]),
    .Q(\B_reg[1] ));
 sky130_fd_sc_hd__dfxtp_2 _690_ (.CLK(clk),
    .D(B[2]),
    .Q(\B_reg[2] ));
 sky130_fd_sc_hd__dfxtp_2 _691_ (.CLK(clk),
    .D(B[3]),
    .Q(\B_reg[3] ));
 sky130_fd_sc_hd__dfxtp_2 _692_ (.CLK(clk),
    .D(B[4]),
    .Q(\B_reg[4] ));
 sky130_fd_sc_hd__dfxtp_2 _693_ (.CLK(clk),
    .D(B[5]),
    .Q(\B_reg[5] ));
 sky130_fd_sc_hd__dfxtp_2 _694_ (.CLK(clk),
    .D(B[6]),
    .Q(\B_reg[6] ));
 sky130_fd_sc_hd__dfxtp_2 _695_ (.CLK(clk),
    .D(B[7]),
    .Q(\B_reg[7] ));
 sky130_fd_sc_hd__dfxtp_2 _696_ (.CLK(clk),
    .D(B[8]),
    .Q(\B_reg[8] ));
 sky130_fd_sc_hd__dfxtp_2 _697_ (.CLK(clk),
    .D(B[9]),
    .Q(\B_reg[9] ));
 sky130_fd_sc_hd__dfxtp_2 _698_ (.CLK(clk),
    .D(B[10]),
    .Q(\B_reg[10] ));
 sky130_fd_sc_hd__dfxtp_2 _699_ (.CLK(clk),
    .D(B[11]),
    .Q(\B_reg[11] ));
 sky130_fd_sc_hd__dfxtp_2 _700_ (.CLK(clk),
    .D(B[12]),
    .Q(\B_reg[12] ));
 sky130_fd_sc_hd__dfxtp_2 _701_ (.CLK(clk),
    .D(B[13]),
    .Q(\B_reg[13] ));
 sky130_fd_sc_hd__dfxtp_2 _702_ (.CLK(clk),
    .D(B[14]),
    .Q(\B_reg[14] ));
 sky130_fd_sc_hd__dfxtp_2 _703_ (.CLK(clk),
    .D(B[15]),
    .Q(\B_reg[15] ));
 sky130_fd_sc_hd__dfxtp_2 _704_ (.CLK(clk),
    .D(opcode[0]),
    .Q(\opcode_reg[0] ));
 sky130_fd_sc_hd__dfxtp_2 _705_ (.CLK(clk),
    .D(opcode[1]),
    .Q(\opcode_reg[1] ));
 sky130_fd_sc_hd__dfxtp_2 _706_ (.CLK(clk),
    .D(opcode[2]),
    .Q(\opcode_reg[2] ));
 sky130_fd_sc_hd__buf_2 _707_ (.A(N),
    .X(Y[15]));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_0_Right_0 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_1_Right_1 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_2_Right_2 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_3_Right_3 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_4_Right_4 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_5_Right_5 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_6_Right_6 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_7_Right_7 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_8_Right_8 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_9_Right_9 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_10_Right_10 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_11_Right_11 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_12_Right_12 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_13_Right_13 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_14_Right_14 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_15_Right_15 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_16_Right_16 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_17_Right_17 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_18_Right_18 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_19_Right_19 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_20_Right_20 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_21_Right_21 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_22_Right_22 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_23_Right_23 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_24_Right_24 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_25_Right_25 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_Right_26 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_Right_27 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_Right_28 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_Right_29 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_Right_30 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_31_Right_31 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_32_Right_32 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_33_Right_33 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_34_Right_34 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_35_Right_35 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_36_Right_36 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_37_Right_37 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_38_Right_38 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_39_Right_39 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_40_Right_40 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_41_Right_41 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_0_Left_42 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_1_Left_43 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_2_Left_44 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_3_Left_45 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_4_Left_46 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_5_Left_47 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_6_Left_48 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_7_Left_49 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_8_Left_50 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_9_Left_51 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_10_Left_52 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_11_Left_53 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_12_Left_54 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_13_Left_55 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_14_Left_56 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_15_Left_57 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_16_Left_58 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_17_Left_59 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_18_Left_60 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_19_Left_61 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_20_Left_62 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_21_Left_63 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_22_Left_64 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_23_Left_65 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_24_Left_66 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_25_Left_67 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_Left_68 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_Left_69 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_Left_70 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_Left_71 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_Left_72 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_31_Left_73 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_32_Left_74 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_33_Left_75 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_34_Left_76 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_35_Left_77 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_36_Left_78 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_37_Left_79 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_38_Left_80 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_39_Left_81 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_40_Left_82 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_41_Left_83 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_84 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_85 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_86 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_87 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_88 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_89 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_90 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_91 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_92 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_93 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_94 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_95 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_96 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_97 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_98 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_99 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_100 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_101 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_102 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_103 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_104 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_105 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_106 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_107 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_108 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_109 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_110 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_111 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_112 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_113 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_114 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_115 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_116 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_117 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_118 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_119 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_120 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_121 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_122 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_123 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_124 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_125 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_126 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_127 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_128 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_129 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_130 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_131 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_132 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_133 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_134 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_135 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_136 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_137 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_138 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_139 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_140 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_141 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_142 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_143 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_144 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_145 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_146 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_147 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_148 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_149 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_150 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_151 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_152 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_153 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_154 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_155 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_156 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_157 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_158 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_159 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_160 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_161 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_162 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_163 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_164 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_165 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_166 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_167 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_168 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_169 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_170 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_171 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_172 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_173 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_174 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_175 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_176 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_177 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_178 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_179 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_180 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_181 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_182 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_183 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_184 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_185 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_186 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_187 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_188 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_189 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_190 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_191 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_192 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_193 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_194 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_195 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_196 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_197 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_198 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_199 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_200 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_201 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_202 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_203 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_204 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_205 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_206 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_207 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_208 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_209 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_210 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_211 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_212 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_213 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_214 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_215 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_216 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_217 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_218 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_219 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_220 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_221 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_222 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_223 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_224 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_225 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_226 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_227 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_228 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_229 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_230 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_231 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_232 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_233 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_234 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_235 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_236 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_237 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_238 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_239 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_240 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_241 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_242 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_243 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_244 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_245 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_246 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_247 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_248 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_249 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_250 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_251 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_41_252 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_41_253 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_41_254 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_41_255 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_41_256 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_41_257 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_41_258 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_41_259 ();
endmodule
