module alu16 (C,
    N,
    V,
    Z,
    clk,
    A,
    B,
    Y,
    opcode);
 output C;
 output N;
 output V;
 output Z;
 input clk;
 input [15:0] A;
 input [15:0] B;
 output [15:0] Y;
 input [2:0] opcode;

 wire \A_reg[0] ;
 wire \A_reg[10] ;
 wire \A_reg[11] ;
 wire \A_reg[12] ;
 wire \A_reg[13] ;
 wire \A_reg[14] ;
 wire \A_reg[15] ;
 wire \A_reg[1] ;
 wire \A_reg[2] ;
 wire \A_reg[3] ;
 wire \A_reg[4] ;
 wire \A_reg[5] ;
 wire \A_reg[6] ;
 wire \A_reg[7] ;
 wire \A_reg[8] ;
 wire \A_reg[9] ;
 wire \B_reg[0] ;
 wire \B_reg[10] ;
 wire \B_reg[11] ;
 wire \B_reg[12] ;
 wire \B_reg[13] ;
 wire \B_reg[14] ;
 wire \B_reg[15] ;
 wire \B_reg[1] ;
 wire \B_reg[2] ;
 wire \B_reg[3] ;
 wire \B_reg[4] ;
 wire \B_reg[5] ;
 wire \B_reg[6] ;
 wire \B_reg[7] ;
 wire \B_reg[8] ;
 wire \B_reg[9] ;
 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _070_;
 wire _071_;
 wire _072_;
 wire _073_;
 wire _074_;
 wire _075_;
 wire _076_;
 wire _077_;
 wire _078_;
 wire _079_;
 wire _080_;
 wire _081_;
 wire _082_;
 wire _083_;
 wire _084_;
 wire _085_;
 wire _086_;
 wire _087_;
 wire _088_;
 wire _089_;
 wire _090_;
 wire _091_;
 wire _092_;
 wire _093_;
 wire _094_;
 wire _095_;
 wire _096_;
 wire _097_;
 wire _098_;
 wire _099_;
 wire _100_;
 wire _101_;
 wire _102_;
 wire _103_;
 wire _104_;
 wire _105_;
 wire _106_;
 wire _107_;
 wire _108_;
 wire _109_;
 wire _110_;
 wire _111_;
 wire _112_;
 wire _113_;
 wire _114_;
 wire _115_;
 wire _116_;
 wire _117_;
 wire _118_;
 wire _119_;
 wire _120_;
 wire _121_;
 wire _122_;
 wire _123_;
 wire _124_;
 wire _125_;
 wire _126_;
 wire _127_;
 wire _128_;
 wire _129_;
 wire _130_;
 wire _131_;
 wire _132_;
 wire _133_;
 wire _134_;
 wire _135_;
 wire _136_;
 wire _137_;
 wire _138_;
 wire _139_;
 wire _140_;
 wire _141_;
 wire _142_;
 wire _143_;
 wire _144_;
 wire _145_;
 wire _146_;
 wire _147_;
 wire _148_;
 wire _149_;
 wire _150_;
 wire _151_;
 wire _152_;
 wire _153_;
 wire _154_;
 wire _155_;
 wire _156_;
 wire _157_;
 wire _158_;
 wire _159_;
 wire _160_;
 wire _161_;
 wire _162_;
 wire _163_;
 wire _164_;
 wire _165_;
 wire _166_;
 wire _167_;
 wire _168_;
 wire _169_;
 wire _170_;
 wire _171_;
 wire _172_;
 wire _173_;
 wire _174_;
 wire _175_;
 wire _176_;
 wire _177_;
 wire _178_;
 wire _179_;
 wire _180_;
 wire _181_;
 wire _182_;
 wire _183_;
 wire _184_;
 wire _185_;
 wire _186_;
 wire _187_;
 wire _188_;
 wire _189_;
 wire _190_;
 wire _191_;
 wire _192_;
 wire _193_;
 wire _194_;
 wire _195_;
 wire _196_;
 wire _197_;
 wire _198_;
 wire _199_;
 wire _200_;
 wire _201_;
 wire _202_;
 wire _203_;
 wire _204_;
 wire _205_;
 wire _206_;
 wire _207_;
 wire _208_;
 wire _209_;
 wire _210_;
 wire _211_;
 wire _212_;
 wire _213_;
 wire _214_;
 wire _215_;
 wire _216_;
 wire _217_;
 wire _218_;
 wire _219_;
 wire _220_;
 wire _221_;
 wire _222_;
 wire _223_;
 wire _224_;
 wire _225_;
 wire _226_;
 wire _227_;
 wire _228_;
 wire _229_;
 wire _230_;
 wire _231_;
 wire _232_;
 wire _233_;
 wire _234_;
 wire _235_;
 wire _236_;
 wire _237_;
 wire _238_;
 wire _239_;
 wire _240_;
 wire _241_;
 wire _242_;
 wire _243_;
 wire _244_;
 wire _245_;
 wire _246_;
 wire _247_;
 wire _248_;
 wire _249_;
 wire _250_;
 wire _251_;
 wire _252_;
 wire _253_;
 wire _254_;
 wire _255_;
 wire _256_;
 wire _257_;
 wire _258_;
 wire _259_;
 wire _260_;
 wire _261_;
 wire _262_;
 wire _263_;
 wire _264_;
 wire _265_;
 wire _266_;
 wire _267_;
 wire _268_;
 wire _269_;
 wire _270_;
 wire _271_;
 wire _272_;
 wire _273_;
 wire _274_;
 wire _275_;
 wire _276_;
 wire _277_;
 wire _278_;
 wire _279_;
 wire _280_;
 wire _281_;
 wire _282_;
 wire _283_;
 wire _284_;
 wire _285_;
 wire _286_;
 wire _287_;
 wire _288_;
 wire _289_;
 wire _290_;
 wire _291_;
 wire _292_;
 wire _293_;
 wire _294_;
 wire _295_;
 wire _296_;
 wire _297_;
 wire _298_;
 wire _299_;
 wire _300_;
 wire _301_;
 wire _302_;
 wire _303_;
 wire _304_;
 wire _305_;
 wire _306_;
 wire _307_;
 wire _308_;
 wire _309_;
 wire _310_;
 wire _311_;
 wire _312_;
 wire _313_;
 wire _314_;
 wire _315_;
 wire _316_;
 wire _317_;
 wire _318_;
 wire _319_;
 wire _320_;
 wire _321_;
 wire _322_;
 wire _323_;
 wire _324_;
 wire _325_;
 wire _326_;
 wire _327_;
 wire _328_;
 wire _329_;
 wire _330_;
 wire _331_;
 wire _332_;
 wire _333_;
 wire _334_;
 wire _335_;
 wire _336_;
 wire _337_;
 wire _338_;
 wire _339_;
 wire _340_;
 wire _341_;
 wire _342_;
 wire _343_;
 wire _344_;
 wire _345_;
 wire _346_;
 wire _347_;
 wire _348_;
 wire _349_;
 wire _350_;
 wire _351_;
 wire _352_;
 wire _353_;
 wire carry_comb;
 wire \opcode_reg[0] ;
 wire \opcode_reg[1] ;
 wire \opcode_reg[2] ;
 wire \result_comb[0] ;
 wire \result_comb[10] ;
 wire \result_comb[11] ;
 wire \result_comb[12] ;
 wire \result_comb[13] ;
 wire \result_comb[14] ;
 wire \result_comb[15] ;
 wire \result_comb[1] ;
 wire \result_comb[2] ;
 wire \result_comb[3] ;
 wire \result_comb[4] ;
 wire \result_comb[5] ;
 wire \result_comb[6] ;
 wire \result_comb[7] ;
 wire \result_comb[8] ;
 wire \result_comb[9] ;
 wire net1;
 wire net2;
 wire net3;
 wire net4;
 wire net5;
 wire net6;
 wire net7;
 wire net8;
 wire net9;
 wire net10;
 wire net11;
 wire net12;
 wire net13;
 wire net14;
 wire net15;
 wire net16;
 wire net17;
 wire net18;
 wire net19;
 wire net20;
 wire net21;
 wire net22;
 wire net23;
 wire net24;
 wire net25;
 wire net26;
 wire net27;
 wire net28;
 wire net29;
 wire net30;
 wire net31;
 wire net32;
 wire net33;
 wire net34;
 wire net35;
 wire net36;
 wire net37;
 wire net38;
 wire net39;
 wire net40;
 wire net41;
 wire net42;
 wire net43;
 wire net44;
 wire net45;
 wire net46;
 wire net47;
 wire net48;
 wire net49;
 wire net50;
 wire net51;
 wire net52;
 wire net53;
 wire net54;
 wire net55;
 wire net56;
 wire net57;
 wire net58;
 wire net59;
 wire net60;
 wire net61;
 wire net62;
 wire net63;
 wire net64;
 wire net65;
 wire net66;
 wire net67;
 wire net68;
 wire net69;
 wire net70;
 wire net71;
 wire net72;
 wire net73;
 wire net74;
 wire net75;
 wire net76;
 wire net77;
 wire net78;
 wire net79;
 wire net80;
 wire net81;
 wire net82;
 wire net83;
 wire net84;
 wire net85;
 wire net86;
 wire net87;
 wire net88;
 wire net89;
 wire net90;
 wire net91;
 wire net92;

 sky130_fd_sc_hd__inv_2 _354_ (.A(\opcode_reg[0] ),
    .Y(_309_));
 sky130_fd_sc_hd__inv_2 _355_ (.A(net71),
    .Y(_310_));
 sky130_fd_sc_hd__inv_2 _356_ (.A(net74),
    .Y(_311_));
 sky130_fd_sc_hd__inv_2 _357_ (.A(net75),
    .Y(_312_));
 sky130_fd_sc_hd__inv_2 _358_ (.A(\A_reg[1] ),
    .Y(_313_));
 sky130_fd_sc_hd__inv_2 _359_ (.A(net92),
    .Y(_314_));
 sky130_fd_sc_hd__inv_2 _360_ (.A(\A_reg[4] ),
    .Y(_315_));
 sky130_fd_sc_hd__inv_2 _361_ (.A(\A_reg[5] ),
    .Y(_316_));
 sky130_fd_sc_hd__inv_2 _362_ (.A(\A_reg[12] ),
    .Y(_317_));
 sky130_fd_sc_hd__inv_2 _363_ (.A(\A_reg[13] ),
    .Y(_318_));
 sky130_fd_sc_hd__inv_2 _364_ (.A(\A_reg[14] ),
    .Y(_319_));
 sky130_fd_sc_hd__inv_2 _365_ (.A(\A_reg[15] ),
    .Y(_320_));
 sky130_fd_sc_hd__nor2_1 _366_ (.A(\A_reg[0] ),
    .B(net80),
    .Y(_321_));
 sky130_fd_sc_hd__nand2_1 _367_ (.A(\A_reg[0] ),
    .B(net79),
    .Y(_322_));
 sky130_fd_sc_hd__and2b_1 _368_ (.A_N(_321_),
    .B(_322_),
    .X(_323_));
 sky130_fd_sc_hd__nor2_4 _369_ (.A(net71),
    .B(net70),
    .Y(_324_));
 sky130_fd_sc_hd__or2_1 _370_ (.A(net71),
    .B(net70),
    .X(_325_));
 sky130_fd_sc_hd__and3_4 _371_ (.A(\opcode_reg[0] ),
    .B(\opcode_reg[1] ),
    .C(\opcode_reg[2] ),
    .X(_326_));
 sky130_fd_sc_hd__nand2_1 _372_ (.A(\B_reg[3] ),
    .B(_326_),
    .Y(_327_));
 sky130_fd_sc_hd__mux4_1 _373_ (.A0(\A_reg[8] ),
    .A1(\A_reg[9] ),
    .A2(\A_reg[10] ),
    .A3(net84),
    .S0(net82),
    .S1(net77),
    .X(_328_));
 sky130_fd_sc_hd__mux2_1 _374_ (.A0(\A_reg[14] ),
    .A1(\A_reg[15] ),
    .S(net81),
    .X(_329_));
 sky130_fd_sc_hd__mux4_2 _375_ (.A0(\A_reg[12] ),
    .A1(\A_reg[13] ),
    .A2(\A_reg[14] ),
    .A3(\A_reg[15] ),
    .S0(net81),
    .S1(net76),
    .X(_330_));
 sky130_fd_sc_hd__mux2_1 _376_ (.A0(_328_),
    .A1(_330_),
    .S(net73),
    .X(_331_));
 sky130_fd_sc_hd__nor2_1 _377_ (.A(net80),
    .B(net75),
    .Y(_332_));
 sky130_fd_sc_hd__nand2_1 _378_ (.A(net68),
    .B(_332_),
    .Y(_333_));
 sky130_fd_sc_hd__and2b_1 _379_ (.A_N(net79),
    .B(\A_reg[0] ),
    .X(_334_));
 sky130_fd_sc_hd__or3b_1 _380_ (.A(net73),
    .B(net77),
    .C_N(_334_),
    .X(_335_));
 sky130_fd_sc_hd__and3b_1 _381_ (.A_N(\opcode_reg[0] ),
    .B(net71),
    .C(net70),
    .X(_336_));
 sky130_fd_sc_hd__and2b_1 _382_ (.A_N(net72),
    .B(_336_),
    .X(_337_));
 sky130_fd_sc_hd__nand2b_1 _383_ (.A_N(\B_reg[3] ),
    .B(_336_),
    .Y(_338_));
 sky130_fd_sc_hd__or3b_1 _384_ (.A(_309_),
    .B(net71),
    .C_N(\opcode_reg[2] ),
    .X(_339_));
 sky130_fd_sc_hd__and3_1 _385_ (.A(_309_),
    .B(_310_),
    .C(net70),
    .X(_340_));
 sky130_fd_sc_hd__or3b_2 _386_ (.A(\opcode_reg[0] ),
    .B(net71),
    .C_N(net70),
    .X(_341_));
 sky130_fd_sc_hd__nand2_1 _387_ (.A(_323_),
    .B(_340_),
    .Y(_342_));
 sky130_fd_sc_hd__or3_1 _388_ (.A(\opcode_reg[0] ),
    .B(_310_),
    .C(net70),
    .X(_343_));
 sky130_fd_sc_hd__and2b_2 _389_ (.A_N(net70),
    .B(\opcode_reg[0] ),
    .X(_344_));
 sky130_fd_sc_hd__o31a_1 _390_ (.A1(_309_),
    .A2(net70),
    .A3(_321_),
    .B1(net64),
    .X(_345_));
 sky130_fd_sc_hd__o221a_1 _391_ (.A1(\A_reg[0] ),
    .A2(net58),
    .B1(net56),
    .B2(_322_),
    .C1(_342_),
    .X(_346_));
 sky130_fd_sc_hd__and2_4 _392_ (.A(net71),
    .B(_344_),
    .X(_347_));
 sky130_fd_sc_hd__o211ai_1 _393_ (.A1(_335_),
    .A2(_338_),
    .B1(_345_),
    .C1(_346_),
    .Y(_348_));
 sky130_fd_sc_hd__and2b_1 _394_ (.A_N(net72),
    .B(_326_),
    .X(_349_));
 sky130_fd_sc_hd__nand4b_4 _395_ (.A_N(net72),
    .B(net70),
    .C(net71),
    .D(\opcode_reg[0] ),
    .Y(_350_));
 sky130_fd_sc_hd__nor2_4 _396_ (.A(net74),
    .B(_350_),
    .Y(_351_));
 sky130_fd_sc_hd__mux4_1 _397_ (.A0(\A_reg[0] ),
    .A1(\A_reg[1] ),
    .A2(net92),
    .A3(net91),
    .S0(net79),
    .S1(net77),
    .X(_352_));
 sky130_fd_sc_hd__mux4_1 _398_ (.A0(net90),
    .A1(\A_reg[5] ),
    .A2(net89),
    .A3(net88),
    .S0(net79),
    .S1(net77),
    .X(_353_));
 sky130_fd_sc_hd__nor2_2 _399_ (.A(net68),
    .B(_350_),
    .Y(_002_));
 sky130_fd_sc_hd__a22o_1 _400_ (.A1(_351_),
    .A2(_352_),
    .B1(_353_),
    .B2(_002_),
    .X(_003_));
 sky130_fd_sc_hd__a31o_1 _401_ (.A1(\B_reg[3] ),
    .A2(_326_),
    .A3(_331_),
    .B1(_003_),
    .X(_004_));
 sky130_fd_sc_hd__o22a_1 _402_ (.A1(_323_),
    .A2(net64),
    .B1(_348_),
    .B2(_004_),
    .X(\result_comb[0] ));
 sky130_fd_sc_hd__or3b_4 _403_ (.A(net71),
    .B(\opcode_reg[2] ),
    .C_N(\opcode_reg[0] ),
    .X(_005_));
 sky130_fd_sc_hd__xnor2_2 _404_ (.A(net67),
    .B(net61),
    .Y(_006_));
 sky130_fd_sc_hd__or2_1 _405_ (.A(_313_),
    .B(_006_),
    .X(_007_));
 sky130_fd_sc_hd__xnor2_2 _406_ (.A(\A_reg[1] ),
    .B(_006_),
    .Y(_008_));
 sky130_fd_sc_hd__xnor2_1 _407_ (.A(_313_),
    .B(_006_),
    .Y(_009_));
 sky130_fd_sc_hd__o21ai_1 _408_ (.A1(net79),
    .A2(net61),
    .B1(_322_),
    .Y(_010_));
 sky130_fd_sc_hd__xnor2_1 _409_ (.A(_008_),
    .B(_010_),
    .Y(_011_));
 sky130_fd_sc_hd__mux4_1 _410_ (.A0(\A_reg[1] ),
    .A1(net92),
    .A2(net91),
    .A3(net90),
    .S0(net79),
    .S1(net77),
    .X(_012_));
 sky130_fd_sc_hd__mux4_1 _411_ (.A0(\A_reg[5] ),
    .A1(net89),
    .A2(net88),
    .A3(net87),
    .S0(net82),
    .S1(net78),
    .X(_013_));
 sky130_fd_sc_hd__a22o_1 _412_ (.A1(_351_),
    .A2(_012_),
    .B1(_013_),
    .B2(_002_),
    .X(_014_));
 sky130_fd_sc_hd__mux2_1 _413_ (.A0(\A_reg[1] ),
    .A1(\A_reg[0] ),
    .S(net80),
    .X(_015_));
 sky130_fd_sc_hd__and2_1 _414_ (.A(net67),
    .B(_015_),
    .X(_016_));
 sky130_fd_sc_hd__or3b_1 _415_ (.A(net73),
    .B(_338_),
    .C_N(_016_),
    .X(_017_));
 sky130_fd_sc_hd__o21ai_1 _416_ (.A1(net77),
    .A2(\A_reg[1] ),
    .B1(_344_),
    .Y(_018_));
 sky130_fd_sc_hd__o211a_1 _417_ (.A1(\A_reg[1] ),
    .A2(net58),
    .B1(_018_),
    .C1(net65),
    .X(_019_));
 sky130_fd_sc_hd__mux2_1 _418_ (.A0(net86),
    .A1(net85),
    .S(net83),
    .X(_020_));
 sky130_fd_sc_hd__inv_2 _419_ (.A(_020_),
    .Y(_021_));
 sky130_fd_sc_hd__mux2_1 _420_ (.A0(net84),
    .A1(\A_reg[12] ),
    .S(net83),
    .X(_022_));
 sky130_fd_sc_hd__inv_2 _421_ (.A(_022_),
    .Y(_023_));
 sky130_fd_sc_hd__mux2_1 _422_ (.A0(_020_),
    .A1(_022_),
    .S(net78),
    .X(_024_));
 sky130_fd_sc_hd__mux2_1 _423_ (.A0(\A_reg[13] ),
    .A1(\A_reg[14] ),
    .S(net81),
    .X(_025_));
 sky130_fd_sc_hd__inv_2 _424_ (.A(_025_),
    .Y(_026_));
 sky130_fd_sc_hd__nand2_1 _425_ (.A(net66),
    .B(_025_),
    .Y(_027_));
 sky130_fd_sc_hd__or2_1 _426_ (.A(net81),
    .B(_320_),
    .X(_028_));
 sky130_fd_sc_hd__o21ai_1 _427_ (.A1(net66),
    .A2(_028_),
    .B1(_027_),
    .Y(_029_));
 sky130_fd_sc_hd__mux4_2 _428_ (.A0(_021_),
    .A1(_023_),
    .A2(_026_),
    .A3(_028_),
    .S0(net78),
    .S1(net74),
    .X(_030_));
 sky130_fd_sc_hd__o211a_1 _429_ (.A1(_327_),
    .A2(_030_),
    .B1(_019_),
    .C1(_017_),
    .X(_031_));
 sky130_fd_sc_hd__a21oi_1 _430_ (.A1(_340_),
    .A2(_008_),
    .B1(_014_),
    .Y(_032_));
 sky130_fd_sc_hd__o211a_1 _431_ (.A1(net56),
    .A2(_007_),
    .B1(_031_),
    .C1(_032_),
    .X(_033_));
 sky130_fd_sc_hd__a21oi_1 _432_ (.A1(_324_),
    .A2(_011_),
    .B1(_033_),
    .Y(\result_comb[1] ));
 sky130_fd_sc_hd__and2_1 _433_ (.A(net73),
    .B(net61),
    .X(_034_));
 sky130_fd_sc_hd__nor2_1 _434_ (.A(net73),
    .B(net61),
    .Y(_035_));
 sky130_fd_sc_hd__xnor2_2 _435_ (.A(net69),
    .B(net61),
    .Y(_036_));
 sky130_fd_sc_hd__nor2_1 _436_ (.A(_314_),
    .B(_036_),
    .Y(_037_));
 sky130_fd_sc_hd__nand2_1 _437_ (.A(_314_),
    .B(_036_),
    .Y(_038_));
 sky130_fd_sc_hd__xnor2_2 _438_ (.A(_314_),
    .B(_036_),
    .Y(_039_));
 sky130_fd_sc_hd__a21bo_1 _439_ (.A1(_008_),
    .A2(_010_),
    .B1_N(_007_),
    .X(_040_));
 sky130_fd_sc_hd__xnor2_1 _440_ (.A(_039_),
    .B(_040_),
    .Y(_041_));
 sky130_fd_sc_hd__nand2_2 _441_ (.A(net66),
    .B(_329_),
    .Y(_042_));
 sky130_fd_sc_hd__mux4_1 _442_ (.A0(\A_reg[10] ),
    .A1(\A_reg[11] ),
    .A2(\A_reg[12] ),
    .A3(\A_reg[13] ),
    .S0(net82),
    .S1(net78),
    .X(_043_));
 sky130_fd_sc_hd__nor2_1 _443_ (.A(net73),
    .B(_043_),
    .Y(_044_));
 sky130_fd_sc_hd__a211o_1 _444_ (.A1(net73),
    .A2(_042_),
    .B1(_044_),
    .C1(_327_),
    .X(_045_));
 sky130_fd_sc_hd__o21ai_1 _445_ (.A1(net63),
    .A2(_039_),
    .B1(_045_),
    .Y(_046_));
 sky130_fd_sc_hd__mux4_1 _446_ (.A0(net92),
    .A1(\A_reg[3] ),
    .A2(net90),
    .A3(\A_reg[5] ),
    .S0(net79),
    .S1(net77),
    .X(_047_));
 sky130_fd_sc_hd__o21ai_1 _447_ (.A1(net73),
    .A2(\A_reg[2] ),
    .B1(_344_),
    .Y(_048_));
 sky130_fd_sc_hd__o211ai_1 _448_ (.A1(net92),
    .A2(net58),
    .B1(_048_),
    .C1(net65),
    .Y(_049_));
 sky130_fd_sc_hd__mux4_1 _449_ (.A0(\A_reg[6] ),
    .A1(\A_reg[7] ),
    .A2(net87),
    .A3(net86),
    .S0(net82),
    .S1(net77),
    .X(_050_));
 sky130_fd_sc_hd__a221o_1 _450_ (.A1(_351_),
    .A2(_047_),
    .B1(_050_),
    .B2(_002_),
    .C1(_049_),
    .X(_051_));
 sky130_fd_sc_hd__or3_1 _451_ (.A(_314_),
    .B(net56),
    .C(_036_),
    .X(_052_));
 sky130_fd_sc_hd__mux2_1 _452_ (.A0(net92),
    .A1(\A_reg[1] ),
    .S(net79),
    .X(_053_));
 sky130_fd_sc_hd__mux2_1 _453_ (.A0(_334_),
    .A1(_053_),
    .S(net67),
    .X(_054_));
 sky130_fd_sc_hd__and3_1 _454_ (.A(net68),
    .B(_336_),
    .C(_054_),
    .X(_055_));
 sky130_fd_sc_hd__and3_1 _455_ (.A(net69),
    .B(net60),
    .C(_054_),
    .X(_056_));
 sky130_fd_sc_hd__or4b_1 _456_ (.A(_046_),
    .B(_056_),
    .C(_051_),
    .D_N(_052_),
    .X(_057_));
 sky130_fd_sc_hd__o21a_1 _457_ (.A1(net65),
    .A2(_041_),
    .B1(_057_),
    .X(\result_comb[2] ));
 sky130_fd_sc_hd__xnor2_2 _458_ (.A(net72),
    .B(net61),
    .Y(_058_));
 sky130_fd_sc_hd__nand2_1 _459_ (.A(net91),
    .B(_058_),
    .Y(_059_));
 sky130_fd_sc_hd__xnor2_2 _460_ (.A(net91),
    .B(_058_),
    .Y(_060_));
 sky130_fd_sc_hd__a21o_1 _461_ (.A1(_038_),
    .A2(_040_),
    .B1(_037_),
    .X(_061_));
 sky130_fd_sc_hd__xnor2_1 _462_ (.A(_060_),
    .B(_061_),
    .Y(_062_));
 sky130_fd_sc_hd__mux2_1 _463_ (.A0(net91),
    .A1(net92),
    .S(net82),
    .X(_063_));
 sky130_fd_sc_hd__mux2_1 _464_ (.A0(_015_),
    .A1(_063_),
    .S(net66),
    .X(_064_));
 sky130_fd_sc_hd__nand2_1 _465_ (.A(net69),
    .B(_064_),
    .Y(_065_));
 sky130_fd_sc_hd__o21ai_1 _466_ (.A1(\B_reg[3] ),
    .A2(net91),
    .B1(_347_),
    .Y(_066_));
 sky130_fd_sc_hd__o221a_1 _467_ (.A1(\A_reg[3] ),
    .A2(net58),
    .B1(_065_),
    .B2(_338_),
    .C1(_066_),
    .X(_067_));
 sky130_fd_sc_hd__o21ai_1 _468_ (.A1(net56),
    .A2(_059_),
    .B1(_067_),
    .Y(_068_));
 sky130_fd_sc_hd__nor2_1 _469_ (.A(net63),
    .B(_060_),
    .Y(_069_));
 sky130_fd_sc_hd__mux4_1 _470_ (.A0(\A_reg[7] ),
    .A1(net87),
    .A2(net86),
    .A3(net85),
    .S0(net82),
    .S1(net78),
    .X(_070_));
 sky130_fd_sc_hd__mux4_1 _471_ (.A0(\A_reg[3] ),
    .A1(net90),
    .A2(\A_reg[5] ),
    .A3(\A_reg[6] ),
    .S0(net79),
    .S1(net77),
    .X(_071_));
 sky130_fd_sc_hd__mux2_1 _472_ (.A0(_070_),
    .A1(_071_),
    .S(net69),
    .X(_072_));
 sky130_fd_sc_hd__nor2_1 _473_ (.A(net77),
    .B(_028_),
    .Y(_073_));
 sky130_fd_sc_hd__mux2_1 _474_ (.A0(_022_),
    .A1(_025_),
    .S(net78),
    .X(_074_));
 sky130_fd_sc_hd__mux2_1 _475_ (.A0(_073_),
    .A1(_074_),
    .S(net69),
    .X(_075_));
 sky130_fd_sc_hd__a31o_1 _476_ (.A1(net72),
    .A2(_326_),
    .A3(_075_),
    .B1(_069_),
    .X(_076_));
 sky130_fd_sc_hd__a21o_1 _477_ (.A1(_349_),
    .A2(_072_),
    .B1(_076_),
    .X(_077_));
 sky130_fd_sc_hd__a211o_1 _478_ (.A1(_324_),
    .A2(_062_),
    .B1(_068_),
    .C1(_077_),
    .X(\result_comb[3] ));
 sky130_fd_sc_hd__xor2_2 _479_ (.A(\B_reg[4] ),
    .B(net61),
    .X(_078_));
 sky130_fd_sc_hd__or2_1 _480_ (.A(_315_),
    .B(_078_),
    .X(_079_));
 sky130_fd_sc_hd__xnor2_2 _481_ (.A(_315_),
    .B(_078_),
    .Y(_080_));
 sky130_fd_sc_hd__or2_1 _482_ (.A(_323_),
    .B(net61),
    .X(_081_));
 sky130_fd_sc_hd__or4_2 _483_ (.A(_009_),
    .B(_039_),
    .C(_060_),
    .D(_081_),
    .X(_082_));
 sky130_fd_sc_hd__xnor2_1 _484_ (.A(net79),
    .B(net61),
    .Y(_083_));
 sky130_fd_sc_hd__nand2_1 _485_ (.A(\A_reg[0] ),
    .B(_083_),
    .Y(_084_));
 sky130_fd_sc_hd__or4_2 _486_ (.A(_009_),
    .B(_039_),
    .C(_060_),
    .D(_084_),
    .X(_085_));
 sky130_fd_sc_hd__o221ai_1 _487_ (.A1(_034_),
    .A2(_035_),
    .B1(_058_),
    .B2(net91),
    .C1(net92),
    .Y(_086_));
 sky130_fd_sc_hd__o311a_1 _488_ (.A1(_007_),
    .A2(_039_),
    .A3(_060_),
    .B1(_086_),
    .C1(_059_),
    .X(_087_));
 sky130_fd_sc_hd__and3_1 _489_ (.A(_082_),
    .B(_085_),
    .C(_087_),
    .X(_088_));
 sky130_fd_sc_hd__a31o_1 _490_ (.A1(_082_),
    .A2(_085_),
    .A3(_087_),
    .B1(_080_),
    .X(_089_));
 sky130_fd_sc_hd__xor2_1 _491_ (.A(_080_),
    .B(_088_),
    .X(_090_));
 sky130_fd_sc_hd__and3_1 _492_ (.A(\A_reg[0] ),
    .B(net74),
    .C(_332_),
    .X(_091_));
 sky130_fd_sc_hd__mux4_1 _493_ (.A0(net90),
    .A1(net91),
    .A2(net92),
    .A3(\A_reg[1] ),
    .S0(net80),
    .S1(net75),
    .X(_092_));
 sky130_fd_sc_hd__a21o_1 _494_ (.A1(net68),
    .A2(_092_),
    .B1(_091_),
    .X(_093_));
 sky130_fd_sc_hd__a2bb2o_1 _495_ (.A1_N(net63),
    .A2_N(_080_),
    .B1(_093_),
    .B2(net60),
    .X(_094_));
 sky130_fd_sc_hd__nor2_1 _496_ (.A(net56),
    .B(_079_),
    .Y(_095_));
 sky130_fd_sc_hd__nor2_1 _497_ (.A(net73),
    .B(_327_),
    .Y(_096_));
 sky130_fd_sc_hd__o21ai_1 _498_ (.A1(net90),
    .A2(\B_reg[4] ),
    .B1(_344_),
    .Y(_097_));
 sky130_fd_sc_hd__o211ai_1 _499_ (.A1(net90),
    .A2(net58),
    .B1(_097_),
    .C1(net64),
    .Y(_098_));
 sky130_fd_sc_hd__a221o_1 _500_ (.A1(_351_),
    .A2(_353_),
    .B1(_002_),
    .B2(_328_),
    .C1(_098_),
    .X(_099_));
 sky130_fd_sc_hd__a211o_1 _501_ (.A1(_330_),
    .A2(_096_),
    .B1(_099_),
    .C1(_095_),
    .X(_100_));
 sky130_fd_sc_hd__o22a_1 _502_ (.A1(net65),
    .A2(_090_),
    .B1(_094_),
    .B2(_100_),
    .X(\result_comb[4] ));
 sky130_fd_sc_hd__xor2_2 _503_ (.A(\B_reg[5] ),
    .B(net61),
    .X(_101_));
 sky130_fd_sc_hd__or2_2 _504_ (.A(_316_),
    .B(_101_),
    .X(_102_));
 sky130_fd_sc_hd__xnor2_2 _505_ (.A(_316_),
    .B(_101_),
    .Y(_103_));
 sky130_fd_sc_hd__a21o_1 _506_ (.A1(_079_),
    .A2(_089_),
    .B1(_103_),
    .X(_104_));
 sky130_fd_sc_hd__nand3_1 _507_ (.A(_079_),
    .B(_089_),
    .C(_103_),
    .Y(_105_));
 sky130_fd_sc_hd__a21oi_1 _508_ (.A1(_104_),
    .A2(_105_),
    .B1(net64),
    .Y(_106_));
 sky130_fd_sc_hd__mux2_1 _509_ (.A0(\A_reg[5] ),
    .A1(net90),
    .S(net82),
    .X(_107_));
 sky130_fd_sc_hd__mux2_1 _510_ (.A0(_063_),
    .A1(_107_),
    .S(net66),
    .X(_108_));
 sky130_fd_sc_hd__mux2_1 _511_ (.A0(_016_),
    .A1(_108_),
    .S(net69),
    .X(_109_));
 sky130_fd_sc_hd__a2bb2o_1 _512_ (.A1_N(net63),
    .A2_N(_103_),
    .B1(_109_),
    .B2(net60),
    .X(_110_));
 sky130_fd_sc_hd__nor2_1 _513_ (.A(net56),
    .B(_102_),
    .Y(_111_));
 sky130_fd_sc_hd__o21ai_1 _514_ (.A1(\A_reg[5] ),
    .A2(\B_reg[5] ),
    .B1(_344_),
    .Y(_112_));
 sky130_fd_sc_hd__o211ai_1 _515_ (.A1(\A_reg[5] ),
    .A2(net58),
    .B1(_112_),
    .C1(net64),
    .Y(_113_));
 sky130_fd_sc_hd__a221o_1 _516_ (.A1(_351_),
    .A2(_013_),
    .B1(_024_),
    .B2(_002_),
    .C1(_110_),
    .X(_114_));
 sky130_fd_sc_hd__a211o_1 _517_ (.A1(_029_),
    .A2(_096_),
    .B1(_113_),
    .C1(_114_),
    .X(_115_));
 sky130_fd_sc_hd__o21ba_1 _518_ (.A1(_111_),
    .A2(_115_),
    .B1_N(_106_),
    .X(\result_comb[5] ));
 sky130_fd_sc_hd__xnor2_2 _519_ (.A(\B_reg[6] ),
    .B(net62),
    .Y(_116_));
 sky130_fd_sc_hd__nand2_1 _520_ (.A(\A_reg[6] ),
    .B(_116_),
    .Y(_117_));
 sky130_fd_sc_hd__nor2_1 _521_ (.A(net89),
    .B(_116_),
    .Y(_118_));
 sky130_fd_sc_hd__xnor2_2 _522_ (.A(net89),
    .B(_116_),
    .Y(_119_));
 sky130_fd_sc_hd__a21oi_1 _523_ (.A1(_102_),
    .A2(_104_),
    .B1(_119_),
    .Y(_120_));
 sky130_fd_sc_hd__a31o_1 _524_ (.A1(_102_),
    .A2(_104_),
    .A3(_119_),
    .B1(net64),
    .X(_121_));
 sky130_fd_sc_hd__nor2_1 _525_ (.A(_120_),
    .B(_121_),
    .Y(_122_));
 sky130_fd_sc_hd__nor2_1 _526_ (.A(net56),
    .B(_117_),
    .Y(_123_));
 sky130_fd_sc_hd__o21ai_1 _527_ (.A1(net89),
    .A2(\B_reg[6] ),
    .B1(_347_),
    .Y(_124_));
 sky130_fd_sc_hd__o32a_1 _528_ (.A1(\B_reg[2] ),
    .A2(_327_),
    .A3(_042_),
    .B1(net58),
    .B2(net89),
    .X(_125_));
 sky130_fd_sc_hd__nand2_1 _529_ (.A(_124_),
    .B(_125_),
    .Y(_126_));
 sky130_fd_sc_hd__a221o_1 _530_ (.A1(_002_),
    .A2(_043_),
    .B1(_050_),
    .B2(_351_),
    .C1(_126_),
    .X(_127_));
 sky130_fd_sc_hd__mux4_1 _531_ (.A0(net89),
    .A1(\A_reg[5] ),
    .A2(net90),
    .A3(net91),
    .S0(net81),
    .S1(net75),
    .X(_128_));
 sky130_fd_sc_hd__mux2_1 _532_ (.A0(_054_),
    .A1(_128_),
    .S(net68),
    .X(_129_));
 sky130_fd_sc_hd__a2bb2o_1 _533_ (.A1_N(net63),
    .A2_N(_119_),
    .B1(_129_),
    .B2(net60),
    .X(_130_));
 sky130_fd_sc_hd__or4_1 _534_ (.A(_122_),
    .B(_123_),
    .C(_127_),
    .D(_130_),
    .X(\result_comb[6] ));
 sky130_fd_sc_hd__xnor2_1 _535_ (.A(\B_reg[7] ),
    .B(net62),
    .Y(_131_));
 sky130_fd_sc_hd__nand2_1 _536_ (.A(\A_reg[7] ),
    .B(_131_),
    .Y(_132_));
 sky130_fd_sc_hd__nor2_1 _537_ (.A(net88),
    .B(_131_),
    .Y(_133_));
 sky130_fd_sc_hd__xnor2_1 _538_ (.A(net88),
    .B(_131_),
    .Y(_134_));
 sky130_fd_sc_hd__a31o_1 _539_ (.A1(_102_),
    .A2(_104_),
    .A3(_117_),
    .B1(_118_),
    .X(_135_));
 sky130_fd_sc_hd__xor2_1 _540_ (.A(_134_),
    .B(_135_),
    .X(_136_));
 sky130_fd_sc_hd__o21ai_1 _541_ (.A1(net88),
    .A2(\B_reg[7] ),
    .B1(_347_),
    .Y(_137_));
 sky130_fd_sc_hd__o221ai_1 _542_ (.A1(net88),
    .A2(net58),
    .B1(net56),
    .B2(_132_),
    .C1(_137_),
    .Y(_138_));
 sky130_fd_sc_hd__a22o_1 _543_ (.A1(_351_),
    .A2(_070_),
    .B1(_074_),
    .B2(_002_),
    .X(_139_));
 sky130_fd_sc_hd__a211o_1 _544_ (.A1(_073_),
    .A2(_096_),
    .B1(_138_),
    .C1(_139_),
    .X(_140_));
 sky130_fd_sc_hd__mux2_1 _545_ (.A0(net88),
    .A1(net89),
    .S(net82),
    .X(_141_));
 sky130_fd_sc_hd__mux2_1 _546_ (.A0(_107_),
    .A1(_141_),
    .S(net66),
    .X(_142_));
 sky130_fd_sc_hd__mux2_1 _547_ (.A0(_064_),
    .A1(_142_),
    .S(_311_),
    .X(_143_));
 sky130_fd_sc_hd__a2bb2o_1 _548_ (.A1_N(net63),
    .A2_N(_134_),
    .B1(_143_),
    .B2(_337_),
    .X(_144_));
 sky130_fd_sc_hd__a211o_1 _549_ (.A1(_324_),
    .A2(_136_),
    .B1(_140_),
    .C1(_144_),
    .X(\result_comb[7] ));
 sky130_fd_sc_hd__xnor2_2 _550_ (.A(\B_reg[8] ),
    .B(net62),
    .Y(_145_));
 sky130_fd_sc_hd__nand2_2 _551_ (.A(net87),
    .B(_145_),
    .Y(_146_));
 sky130_fd_sc_hd__xnor2_2 _552_ (.A(net87),
    .B(_145_),
    .Y(_147_));
 sky130_fd_sc_hd__or4_1 _553_ (.A(_079_),
    .B(_103_),
    .C(_119_),
    .D(_134_),
    .X(_148_));
 sky130_fd_sc_hd__o211a_1 _554_ (.A1(_102_),
    .A2(_119_),
    .B1(_132_),
    .C1(_117_),
    .X(_149_));
 sky130_fd_sc_hd__o21a_1 _555_ (.A1(_133_),
    .A2(_149_),
    .B1(_148_),
    .X(_150_));
 sky130_fd_sc_hd__or4_1 _556_ (.A(_080_),
    .B(_103_),
    .C(_119_),
    .D(_134_),
    .X(_151_));
 sky130_fd_sc_hd__a31o_1 _557_ (.A1(_082_),
    .A2(_085_),
    .A3(_087_),
    .B1(_151_),
    .X(_152_));
 sky130_fd_sc_hd__a21o_1 _558_ (.A1(_150_),
    .A2(_152_),
    .B1(_147_),
    .X(_153_));
 sky130_fd_sc_hd__nand3_1 _559_ (.A(_147_),
    .B(_150_),
    .C(_152_),
    .Y(_154_));
 sky130_fd_sc_hd__a21o_1 _560_ (.A1(_153_),
    .A2(_154_),
    .B1(net65),
    .X(_155_));
 sky130_fd_sc_hd__mux4_1 _561_ (.A0(net87),
    .A1(net88),
    .A2(net89),
    .A3(\A_reg[5] ),
    .S0(net81),
    .S1(net75),
    .X(_156_));
 sky130_fd_sc_hd__or2_1 _562_ (.A(net74),
    .B(_156_),
    .X(_157_));
 sky130_fd_sc_hd__o21a_1 _563_ (.A1(net68),
    .A2(_092_),
    .B1(net60),
    .X(_158_));
 sky130_fd_sc_hd__a22o_1 _564_ (.A1(_331_),
    .A2(_349_),
    .B1(_157_),
    .B2(_158_),
    .X(_159_));
 sky130_fd_sc_hd__o21ai_1 _565_ (.A1(net87),
    .A2(\B_reg[8] ),
    .B1(_344_),
    .Y(_160_));
 sky130_fd_sc_hd__o211a_1 _566_ (.A1(net87),
    .A2(net58),
    .B1(_160_),
    .C1(net65),
    .X(_161_));
 sky130_fd_sc_hd__and2_1 _567_ (.A(net72),
    .B(_336_),
    .X(_162_));
 sky130_fd_sc_hd__nand2_1 _568_ (.A(net72),
    .B(_336_),
    .Y(_163_));
 sky130_fd_sc_hd__o221a_1 _569_ (.A1(net56),
    .A2(_146_),
    .B1(_163_),
    .B2(_335_),
    .C1(_161_),
    .X(_164_));
 sky130_fd_sc_hd__o21ai_1 _570_ (.A1(_341_),
    .A2(_147_),
    .B1(_164_),
    .Y(_165_));
 sky130_fd_sc_hd__o21a_1 _571_ (.A1(_159_),
    .A2(_165_),
    .B1(_155_),
    .X(\result_comb[8] ));
 sky130_fd_sc_hd__xnor2_2 _572_ (.A(\B_reg[9] ),
    .B(net62),
    .Y(_166_));
 sky130_fd_sc_hd__nand2_1 _573_ (.A(\A_reg[9] ),
    .B(_166_),
    .Y(_167_));
 sky130_fd_sc_hd__nor2_1 _574_ (.A(net86),
    .B(_166_),
    .Y(_168_));
 sky130_fd_sc_hd__xnor2_2 _575_ (.A(net86),
    .B(_166_),
    .Y(_169_));
 sky130_fd_sc_hd__nand3_1 _576_ (.A(_146_),
    .B(_153_),
    .C(_169_),
    .Y(_170_));
 sky130_fd_sc_hd__a21o_1 _577_ (.A1(_146_),
    .A2(_153_),
    .B1(_169_),
    .X(_171_));
 sky130_fd_sc_hd__or3b_1 _578_ (.A(_163_),
    .B(net73),
    .C_N(_016_),
    .X(_172_));
 sky130_fd_sc_hd__o21ai_1 _579_ (.A1(\A_reg[9] ),
    .A2(\B_reg[9] ),
    .B1(_347_),
    .Y(_173_));
 sky130_fd_sc_hd__o211a_1 _580_ (.A1(net86),
    .A2(net58),
    .B1(_172_),
    .C1(_173_),
    .X(_174_));
 sky130_fd_sc_hd__mux2_1 _581_ (.A0(net86),
    .A1(\A_reg[8] ),
    .S(net82),
    .X(_175_));
 sky130_fd_sc_hd__mux4_1 _582_ (.A0(_063_),
    .A1(_107_),
    .A2(_141_),
    .A3(_175_),
    .S0(net67),
    .S1(net69),
    .X(_176_));
 sky130_fd_sc_hd__o221a_1 _583_ (.A1(net56),
    .A2(_167_),
    .B1(_169_),
    .B2(_341_),
    .C1(_174_),
    .X(_177_));
 sky130_fd_sc_hd__o21ai_1 _584_ (.A1(_350_),
    .A2(_030_),
    .B1(_177_),
    .Y(_178_));
 sky130_fd_sc_hd__a21o_1 _585_ (.A1(_337_),
    .A2(_176_),
    .B1(_178_),
    .X(_179_));
 sky130_fd_sc_hd__a31o_1 _586_ (.A1(_324_),
    .A2(_170_),
    .A3(_171_),
    .B1(_179_),
    .X(\result_comb[9] ));
 sky130_fd_sc_hd__xnor2_2 _587_ (.A(\B_reg[10] ),
    .B(_005_),
    .Y(_180_));
 sky130_fd_sc_hd__nand2_1 _588_ (.A(net85),
    .B(_180_),
    .Y(_181_));
 sky130_fd_sc_hd__nor2_1 _589_ (.A(net85),
    .B(_180_),
    .Y(_182_));
 sky130_fd_sc_hd__xnor2_2 _590_ (.A(\A_reg[10] ),
    .B(_180_),
    .Y(_183_));
 sky130_fd_sc_hd__a31o_1 _591_ (.A1(_146_),
    .A2(_153_),
    .A3(_167_),
    .B1(_168_),
    .X(_184_));
 sky130_fd_sc_hd__xor2_1 _592_ (.A(_183_),
    .B(_184_),
    .X(_185_));
 sky130_fd_sc_hd__o21ai_1 _593_ (.A1(net85),
    .A2(\B_reg[10] ),
    .B1(_347_),
    .Y(_186_));
 sky130_fd_sc_hd__o221a_1 _594_ (.A1(net85),
    .A2(net59),
    .B1(net57),
    .B2(_181_),
    .C1(_186_),
    .X(_187_));
 sky130_fd_sc_hd__a211o_1 _595_ (.A1(net74),
    .A2(_042_),
    .B1(_044_),
    .C1(_350_),
    .X(_188_));
 sky130_fd_sc_hd__o211ai_1 _596_ (.A1(_341_),
    .A2(_183_),
    .B1(_187_),
    .C1(_188_),
    .Y(_189_));
 sky130_fd_sc_hd__mux4_1 _597_ (.A0(net85),
    .A1(net86),
    .A2(net87),
    .A3(net88),
    .S0(net81),
    .S1(net76),
    .X(_190_));
 sky130_fd_sc_hd__mux2_1 _598_ (.A0(_128_),
    .A1(_190_),
    .S(net68),
    .X(_191_));
 sky130_fd_sc_hd__o22a_1 _599_ (.A1(net60),
    .A2(_055_),
    .B1(_191_),
    .B2(net72),
    .X(_192_));
 sky130_fd_sc_hd__a211o_1 _600_ (.A1(_324_),
    .A2(_185_),
    .B1(_189_),
    .C1(_192_),
    .X(\result_comb[10] ));
 sky130_fd_sc_hd__xnor2_2 _601_ (.A(\B_reg[11] ),
    .B(net62),
    .Y(_193_));
 sky130_fd_sc_hd__nand2_1 _602_ (.A(net84),
    .B(_193_),
    .Y(_194_));
 sky130_fd_sc_hd__nor2_1 _603_ (.A(net84),
    .B(_193_),
    .Y(_195_));
 sky130_fd_sc_hd__xnor2_2 _604_ (.A(net84),
    .B(_193_),
    .Y(_196_));
 sky130_fd_sc_hd__a21o_1 _605_ (.A1(_167_),
    .A2(_181_),
    .B1(_182_),
    .X(_197_));
 sky130_fd_sc_hd__a31o_1 _606_ (.A1(_167_),
    .A2(_169_),
    .A3(_181_),
    .B1(_182_),
    .X(_198_));
 sky130_fd_sc_hd__a31o_1 _607_ (.A1(_146_),
    .A2(_153_),
    .A3(_197_),
    .B1(_198_),
    .X(_199_));
 sky130_fd_sc_hd__xor2_1 _608_ (.A(_196_),
    .B(_199_),
    .X(_200_));
 sky130_fd_sc_hd__o21ai_1 _609_ (.A1(\A_reg[11] ),
    .A2(\B_reg[11] ),
    .B1(_347_),
    .Y(_201_));
 sky130_fd_sc_hd__o221a_1 _610_ (.A1(net84),
    .A2(net59),
    .B1(_065_),
    .B2(_163_),
    .C1(_201_),
    .X(_202_));
 sky130_fd_sc_hd__o21ai_1 _611_ (.A1(net57),
    .A2(_194_),
    .B1(_202_),
    .Y(_203_));
 sky130_fd_sc_hd__mux2_1 _612_ (.A0(net84),
    .A1(net85),
    .S(net83),
    .X(_204_));
 sky130_fd_sc_hd__mux2_1 _613_ (.A0(_175_),
    .A1(_204_),
    .S(net67),
    .X(_205_));
 sky130_fd_sc_hd__mux2_1 _614_ (.A0(_142_),
    .A1(_205_),
    .S(net69),
    .X(_206_));
 sky130_fd_sc_hd__a2bb2o_1 _615_ (.A1_N(net63),
    .A2_N(_196_),
    .B1(_206_),
    .B2(_337_),
    .X(_207_));
 sky130_fd_sc_hd__a211o_1 _616_ (.A1(_349_),
    .A2(_075_),
    .B1(_203_),
    .C1(_207_),
    .X(_208_));
 sky130_fd_sc_hd__a21o_1 _617_ (.A1(_324_),
    .A2(_200_),
    .B1(_208_),
    .X(\result_comb[11] ));
 sky130_fd_sc_hd__xor2_1 _618_ (.A(\B_reg[12] ),
    .B(net62),
    .X(_209_));
 sky130_fd_sc_hd__or2_2 _619_ (.A(_317_),
    .B(_209_),
    .X(_210_));
 sky130_fd_sc_hd__nand2_1 _620_ (.A(_317_),
    .B(_209_),
    .Y(_211_));
 sky130_fd_sc_hd__nand2_1 _621_ (.A(_210_),
    .B(_211_),
    .Y(_212_));
 sky130_fd_sc_hd__or4_1 _622_ (.A(_147_),
    .B(_169_),
    .C(_183_),
    .D(_196_),
    .X(_213_));
 sky130_fd_sc_hd__or4_1 _623_ (.A(_146_),
    .B(_169_),
    .C(_183_),
    .D(_196_),
    .X(_214_));
 sky130_fd_sc_hd__o31a_1 _624_ (.A1(_082_),
    .A2(_151_),
    .A3(_213_),
    .B1(_214_),
    .X(_215_));
 sky130_fd_sc_hd__o211a_1 _625_ (.A1(_195_),
    .A2(_197_),
    .B1(_215_),
    .C1(_194_),
    .X(_216_));
 sky130_fd_sc_hd__or2_1 _626_ (.A(_150_),
    .B(_213_),
    .X(_217_));
 sky130_fd_sc_hd__a211o_1 _627_ (.A1(_085_),
    .A2(_087_),
    .B1(_151_),
    .C1(_213_),
    .X(_218_));
 sky130_fd_sc_hd__a31o_1 _628_ (.A1(_216_),
    .A2(_217_),
    .A3(_218_),
    .B1(_212_),
    .X(_219_));
 sky130_fd_sc_hd__nand4_1 _629_ (.A(_212_),
    .B(_216_),
    .C(_217_),
    .D(_218_),
    .Y(_220_));
 sky130_fd_sc_hd__a21o_1 _630_ (.A1(_219_),
    .A2(_220_),
    .B1(net65),
    .X(_221_));
 sky130_fd_sc_hd__nor2_1 _631_ (.A(net57),
    .B(_210_),
    .Y(_222_));
 sky130_fd_sc_hd__o21ai_1 _632_ (.A1(\A_reg[12] ),
    .A2(\B_reg[12] ),
    .B1(_344_),
    .Y(_223_));
 sky130_fd_sc_hd__o211ai_1 _633_ (.A1(\A_reg[12] ),
    .A2(net59),
    .B1(_223_),
    .C1(net64),
    .Y(_224_));
 sky130_fd_sc_hd__mux4_1 _634_ (.A0(\A_reg[12] ),
    .A1(net84),
    .A2(net85),
    .A3(net86),
    .S0(net83),
    .S1(net75),
    .X(_225_));
 sky130_fd_sc_hd__mux2_1 _635_ (.A0(_156_),
    .A1(_225_),
    .S(net68),
    .X(_226_));
 sky130_fd_sc_hd__a2bb2o_1 _636_ (.A1_N(net63),
    .A2_N(_212_),
    .B1(_162_),
    .B2(_093_),
    .X(_227_));
 sky130_fd_sc_hd__a2111o_1 _637_ (.A1(_330_),
    .A2(_351_),
    .B1(_222_),
    .C1(_224_),
    .D1(_227_),
    .X(_228_));
 sky130_fd_sc_hd__a21o_1 _638_ (.A1(net60),
    .A2(_226_),
    .B1(_228_),
    .X(_229_));
 sky130_fd_sc_hd__and2_1 _639_ (.A(_221_),
    .B(_229_),
    .X(\result_comb[12] ));
 sky130_fd_sc_hd__xor2_1 _640_ (.A(\B_reg[13] ),
    .B(net62),
    .X(_230_));
 sky130_fd_sc_hd__nor2_1 _641_ (.A(_318_),
    .B(_230_),
    .Y(_231_));
 sky130_fd_sc_hd__or2_1 _642_ (.A(_318_),
    .B(_230_),
    .X(_232_));
 sky130_fd_sc_hd__and2_1 _643_ (.A(_318_),
    .B(_230_),
    .X(_233_));
 sky130_fd_sc_hd__nor2_1 _644_ (.A(_231_),
    .B(_233_),
    .Y(_234_));
 sky130_fd_sc_hd__a22o_1 _645_ (.A1(_109_),
    .A2(_162_),
    .B1(_234_),
    .B2(_340_),
    .X(_235_));
 sky130_fd_sc_hd__mux2_1 _646_ (.A0(\A_reg[13] ),
    .A1(\A_reg[12] ),
    .S(net82),
    .X(_236_));
 sky130_fd_sc_hd__mux4_1 _647_ (.A0(_141_),
    .A1(_175_),
    .A2(_204_),
    .A3(_236_),
    .S0(net66),
    .S1(net68),
    .X(_237_));
 sky130_fd_sc_hd__nor2_1 _648_ (.A(net57),
    .B(_232_),
    .Y(_238_));
 sky130_fd_sc_hd__or2_1 _649_ (.A(\A_reg[13] ),
    .B(\B_reg[13] ),
    .X(_239_));
 sky130_fd_sc_hd__a2bb2o_1 _650_ (.A1_N(\A_reg[13] ),
    .A2_N(net59),
    .B1(_347_),
    .B2(_239_),
    .X(_240_));
 sky130_fd_sc_hd__a211o_1 _651_ (.A1(_351_),
    .A2(_029_),
    .B1(_240_),
    .C1(_324_),
    .X(_241_));
 sky130_fd_sc_hd__a211o_1 _652_ (.A1(net60),
    .A2(_237_),
    .B1(_241_),
    .C1(_235_),
    .X(_242_));
 sky130_fd_sc_hd__a21oi_1 _653_ (.A1(_210_),
    .A2(_219_),
    .B1(_234_),
    .Y(_243_));
 sky130_fd_sc_hd__a31o_1 _654_ (.A1(_210_),
    .A2(_219_),
    .A3(_234_),
    .B1(net64),
    .X(_244_));
 sky130_fd_sc_hd__o22a_1 _655_ (.A1(_238_),
    .A2(_242_),
    .B1(_243_),
    .B2(_244_),
    .X(\result_comb[13] ));
 sky130_fd_sc_hd__xor2_1 _656_ (.A(\B_reg[14] ),
    .B(net62),
    .X(_245_));
 sky130_fd_sc_hd__or2_1 _657_ (.A(_319_),
    .B(_245_),
    .X(_246_));
 sky130_fd_sc_hd__nand2_1 _658_ (.A(_319_),
    .B(_245_),
    .Y(_247_));
 sky130_fd_sc_hd__nand2_1 _659_ (.A(_246_),
    .B(_247_),
    .Y(_248_));
 sky130_fd_sc_hd__a31o_1 _660_ (.A1(_210_),
    .A2(_219_),
    .A3(_232_),
    .B1(_233_),
    .X(_249_));
 sky130_fd_sc_hd__xor2_1 _661_ (.A(_248_),
    .B(_249_),
    .X(_250_));
 sky130_fd_sc_hd__o21ai_1 _662_ (.A1(\A_reg[14] ),
    .A2(\B_reg[14] ),
    .B1(_347_),
    .Y(_251_));
 sky130_fd_sc_hd__o32a_1 _663_ (.A1(net74),
    .A2(_350_),
    .A3(_042_),
    .B1(\A_reg[14] ),
    .B2(net59),
    .X(_252_));
 sky130_fd_sc_hd__o211a_1 _664_ (.A1(net57),
    .A2(_246_),
    .B1(_251_),
    .C1(_252_),
    .X(_253_));
 sky130_fd_sc_hd__o21ai_1 _665_ (.A1(net63),
    .A2(_248_),
    .B1(_253_),
    .Y(_254_));
 sky130_fd_sc_hd__mux4_1 _666_ (.A0(\A_reg[14] ),
    .A1(\A_reg[13] ),
    .A2(\A_reg[12] ),
    .A3(net84),
    .S0(net81),
    .S1(net76),
    .X(_255_));
 sky130_fd_sc_hd__mux2_1 _667_ (.A0(_190_),
    .A1(_255_),
    .S(net68),
    .X(_256_));
 sky130_fd_sc_hd__a22o_1 _668_ (.A1(_129_),
    .A2(_162_),
    .B1(_256_),
    .B2(net60),
    .X(_257_));
 sky130_fd_sc_hd__a211o_1 _669_ (.A1(_324_),
    .A2(_250_),
    .B1(_254_),
    .C1(_257_),
    .X(\result_comb[14] ));
 sky130_fd_sc_hd__xor2_1 _670_ (.A(\B_reg[15] ),
    .B(net62),
    .X(_258_));
 sky130_fd_sc_hd__nand2_1 _671_ (.A(_320_),
    .B(_258_),
    .Y(_259_));
 sky130_fd_sc_hd__or2_1 _672_ (.A(_320_),
    .B(_258_),
    .X(_260_));
 sky130_fd_sc_hd__nand2_1 _673_ (.A(_259_),
    .B(_260_),
    .Y(_261_));
 sky130_fd_sc_hd__a2111o_1 _674_ (.A1(_210_),
    .A2(_219_),
    .B1(_231_),
    .C1(_233_),
    .D1(_248_),
    .X(_262_));
 sky130_fd_sc_hd__a21boi_1 _675_ (.A1(_231_),
    .A2(_247_),
    .B1_N(_246_),
    .Y(_263_));
 sky130_fd_sc_hd__and2_1 _676_ (.A(_262_),
    .B(_263_),
    .X(_264_));
 sky130_fd_sc_hd__a21oi_1 _677_ (.A1(_262_),
    .A2(_263_),
    .B1(_261_),
    .Y(_265_));
 sky130_fd_sc_hd__a31o_1 _678_ (.A1(_261_),
    .A2(_262_),
    .A3(_263_),
    .B1(net64),
    .X(_266_));
 sky130_fd_sc_hd__and2_1 _679_ (.A(net78),
    .B(_236_),
    .X(_267_));
 sky130_fd_sc_hd__a31o_1 _680_ (.A1(net81),
    .A2(net66),
    .A3(\A_reg[14] ),
    .B1(net74),
    .X(_268_));
 sky130_fd_sc_hd__o32a_1 _681_ (.A1(_073_),
    .A2(_267_),
    .A3(_268_),
    .B1(_205_),
    .B2(net69),
    .X(_269_));
 sky130_fd_sc_hd__a21o_1 _682_ (.A1(_310_),
    .A2(\opcode_reg[2] ),
    .B1(_347_),
    .X(_270_));
 sky130_fd_sc_hd__a21bo_1 _683_ (.A1(\B_reg[15] ),
    .A2(_270_),
    .B1_N(net59),
    .X(_271_));
 sky130_fd_sc_hd__o21a_1 _684_ (.A1(_333_),
    .A2(_350_),
    .B1(\A_reg[15] ),
    .X(_272_));
 sky130_fd_sc_hd__mux2_1 _685_ (.A0(net63),
    .A1(net57),
    .S(\B_reg[15] ),
    .X(_273_));
 sky130_fd_sc_hd__nand2_1 _686_ (.A(_272_),
    .B(_273_),
    .Y(_274_));
 sky130_fd_sc_hd__o22a_1 _687_ (.A1(\A_reg[15] ),
    .A2(_271_),
    .B1(_274_),
    .B2(_347_),
    .X(_275_));
 sky130_fd_sc_hd__a22o_1 _688_ (.A1(_143_),
    .A2(_162_),
    .B1(_269_),
    .B2(net60),
    .X(_276_));
 sky130_fd_sc_hd__nor2_1 _689_ (.A(_275_),
    .B(_276_),
    .Y(_277_));
 sky130_fd_sc_hd__o21ai_2 _690_ (.A1(_265_),
    .A2(_266_),
    .B1(_277_),
    .Y(\result_comb[15] ));
 sky130_fd_sc_hd__or3_1 _691_ (.A(\result_comb[0] ),
    .B(\result_comb[1] ),
    .C(\result_comb[2] ),
    .X(_278_));
 sky130_fd_sc_hd__or3_1 _692_ (.A(\result_comb[3] ),
    .B(\result_comb[4] ),
    .C(_278_),
    .X(_279_));
 sky130_fd_sc_hd__a2111o_1 _693_ (.A1(_221_),
    .A2(_229_),
    .B1(_279_),
    .C1(\result_comb[8] ),
    .D1(\result_comb[5] ),
    .X(_280_));
 sky130_fd_sc_hd__or4_1 _694_ (.A(\result_comb[6] ),
    .B(\result_comb[9] ),
    .C(\result_comb[13] ),
    .D(_280_),
    .X(_281_));
 sky130_fd_sc_hd__or3_1 _695_ (.A(\result_comb[7] ),
    .B(\result_comb[10] ),
    .C(\result_comb[11] ),
    .X(_282_));
 sky130_fd_sc_hd__nor4_1 _696_ (.A(\result_comb[14] ),
    .B(\result_comb[15] ),
    .C(_281_),
    .D(_282_),
    .Y(_000_));
 sky130_fd_sc_hd__nand2_1 _697_ (.A(_260_),
    .B(_264_),
    .Y(_283_));
 sky130_fd_sc_hd__xnor2_2 _698_ (.A(net81),
    .B(_326_),
    .Y(_284_));
 sky130_fd_sc_hd__nor2_1 _699_ (.A(net76),
    .B(_284_),
    .Y(_285_));
 sky130_fd_sc_hd__o21a_1 _700_ (.A1(\A_reg[0] ),
    .A2(net75),
    .B1(_284_),
    .X(_286_));
 sky130_fd_sc_hd__a221o_1 _701_ (.A1(net75),
    .A2(\A_reg[1] ),
    .B1(net91),
    .B2(_285_),
    .C1(_286_),
    .X(_287_));
 sky130_fd_sc_hd__nand2_1 _702_ (.A(net75),
    .B(_284_),
    .Y(_288_));
 sky130_fd_sc_hd__xnor2_1 _703_ (.A(net74),
    .B(_332_),
    .Y(_289_));
 sky130_fd_sc_hd__xnor2_1 _704_ (.A(_326_),
    .B(_289_),
    .Y(_290_));
 sky130_fd_sc_hd__xor2_1 _705_ (.A(_326_),
    .B(_289_),
    .X(_291_));
 sky130_fd_sc_hd__o211a_1 _706_ (.A1(net92),
    .A2(_288_),
    .B1(_290_),
    .C1(_287_),
    .X(_292_));
 sky130_fd_sc_hd__nand2b_1 _707_ (.A_N(_326_),
    .B(net72),
    .Y(_293_));
 sky130_fd_sc_hd__and3_1 _708_ (.A(_333_),
    .B(_350_),
    .C(_293_),
    .X(_294_));
 sky130_fd_sc_hd__a21oi_1 _709_ (.A1(_350_),
    .A2(_293_),
    .B1(_333_),
    .Y(_295_));
 sky130_fd_sc_hd__or2_1 _710_ (.A(_294_),
    .B(_295_),
    .X(_296_));
 sky130_fd_sc_hd__nor2_1 _711_ (.A(net66),
    .B(_316_),
    .Y(_297_));
 sky130_fd_sc_hd__o22a_1 _712_ (.A1(net75),
    .A2(net90),
    .B1(_284_),
    .B2(_297_),
    .X(_298_));
 sky130_fd_sc_hd__o211a_1 _713_ (.A1(_333_),
    .A2(_350_),
    .B1(_285_),
    .C1(net88),
    .X(_299_));
 sky130_fd_sc_hd__o221a_1 _714_ (.A1(net89),
    .A2(_288_),
    .B1(_298_),
    .B2(_299_),
    .C1(_291_),
    .X(_300_));
 sky130_fd_sc_hd__o22a_1 _715_ (.A1(net76),
    .A2(net87),
    .B1(net86),
    .B2(_284_),
    .X(_301_));
 sky130_fd_sc_hd__mux2_1 _716_ (.A0(_301_),
    .A1(net84),
    .S(_285_),
    .X(_302_));
 sky130_fd_sc_hd__o211a_1 _717_ (.A1(net85),
    .A2(_288_),
    .B1(_290_),
    .C1(_302_),
    .X(_303_));
 sky130_fd_sc_hd__mux4_1 _718_ (.A0(\A_reg[13] ),
    .A1(\A_reg[14] ),
    .A2(_272_),
    .A3(\A_reg[12] ),
    .S0(_284_),
    .S1(net66),
    .X(_304_));
 sky130_fd_sc_hd__a21bo_1 _719_ (.A1(_291_),
    .A2(_304_),
    .B1_N(_296_),
    .X(_305_));
 sky130_fd_sc_hd__o32a_1 _720_ (.A1(_292_),
    .A2(_296_),
    .A3(_300_),
    .B1(_303_),
    .B2(_305_),
    .X(_306_));
 sky130_fd_sc_hd__o2111a_1 _721_ (.A1(net72),
    .A2(_333_),
    .B1(_306_),
    .C1(net70),
    .D1(net71),
    .X(_307_));
 sky130_fd_sc_hd__a31o_1 _722_ (.A1(_324_),
    .A2(_259_),
    .A3(_283_),
    .B1(_307_),
    .X(carry_comb));
 sky130_fd_sc_hd__mux2_1 _723_ (.A0(_259_),
    .A1(_260_),
    .S(_264_),
    .X(_308_));
 sky130_fd_sc_hd__nor2_1 _724_ (.A(net64),
    .B(_308_),
    .Y(_001_));
 sky130_fd_sc_hd__dfxtp_1 _725_ (.CLK(clk),
    .D(_001_),
    .Q(net38));
 sky130_fd_sc_hd__dfxtp_1 _726_ (.CLK(clk),
    .D(carry_comb),
    .Q(net36));
 sky130_fd_sc_hd__dfxtp_1 _727_ (.CLK(clk),
    .D(\result_comb[15] ),
    .Q(net37));
 sky130_fd_sc_hd__dfxtp_1 _728_ (.CLK(clk),
    .D(\result_comb[0] ),
    .Q(net39));
 sky130_fd_sc_hd__dfxtp_1 _729_ (.CLK(clk),
    .D(\result_comb[1] ),
    .Q(net46));
 sky130_fd_sc_hd__dfxtp_1 _730_ (.CLK(clk),
    .D(\result_comb[2] ),
    .Q(net47));
 sky130_fd_sc_hd__dfxtp_1 _731_ (.CLK(clk),
    .D(\result_comb[3] ),
    .Q(net48));
 sky130_fd_sc_hd__dfxtp_1 _732_ (.CLK(clk),
    .D(\result_comb[4] ),
    .Q(net49));
 sky130_fd_sc_hd__dfxtp_1 _733_ (.CLK(clk),
    .D(\result_comb[5] ),
    .Q(net50));
 sky130_fd_sc_hd__dfxtp_1 _734_ (.CLK(clk),
    .D(\result_comb[6] ),
    .Q(net51));
 sky130_fd_sc_hd__dfxtp_1 _735_ (.CLK(clk),
    .D(\result_comb[7] ),
    .Q(net52));
 sky130_fd_sc_hd__dfxtp_1 _736_ (.CLK(clk),
    .D(\result_comb[8] ),
    .Q(net53));
 sky130_fd_sc_hd__dfxtp_1 _737_ (.CLK(clk),
    .D(\result_comb[9] ),
    .Q(net54));
 sky130_fd_sc_hd__dfxtp_1 _738_ (.CLK(clk),
    .D(\result_comb[10] ),
    .Q(net40));
 sky130_fd_sc_hd__dfxtp_1 _739_ (.CLK(clk),
    .D(\result_comb[11] ),
    .Q(net41));
 sky130_fd_sc_hd__dfxtp_1 _740_ (.CLK(clk),
    .D(\result_comb[12] ),
    .Q(net42));
 sky130_fd_sc_hd__dfxtp_1 _741_ (.CLK(clk),
    .D(\result_comb[13] ),
    .Q(net43));
 sky130_fd_sc_hd__dfxtp_1 _742_ (.CLK(clk),
    .D(\result_comb[14] ),
    .Q(net44));
 sky130_fd_sc_hd__dfxtp_1 _743_ (.CLK(clk),
    .D(_000_),
    .Q(net55));
 sky130_fd_sc_hd__dfxtp_2 _744_ (.CLK(clk),
    .D(net1),
    .Q(\A_reg[0] ));
 sky130_fd_sc_hd__dfxtp_4 _745_ (.CLK(clk),
    .D(net8),
    .Q(\A_reg[1] ));
 sky130_fd_sc_hd__dfxtp_1 _746_ (.CLK(clk),
    .D(net9),
    .Q(\A_reg[2] ));
 sky130_fd_sc_hd__dfxtp_1 _747_ (.CLK(clk),
    .D(net10),
    .Q(\A_reg[3] ));
 sky130_fd_sc_hd__dfxtp_1 _748_ (.CLK(clk),
    .D(net11),
    .Q(\A_reg[4] ));
 sky130_fd_sc_hd__dfxtp_2 _749_ (.CLK(clk),
    .D(net12),
    .Q(\A_reg[5] ));
 sky130_fd_sc_hd__dfxtp_1 _750_ (.CLK(clk),
    .D(net13),
    .Q(\A_reg[6] ));
 sky130_fd_sc_hd__dfxtp_1 _751_ (.CLK(clk),
    .D(net14),
    .Q(\A_reg[7] ));
 sky130_fd_sc_hd__dfxtp_1 _752_ (.CLK(clk),
    .D(net15),
    .Q(\A_reg[8] ));
 sky130_fd_sc_hd__dfxtp_1 _753_ (.CLK(clk),
    .D(net16),
    .Q(\A_reg[9] ));
 sky130_fd_sc_hd__dfxtp_2 _754_ (.CLK(clk),
    .D(net2),
    .Q(\A_reg[10] ));
 sky130_fd_sc_hd__dfxtp_1 _755_ (.CLK(clk),
    .D(net3),
    .Q(\A_reg[11] ));
 sky130_fd_sc_hd__dfxtp_2 _756_ (.CLK(clk),
    .D(net4),
    .Q(\A_reg[12] ));
 sky130_fd_sc_hd__dfxtp_2 _757_ (.CLK(clk),
    .D(net5),
    .Q(\A_reg[13] ));
 sky130_fd_sc_hd__dfxtp_2 _758_ (.CLK(clk),
    .D(net6),
    .Q(\A_reg[14] ));
 sky130_fd_sc_hd__dfxtp_1 _759_ (.CLK(clk),
    .D(net7),
    .Q(\A_reg[15] ));
 sky130_fd_sc_hd__dfxtp_1 _760_ (.CLK(clk),
    .D(net17),
    .Q(\B_reg[0] ));
 sky130_fd_sc_hd__dfxtp_1 _761_ (.CLK(clk),
    .D(net24),
    .Q(\B_reg[1] ));
 sky130_fd_sc_hd__dfxtp_1 _762_ (.CLK(clk),
    .D(net25),
    .Q(\B_reg[2] ));
 sky130_fd_sc_hd__dfxtp_1 _763_ (.CLK(clk),
    .D(net26),
    .Q(\B_reg[3] ));
 sky130_fd_sc_hd__dfxtp_1 _764_ (.CLK(clk),
    .D(net27),
    .Q(\B_reg[4] ));
 sky130_fd_sc_hd__dfxtp_1 _765_ (.CLK(clk),
    .D(net28),
    .Q(\B_reg[5] ));
 sky130_fd_sc_hd__dfxtp_1 _766_ (.CLK(clk),
    .D(net29),
    .Q(\B_reg[6] ));
 sky130_fd_sc_hd__dfxtp_1 _767_ (.CLK(clk),
    .D(net30),
    .Q(\B_reg[7] ));
 sky130_fd_sc_hd__dfxtp_1 _768_ (.CLK(clk),
    .D(net31),
    .Q(\B_reg[8] ));
 sky130_fd_sc_hd__dfxtp_1 _769_ (.CLK(clk),
    .D(net32),
    .Q(\B_reg[9] ));
 sky130_fd_sc_hd__dfxtp_1 _770_ (.CLK(clk),
    .D(net18),
    .Q(\B_reg[10] ));
 sky130_fd_sc_hd__dfxtp_1 _771_ (.CLK(clk),
    .D(net19),
    .Q(\B_reg[11] ));
 sky130_fd_sc_hd__dfxtp_1 _772_ (.CLK(clk),
    .D(net20),
    .Q(\B_reg[12] ));
 sky130_fd_sc_hd__dfxtp_1 _773_ (.CLK(clk),
    .D(net21),
    .Q(\B_reg[13] ));
 sky130_fd_sc_hd__dfxtp_1 _774_ (.CLK(clk),
    .D(net22),
    .Q(\B_reg[14] ));
 sky130_fd_sc_hd__dfxtp_1 _775_ (.CLK(clk),
    .D(net23),
    .Q(\B_reg[15] ));
 sky130_fd_sc_hd__dfxtp_2 _776_ (.CLK(clk),
    .D(net33),
    .Q(\opcode_reg[0] ));
 sky130_fd_sc_hd__dfxtp_1 _777_ (.CLK(clk),
    .D(net34),
    .Q(\opcode_reg[1] ));
 sky130_fd_sc_hd__dfxtp_1 _778_ (.CLK(clk),
    .D(net35),
    .Q(\opcode_reg[2] ));
 sky130_fd_sc_hd__clkbuf_1 _779_ (.A(net37),
    .X(net45));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_0_Right_0 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_1_Right_1 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_2_Right_2 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_3_Right_3 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_4_Right_4 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_5_Right_5 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_6_Right_6 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_7_Right_7 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_8_Right_8 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_9_Right_9 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_10_Right_10 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_11_Right_11 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_12_Right_12 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_13_Right_13 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_14_Right_14 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_15_Right_15 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_16_Right_16 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_17_Right_17 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_18_Right_18 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_19_Right_19 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_20_Right_20 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_21_Right_21 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_22_Right_22 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_23_Right_23 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_24_Right_24 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_25_Right_25 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_Right_26 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_Right_27 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_Right_28 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_Right_29 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_Right_30 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_31_Right_31 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_32_Right_32 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_33_Right_33 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_34_Right_34 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_35_Right_35 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_36_Right_36 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_37_Right_37 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_38_Right_38 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_39_Right_39 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_40_Right_40 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_41_Right_41 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_42_Right_42 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_0_Left_43 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_1_Left_44 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_2_Left_45 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_3_Left_46 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_4_Left_47 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_5_Left_48 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_6_Left_49 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_7_Left_50 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_8_Left_51 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_9_Left_52 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_10_Left_53 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_11_Left_54 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_12_Left_55 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_13_Left_56 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_14_Left_57 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_15_Left_58 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_16_Left_59 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_17_Left_60 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_18_Left_61 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_19_Left_62 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_20_Left_63 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_21_Left_64 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_22_Left_65 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_23_Left_66 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_24_Left_67 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_25_Left_68 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_Left_69 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_Left_70 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_Left_71 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_Left_72 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_Left_73 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_31_Left_74 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_32_Left_75 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_33_Left_76 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_34_Left_77 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_35_Left_78 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_36_Left_79 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_37_Left_80 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_38_Left_81 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_39_Left_82 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_40_Left_83 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_41_Left_84 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_42_Left_85 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_86 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_87 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_88 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_89 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_90 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_91 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_92 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_93 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_94 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_95 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_96 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_97 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_98 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_99 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_100 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_101 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_102 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_103 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_104 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_105 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_106 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_107 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_108 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_109 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_110 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_111 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_112 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_113 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_114 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_115 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_116 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_117 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_118 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_119 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_120 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_121 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_122 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_123 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_124 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_125 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_126 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_127 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_128 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_129 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_130 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_131 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_132 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_133 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_134 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_135 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_136 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_137 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_138 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_139 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_140 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_141 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_142 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_143 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_144 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_145 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_146 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_147 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_148 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_149 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_150 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_151 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_152 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_153 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_154 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_155 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_156 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_157 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_158 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_159 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_160 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_161 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_162 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_163 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_164 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_165 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_166 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_167 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_168 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_169 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_170 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_171 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_172 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_173 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_174 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_175 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_176 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_177 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_178 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_179 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_180 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_181 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_182 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_183 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_184 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_185 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_186 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_187 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_188 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_189 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_190 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_191 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_192 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_193 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_194 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_195 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_196 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_197 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_198 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_199 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_200 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_201 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_202 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_203 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_204 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_205 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_206 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_207 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_208 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_209 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_210 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_211 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_212 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_213 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_214 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_215 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_216 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_217 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_218 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_219 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_220 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_221 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_222 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_223 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_224 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_225 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_226 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_227 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_228 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_229 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_230 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_231 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_232 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_233 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_234 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_235 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_236 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_237 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_238 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_239 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_240 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_241 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_242 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_243 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_244 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_245 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_246 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_247 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_248 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_249 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_250 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_251 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_252 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_253 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_254 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_255 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_256 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_257 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_258 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_259 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_260 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_261 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_262 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_263 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_264 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_265 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_266 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_267 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_268 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_269 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_270 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_271 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_272 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_273 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_274 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_41_275 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_41_276 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_41_277 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_41_278 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_42_279 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_42_280 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_42_281 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_42_282 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_42_283 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_42_284 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_42_285 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_42_286 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_42_287 ();
 sky130_fd_sc_hd__clkbuf_1 input1 (.A(A[0]),
    .X(net1));
 sky130_fd_sc_hd__clkbuf_1 input2 (.A(A[10]),
    .X(net2));
 sky130_fd_sc_hd__clkbuf_1 input3 (.A(A[11]),
    .X(net3));
 sky130_fd_sc_hd__clkbuf_1 input4 (.A(A[12]),
    .X(net4));
 sky130_fd_sc_hd__clkbuf_1 input5 (.A(A[13]),
    .X(net5));
 sky130_fd_sc_hd__clkbuf_1 input6 (.A(A[14]),
    .X(net6));
 sky130_fd_sc_hd__clkbuf_1 input7 (.A(A[15]),
    .X(net7));
 sky130_fd_sc_hd__clkbuf_1 input8 (.A(A[1]),
    .X(net8));
 sky130_fd_sc_hd__clkbuf_1 input9 (.A(A[2]),
    .X(net9));
 sky130_fd_sc_hd__clkbuf_1 input10 (.A(A[3]),
    .X(net10));
 sky130_fd_sc_hd__clkbuf_1 input11 (.A(A[4]),
    .X(net11));
 sky130_fd_sc_hd__clkbuf_1 input12 (.A(A[5]),
    .X(net12));
 sky130_fd_sc_hd__clkbuf_1 input13 (.A(A[6]),
    .X(net13));
 sky130_fd_sc_hd__clkbuf_1 input14 (.A(A[7]),
    .X(net14));
 sky130_fd_sc_hd__clkbuf_1 input15 (.A(A[8]),
    .X(net15));
 sky130_fd_sc_hd__clkbuf_1 input16 (.A(A[9]),
    .X(net16));
 sky130_fd_sc_hd__clkbuf_1 input17 (.A(B[0]),
    .X(net17));
 sky130_fd_sc_hd__clkbuf_1 input18 (.A(B[10]),
    .X(net18));
 sky130_fd_sc_hd__clkbuf_1 input19 (.A(B[11]),
    .X(net19));
 sky130_fd_sc_hd__clkbuf_1 input20 (.A(B[12]),
    .X(net20));
 sky130_fd_sc_hd__clkbuf_1 input21 (.A(B[13]),
    .X(net21));
 sky130_fd_sc_hd__clkbuf_1 input22 (.A(B[14]),
    .X(net22));
 sky130_fd_sc_hd__clkbuf_1 input23 (.A(B[15]),
    .X(net23));
 sky130_fd_sc_hd__clkbuf_1 input24 (.A(B[1]),
    .X(net24));
 sky130_fd_sc_hd__clkbuf_1 input25 (.A(B[2]),
    .X(net25));
 sky130_fd_sc_hd__clkbuf_1 input26 (.A(B[3]),
    .X(net26));
 sky130_fd_sc_hd__clkbuf_1 input27 (.A(B[4]),
    .X(net27));
 sky130_fd_sc_hd__clkbuf_1 input28 (.A(B[5]),
    .X(net28));
 sky130_fd_sc_hd__clkbuf_1 input29 (.A(B[6]),
    .X(net29));
 sky130_fd_sc_hd__clkbuf_1 input30 (.A(B[7]),
    .X(net30));
 sky130_fd_sc_hd__clkbuf_1 input31 (.A(B[8]),
    .X(net31));
 sky130_fd_sc_hd__clkbuf_1 input32 (.A(B[9]),
    .X(net32));
 sky130_fd_sc_hd__clkbuf_1 input33 (.A(opcode[0]),
    .X(net33));
 sky130_fd_sc_hd__clkbuf_1 input34 (.A(opcode[1]),
    .X(net34));
 sky130_fd_sc_hd__clkbuf_1 input35 (.A(opcode[2]),
    .X(net35));
 sky130_fd_sc_hd__buf_2 output36 (.A(net36),
    .X(C));
 sky130_fd_sc_hd__buf_2 output37 (.A(net37),
    .X(N));
 sky130_fd_sc_hd__buf_2 output38 (.A(net38),
    .X(V));
 sky130_fd_sc_hd__buf_2 output39 (.A(net39),
    .X(Y[0]));
 sky130_fd_sc_hd__buf_2 output40 (.A(net40),
    .X(Y[10]));
 sky130_fd_sc_hd__buf_2 output41 (.A(net41),
    .X(Y[11]));
 sky130_fd_sc_hd__buf_2 output42 (.A(net42),
    .X(Y[12]));
 sky130_fd_sc_hd__buf_2 output43 (.A(net43),
    .X(Y[13]));
 sky130_fd_sc_hd__buf_2 output44 (.A(net44),
    .X(Y[14]));
 sky130_fd_sc_hd__buf_2 output45 (.A(net45),
    .X(Y[15]));
 sky130_fd_sc_hd__buf_2 output46 (.A(net46),
    .X(Y[1]));
 sky130_fd_sc_hd__buf_2 output47 (.A(net47),
    .X(Y[2]));
 sky130_fd_sc_hd__buf_2 output48 (.A(net48),
    .X(Y[3]));
 sky130_fd_sc_hd__buf_2 output49 (.A(net49),
    .X(Y[4]));
 sky130_fd_sc_hd__buf_2 output50 (.A(net50),
    .X(Y[5]));
 sky130_fd_sc_hd__buf_2 output51 (.A(net51),
    .X(Y[6]));
 sky130_fd_sc_hd__buf_2 output52 (.A(net52),
    .X(Y[7]));
 sky130_fd_sc_hd__buf_2 output53 (.A(net53),
    .X(Y[8]));
 sky130_fd_sc_hd__buf_2 output54 (.A(net54),
    .X(Y[9]));
 sky130_fd_sc_hd__buf_2 output55 (.A(net55),
    .X(Z));
 sky130_fd_sc_hd__clkbuf_4 fanout56 (.A(_343_),
    .X(net56));
 sky130_fd_sc_hd__clkbuf_2 fanout57 (.A(_343_),
    .X(net57));
 sky130_fd_sc_hd__clkbuf_4 fanout58 (.A(_339_),
    .X(net58));
 sky130_fd_sc_hd__clkbuf_2 fanout59 (.A(_339_),
    .X(net59));
 sky130_fd_sc_hd__buf_2 fanout60 (.A(_337_),
    .X(net60));
 sky130_fd_sc_hd__buf_4 fanout61 (.A(net62),
    .X(net61));
 sky130_fd_sc_hd__buf_6 fanout62 (.A(_005_),
    .X(net62));
 sky130_fd_sc_hd__buf_2 fanout63 (.A(_341_),
    .X(net63));
 sky130_fd_sc_hd__clkbuf_4 fanout64 (.A(_325_),
    .X(net64));
 sky130_fd_sc_hd__buf_2 fanout65 (.A(_325_),
    .X(net65));
 sky130_fd_sc_hd__clkbuf_4 fanout66 (.A(net67),
    .X(net66));
 sky130_fd_sc_hd__buf_2 fanout67 (.A(_312_),
    .X(net67));
 sky130_fd_sc_hd__clkbuf_4 fanout68 (.A(net69),
    .X(net68));
 sky130_fd_sc_hd__clkbuf_4 fanout69 (.A(_311_),
    .X(net69));
 sky130_fd_sc_hd__clkbuf_4 fanout70 (.A(\opcode_reg[2] ),
    .X(net70));
 sky130_fd_sc_hd__clkbuf_4 fanout71 (.A(\opcode_reg[1] ),
    .X(net71));
 sky130_fd_sc_hd__clkbuf_4 fanout72 (.A(\B_reg[3] ),
    .X(net72));
 sky130_fd_sc_hd__buf_2 fanout73 (.A(net74),
    .X(net73));
 sky130_fd_sc_hd__clkbuf_4 fanout74 (.A(\B_reg[2] ),
    .X(net74));
 sky130_fd_sc_hd__clkbuf_4 fanout75 (.A(\B_reg[1] ),
    .X(net75));
 sky130_fd_sc_hd__dlymetal6s2s_1 fanout76 (.A(\B_reg[1] ),
    .X(net76));
 sky130_fd_sc_hd__clkbuf_4 fanout77 (.A(\B_reg[1] ),
    .X(net77));
 sky130_fd_sc_hd__buf_2 fanout78 (.A(\B_reg[1] ),
    .X(net78));
 sky130_fd_sc_hd__clkbuf_4 fanout79 (.A(net80),
    .X(net79));
 sky130_fd_sc_hd__clkbuf_2 fanout80 (.A(\B_reg[0] ),
    .X(net80));
 sky130_fd_sc_hd__buf_4 fanout81 (.A(net83),
    .X(net81));
 sky130_fd_sc_hd__clkbuf_4 fanout82 (.A(net83),
    .X(net82));
 sky130_fd_sc_hd__buf_2 fanout83 (.A(\B_reg[0] ),
    .X(net83));
 sky130_fd_sc_hd__clkbuf_4 fanout84 (.A(\A_reg[11] ),
    .X(net84));
 sky130_fd_sc_hd__buf_2 fanout85 (.A(\A_reg[10] ),
    .X(net85));
 sky130_fd_sc_hd__clkbuf_4 fanout86 (.A(\A_reg[9] ),
    .X(net86));
 sky130_fd_sc_hd__clkbuf_4 fanout87 (.A(\A_reg[8] ),
    .X(net87));
 sky130_fd_sc_hd__buf_2 fanout88 (.A(\A_reg[7] ),
    .X(net88));
 sky130_fd_sc_hd__clkbuf_4 fanout89 (.A(\A_reg[6] ),
    .X(net89));
 sky130_fd_sc_hd__buf_2 fanout90 (.A(\A_reg[4] ),
    .X(net90));
 sky130_fd_sc_hd__clkbuf_4 fanout91 (.A(\A_reg[3] ),
    .X(net91));
 sky130_fd_sc_hd__buf_2 fanout92 (.A(\A_reg[2] ),
    .X(net92));
endmodule
