module alu16 (C,
    N,
    V,
    Z,
    clk,
    A,
    B,
    Y,
    opcode);
 output C;
 output N;
 output V;
 output Z;
 input clk;
 input [15:0] A;
 input [15:0] B;
 output [15:0] Y;
 input [2:0] opcode;

 wire \A_reg[0] ;
 wire \A_reg[10] ;
 wire \A_reg[11] ;
 wire \A_reg[12] ;
 wire \A_reg[13] ;
 wire \A_reg[14] ;
 wire \A_reg[15] ;
 wire \A_reg[1] ;
 wire \A_reg[2] ;
 wire \A_reg[3] ;
 wire \A_reg[4] ;
 wire \A_reg[5] ;
 wire \A_reg[6] ;
 wire \A_reg[7] ;
 wire \A_reg[8] ;
 wire \A_reg[9] ;
 wire \B_reg[0] ;
 wire \B_reg[10] ;
 wire \B_reg[11] ;
 wire \B_reg[12] ;
 wire \B_reg[13] ;
 wire \B_reg[14] ;
 wire \B_reg[15] ;
 wire \B_reg[1] ;
 wire \B_reg[2] ;
 wire \B_reg[3] ;
 wire \B_reg[4] ;
 wire \B_reg[5] ;
 wire \B_reg[6] ;
 wire \B_reg[7] ;
 wire \B_reg[8] ;
 wire \B_reg[9] ;
 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _070_;
 wire _071_;
 wire _072_;
 wire _073_;
 wire _074_;
 wire _075_;
 wire _076_;
 wire _077_;
 wire _078_;
 wire _079_;
 wire _080_;
 wire _081_;
 wire _082_;
 wire _083_;
 wire _084_;
 wire _085_;
 wire _086_;
 wire _087_;
 wire _088_;
 wire _089_;
 wire _090_;
 wire _091_;
 wire _092_;
 wire _093_;
 wire _094_;
 wire _095_;
 wire _096_;
 wire _097_;
 wire _098_;
 wire _099_;
 wire _100_;
 wire _101_;
 wire _102_;
 wire _103_;
 wire _104_;
 wire _105_;
 wire _106_;
 wire _107_;
 wire _108_;
 wire _109_;
 wire _110_;
 wire _111_;
 wire _112_;
 wire _113_;
 wire _114_;
 wire _115_;
 wire _116_;
 wire _117_;
 wire _118_;
 wire _119_;
 wire _120_;
 wire _121_;
 wire _122_;
 wire _123_;
 wire _124_;
 wire _125_;
 wire _126_;
 wire _127_;
 wire _128_;
 wire _129_;
 wire _130_;
 wire _131_;
 wire _132_;
 wire _133_;
 wire _134_;
 wire _135_;
 wire _136_;
 wire _137_;
 wire _138_;
 wire _139_;
 wire _140_;
 wire _141_;
 wire _142_;
 wire _143_;
 wire _144_;
 wire _145_;
 wire _146_;
 wire _147_;
 wire _148_;
 wire _149_;
 wire _150_;
 wire _151_;
 wire _152_;
 wire _153_;
 wire _154_;
 wire _155_;
 wire _156_;
 wire _157_;
 wire _158_;
 wire _159_;
 wire _160_;
 wire _161_;
 wire _162_;
 wire _163_;
 wire _164_;
 wire _165_;
 wire _166_;
 wire _167_;
 wire _168_;
 wire _169_;
 wire _170_;
 wire _171_;
 wire _172_;
 wire _173_;
 wire _174_;
 wire _175_;
 wire _176_;
 wire _177_;
 wire _178_;
 wire _179_;
 wire _180_;
 wire _181_;
 wire _182_;
 wire _183_;
 wire _184_;
 wire _185_;
 wire _186_;
 wire _187_;
 wire _188_;
 wire _189_;
 wire _190_;
 wire _191_;
 wire _192_;
 wire _193_;
 wire _194_;
 wire _195_;
 wire _196_;
 wire _197_;
 wire _198_;
 wire _199_;
 wire _200_;
 wire _201_;
 wire _202_;
 wire _203_;
 wire _204_;
 wire _205_;
 wire _206_;
 wire _207_;
 wire _208_;
 wire _209_;
 wire _210_;
 wire _211_;
 wire _212_;
 wire _213_;
 wire _214_;
 wire _215_;
 wire _216_;
 wire _217_;
 wire _218_;
 wire _219_;
 wire _220_;
 wire _221_;
 wire _222_;
 wire _223_;
 wire _224_;
 wire _225_;
 wire _226_;
 wire _227_;
 wire _228_;
 wire _229_;
 wire _230_;
 wire _231_;
 wire _232_;
 wire _233_;
 wire _234_;
 wire _235_;
 wire _236_;
 wire _237_;
 wire _238_;
 wire _239_;
 wire _240_;
 wire _241_;
 wire _242_;
 wire _243_;
 wire _244_;
 wire _245_;
 wire _246_;
 wire _247_;
 wire _248_;
 wire _249_;
 wire _250_;
 wire _251_;
 wire _252_;
 wire _253_;
 wire _254_;
 wire _255_;
 wire _256_;
 wire _257_;
 wire _258_;
 wire _259_;
 wire _260_;
 wire _261_;
 wire _262_;
 wire _263_;
 wire _264_;
 wire _265_;
 wire _266_;
 wire _267_;
 wire _268_;
 wire _269_;
 wire _270_;
 wire _271_;
 wire _272_;
 wire _273_;
 wire _274_;
 wire _275_;
 wire _276_;
 wire _277_;
 wire _278_;
 wire _279_;
 wire _280_;
 wire _281_;
 wire _282_;
 wire _283_;
 wire _284_;
 wire _285_;
 wire _286_;
 wire _287_;
 wire _288_;
 wire _289_;
 wire _290_;
 wire _291_;
 wire _292_;
 wire _293_;
 wire _294_;
 wire _295_;
 wire _296_;
 wire _297_;
 wire _298_;
 wire _299_;
 wire _300_;
 wire _301_;
 wire _302_;
 wire _303_;
 wire _304_;
 wire _305_;
 wire _306_;
 wire _307_;
 wire _308_;
 wire _309_;
 wire _310_;
 wire _311_;
 wire _312_;
 wire _313_;
 wire _314_;
 wire _315_;
 wire _316_;
 wire _317_;
 wire _318_;
 wire _319_;
 wire _320_;
 wire _321_;
 wire _322_;
 wire _323_;
 wire _324_;
 wire _325_;
 wire _326_;
 wire _327_;
 wire _328_;
 wire _329_;
 wire _330_;
 wire _331_;
 wire _332_;
 wire _333_;
 wire _334_;
 wire _335_;
 wire _336_;
 wire _337_;
 wire _338_;
 wire _339_;
 wire _340_;
 wire _341_;
 wire _342_;
 wire _343_;
 wire _344_;
 wire _345_;
 wire _346_;
 wire _347_;
 wire _348_;
 wire _349_;
 wire _350_;
 wire _351_;
 wire _352_;
 wire _353_;
 wire carry_comb;
 wire \opcode_reg[0] ;
 wire \opcode_reg[1] ;
 wire \opcode_reg[2] ;
 wire \result_comb[0] ;
 wire \result_comb[10] ;
 wire \result_comb[11] ;
 wire \result_comb[12] ;
 wire \result_comb[13] ;
 wire \result_comb[14] ;
 wire \result_comb[15] ;
 wire \result_comb[1] ;
 wire \result_comb[2] ;
 wire \result_comb[3] ;
 wire \result_comb[4] ;
 wire \result_comb[5] ;
 wire \result_comb[6] ;
 wire \result_comb[7] ;
 wire \result_comb[8] ;
 wire \result_comb[9] ;
 wire VPWR;
 wire VGND;

 sky130_fd_sc_hd__inv_2 _354_ (.A(\opcode_reg[0] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_309_));
 sky130_fd_sc_hd__inv_2 _355_ (.A(\opcode_reg[1] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_310_));
 sky130_fd_sc_hd__inv_2 _356_ (.A(\B_reg[2] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_311_));
 sky130_fd_sc_hd__inv_2 _357_ (.A(\B_reg[1] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_312_));
 sky130_fd_sc_hd__inv_2 _358_ (.A(\A_reg[1] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_313_));
 sky130_fd_sc_hd__inv_2 _359_ (.A(\A_reg[2] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_314_));
 sky130_fd_sc_hd__inv_2 _360_ (.A(\A_reg[4] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_315_));
 sky130_fd_sc_hd__inv_2 _361_ (.A(\A_reg[5] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_316_));
 sky130_fd_sc_hd__inv_2 _362_ (.A(\A_reg[12] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_317_));
 sky130_fd_sc_hd__inv_2 _363_ (.A(\A_reg[13] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_318_));
 sky130_fd_sc_hd__inv_2 _364_ (.A(\A_reg[14] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_319_));
 sky130_fd_sc_hd__inv_2 _365_ (.A(\A_reg[15] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_320_));
 sky130_fd_sc_hd__nor2_2 _366_ (.A(\A_reg[0] ),
    .B(\B_reg[0] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_321_));
 sky130_fd_sc_hd__nand2_2 _367_ (.A(\A_reg[0] ),
    .B(\B_reg[0] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_322_));
 sky130_fd_sc_hd__and2b_2 _368_ (.A_N(_321_),
    .B(_322_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_323_));
 sky130_fd_sc_hd__nor2_2 _369_ (.A(\opcode_reg[1] ),
    .B(\opcode_reg[2] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_324_));
 sky130_fd_sc_hd__or2_2 _370_ (.A(\opcode_reg[1] ),
    .B(\opcode_reg[2] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_325_));
 sky130_fd_sc_hd__and3_2 _371_ (.A(\opcode_reg[0] ),
    .B(\opcode_reg[1] ),
    .C(\opcode_reg[2] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_326_));
 sky130_fd_sc_hd__nand2_2 _372_ (.A(\B_reg[3] ),
    .B(_326_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_327_));
 sky130_fd_sc_hd__mux4_2 _373_ (.A0(\A_reg[8] ),
    .A1(\A_reg[9] ),
    .A2(\A_reg[10] ),
    .A3(\A_reg[11] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_328_));
 sky130_fd_sc_hd__mux2_1 _374_ (.A0(\A_reg[14] ),
    .A1(\A_reg[15] ),
    .S(\B_reg[0] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_329_));
 sky130_fd_sc_hd__mux4_2 _375_ (.A0(\A_reg[12] ),
    .A1(\A_reg[13] ),
    .A2(\A_reg[14] ),
    .A3(\A_reg[15] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_330_));
 sky130_fd_sc_hd__mux2_1 _376_ (.A0(_328_),
    .A1(_330_),
    .S(\B_reg[2] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_331_));
 sky130_fd_sc_hd__nor2_2 _377_ (.A(\B_reg[0] ),
    .B(\B_reg[1] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_332_));
 sky130_fd_sc_hd__nand2_2 _378_ (.A(_311_),
    .B(_332_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_333_));
 sky130_fd_sc_hd__and2b_2 _379_ (.A_N(\B_reg[0] ),
    .B(\A_reg[0] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_334_));
 sky130_fd_sc_hd__or3b_2 _380_ (.A(\B_reg[2] ),
    .B(\B_reg[1] ),
    .C_N(_334_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_335_));
 sky130_fd_sc_hd__and3b_2 _381_ (.A_N(\opcode_reg[0] ),
    .B(\opcode_reg[1] ),
    .C(\opcode_reg[2] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_336_));
 sky130_fd_sc_hd__and2b_2 _382_ (.A_N(\B_reg[3] ),
    .B(_336_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_337_));
 sky130_fd_sc_hd__nand2b_2 _383_ (.A_N(\B_reg[3] ),
    .B(_336_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_338_));
 sky130_fd_sc_hd__or3b_2 _384_ (.A(_309_),
    .B(\opcode_reg[1] ),
    .C_N(\opcode_reg[2] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_339_));
 sky130_fd_sc_hd__and3_2 _385_ (.A(_309_),
    .B(_310_),
    .C(\opcode_reg[2] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_340_));
 sky130_fd_sc_hd__or3b_2 _386_ (.A(\opcode_reg[0] ),
    .B(\opcode_reg[1] ),
    .C_N(\opcode_reg[2] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_341_));
 sky130_fd_sc_hd__nand2_2 _387_ (.A(_323_),
    .B(_340_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_342_));
 sky130_fd_sc_hd__or3_2 _388_ (.A(\opcode_reg[0] ),
    .B(_310_),
    .C(\opcode_reg[2] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_343_));
 sky130_fd_sc_hd__and2b_2 _389_ (.A_N(\opcode_reg[2] ),
    .B(\opcode_reg[0] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_344_));
 sky130_fd_sc_hd__o31a_2 _390_ (.A1(_309_),
    .A2(\opcode_reg[2] ),
    .A3(_321_),
    .B1(_325_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_345_));
 sky130_fd_sc_hd__o221a_2 _391_ (.A1(\A_reg[0] ),
    .A2(_339_),
    .B1(_343_),
    .B2(_322_),
    .C1(_342_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_346_));
 sky130_fd_sc_hd__and2_2 _392_ (.A(\opcode_reg[1] ),
    .B(_344_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_347_));
 sky130_fd_sc_hd__o211ai_2 _393_ (.A1(_335_),
    .A2(_338_),
    .B1(_345_),
    .C1(_346_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_348_));
 sky130_fd_sc_hd__and2b_2 _394_ (.A_N(\B_reg[3] ),
    .B(_326_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_349_));
 sky130_fd_sc_hd__nand4b_2 _395_ (.A_N(\B_reg[3] ),
    .B(\opcode_reg[2] ),
    .C(\opcode_reg[1] ),
    .D(\opcode_reg[0] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_350_));
 sky130_fd_sc_hd__nor2_2 _396_ (.A(\B_reg[2] ),
    .B(_350_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_351_));
 sky130_fd_sc_hd__mux4_2 _397_ (.A0(\A_reg[0] ),
    .A1(\A_reg[1] ),
    .A2(\A_reg[2] ),
    .A3(\A_reg[3] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_352_));
 sky130_fd_sc_hd__mux4_2 _398_ (.A0(\A_reg[4] ),
    .A1(\A_reg[5] ),
    .A2(\A_reg[6] ),
    .A3(\A_reg[7] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_353_));
 sky130_fd_sc_hd__nor2_2 _399_ (.A(_311_),
    .B(_350_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_002_));
 sky130_fd_sc_hd__a22o_2 _400_ (.A1(_351_),
    .A2(_352_),
    .B1(_353_),
    .B2(_002_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_003_));
 sky130_fd_sc_hd__a31o_2 _401_ (.A1(\B_reg[3] ),
    .A2(_326_),
    .A3(_331_),
    .B1(_003_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_004_));
 sky130_fd_sc_hd__o22a_2 _402_ (.A1(_323_),
    .A2(_325_),
    .B1(_348_),
    .B2(_004_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(\result_comb[0] ));
 sky130_fd_sc_hd__or3b_2 _403_ (.A(\opcode_reg[1] ),
    .B(\opcode_reg[2] ),
    .C_N(\opcode_reg[0] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_005_));
 sky130_fd_sc_hd__xnor2_2 _404_ (.A(_312_),
    .B(_005_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_006_));
 sky130_fd_sc_hd__or2_2 _405_ (.A(_313_),
    .B(_006_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_007_));
 sky130_fd_sc_hd__xnor2_2 _406_ (.A(\A_reg[1] ),
    .B(_006_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_008_));
 sky130_fd_sc_hd__xnor2_2 _407_ (.A(_313_),
    .B(_006_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_009_));
 sky130_fd_sc_hd__o21ai_2 _408_ (.A1(\B_reg[0] ),
    .A2(_005_),
    .B1(_322_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_010_));
 sky130_fd_sc_hd__xnor2_2 _409_ (.A(_008_),
    .B(_010_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_011_));
 sky130_fd_sc_hd__mux4_2 _410_ (.A0(\A_reg[1] ),
    .A1(\A_reg[2] ),
    .A2(\A_reg[3] ),
    .A3(\A_reg[4] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_012_));
 sky130_fd_sc_hd__mux4_2 _411_ (.A0(\A_reg[5] ),
    .A1(\A_reg[6] ),
    .A2(\A_reg[7] ),
    .A3(\A_reg[8] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_013_));
 sky130_fd_sc_hd__a22o_2 _412_ (.A1(_351_),
    .A2(_012_),
    .B1(_013_),
    .B2(_002_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_014_));
 sky130_fd_sc_hd__mux2_1 _413_ (.A0(\A_reg[1] ),
    .A1(\A_reg[0] ),
    .S(\B_reg[0] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_015_));
 sky130_fd_sc_hd__and2_2 _414_ (.A(_312_),
    .B(_015_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_016_));
 sky130_fd_sc_hd__or3b_2 _415_ (.A(\B_reg[2] ),
    .B(_338_),
    .C_N(_016_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_017_));
 sky130_fd_sc_hd__o21ai_2 _416_ (.A1(\B_reg[1] ),
    .A2(\A_reg[1] ),
    .B1(_344_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_018_));
 sky130_fd_sc_hd__o211a_2 _417_ (.A1(\A_reg[1] ),
    .A2(_339_),
    .B1(_018_),
    .C1(_325_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_019_));
 sky130_fd_sc_hd__mux2_1 _418_ (.A0(\A_reg[9] ),
    .A1(\A_reg[10] ),
    .S(\B_reg[0] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_020_));
 sky130_fd_sc_hd__inv_2 _419_ (.A(_020_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_021_));
 sky130_fd_sc_hd__mux2_1 _420_ (.A0(\A_reg[11] ),
    .A1(\A_reg[12] ),
    .S(\B_reg[0] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_022_));
 sky130_fd_sc_hd__inv_2 _421_ (.A(_022_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_023_));
 sky130_fd_sc_hd__mux2_1 _422_ (.A0(_020_),
    .A1(_022_),
    .S(\B_reg[1] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_024_));
 sky130_fd_sc_hd__mux2_1 _423_ (.A0(\A_reg[13] ),
    .A1(\A_reg[14] ),
    .S(\B_reg[0] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_025_));
 sky130_fd_sc_hd__inv_2 _424_ (.A(_025_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_026_));
 sky130_fd_sc_hd__nand2_2 _425_ (.A(_312_),
    .B(_025_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_027_));
 sky130_fd_sc_hd__or2_2 _426_ (.A(\B_reg[0] ),
    .B(_320_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_028_));
 sky130_fd_sc_hd__o21ai_2 _427_ (.A1(_312_),
    .A2(_028_),
    .B1(_027_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_029_));
 sky130_fd_sc_hd__mux4_2 _428_ (.A0(_021_),
    .A1(_023_),
    .A2(_026_),
    .A3(_028_),
    .S0(\B_reg[1] ),
    .S1(\B_reg[2] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_030_));
 sky130_fd_sc_hd__o211a_2 _429_ (.A1(_327_),
    .A2(_030_),
    .B1(_019_),
    .C1(_017_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_031_));
 sky130_fd_sc_hd__a21oi_2 _430_ (.A1(_340_),
    .A2(_008_),
    .B1(_014_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_032_));
 sky130_fd_sc_hd__o211a_2 _431_ (.A1(_343_),
    .A2(_007_),
    .B1(_031_),
    .C1(_032_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_033_));
 sky130_fd_sc_hd__a21oi_2 _432_ (.A1(_324_),
    .A2(_011_),
    .B1(_033_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(\result_comb[1] ));
 sky130_fd_sc_hd__and2_2 _433_ (.A(\B_reg[2] ),
    .B(_005_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_034_));
 sky130_fd_sc_hd__nor2_2 _434_ (.A(\B_reg[2] ),
    .B(_005_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_035_));
 sky130_fd_sc_hd__xnor2_2 _435_ (.A(_311_),
    .B(_005_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_036_));
 sky130_fd_sc_hd__nor2_2 _436_ (.A(_314_),
    .B(_036_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_037_));
 sky130_fd_sc_hd__nand2_2 _437_ (.A(_314_),
    .B(_036_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_038_));
 sky130_fd_sc_hd__xnor2_2 _438_ (.A(_314_),
    .B(_036_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_039_));
 sky130_fd_sc_hd__a21bo_2 _439_ (.A1(_008_),
    .A2(_010_),
    .B1_N(_007_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_040_));
 sky130_fd_sc_hd__xnor2_2 _440_ (.A(_039_),
    .B(_040_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_041_));
 sky130_fd_sc_hd__nand2_2 _441_ (.A(_312_),
    .B(_329_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_042_));
 sky130_fd_sc_hd__mux4_2 _442_ (.A0(\A_reg[10] ),
    .A1(\A_reg[11] ),
    .A2(\A_reg[12] ),
    .A3(\A_reg[13] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_043_));
 sky130_fd_sc_hd__nor2_2 _443_ (.A(\B_reg[2] ),
    .B(_043_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_044_));
 sky130_fd_sc_hd__a211o_2 _444_ (.A1(\B_reg[2] ),
    .A2(_042_),
    .B1(_044_),
    .C1(_327_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_045_));
 sky130_fd_sc_hd__o21ai_2 _445_ (.A1(_341_),
    .A2(_039_),
    .B1(_045_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_046_));
 sky130_fd_sc_hd__mux4_2 _446_ (.A0(\A_reg[2] ),
    .A1(\A_reg[3] ),
    .A2(\A_reg[4] ),
    .A3(\A_reg[5] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_047_));
 sky130_fd_sc_hd__o21ai_2 _447_ (.A1(\B_reg[2] ),
    .A2(\A_reg[2] ),
    .B1(_344_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_048_));
 sky130_fd_sc_hd__o211ai_2 _448_ (.A1(\A_reg[2] ),
    .A2(_339_),
    .B1(_048_),
    .C1(_325_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_049_));
 sky130_fd_sc_hd__mux4_2 _449_ (.A0(\A_reg[6] ),
    .A1(\A_reg[7] ),
    .A2(\A_reg[8] ),
    .A3(\A_reg[9] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_050_));
 sky130_fd_sc_hd__a221o_2 _450_ (.A1(_351_),
    .A2(_047_),
    .B1(_050_),
    .B2(_002_),
    .C1(_049_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_051_));
 sky130_fd_sc_hd__or3_2 _451_ (.A(_314_),
    .B(_343_),
    .C(_036_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_052_));
 sky130_fd_sc_hd__mux2_1 _452_ (.A0(\A_reg[2] ),
    .A1(\A_reg[1] ),
    .S(\B_reg[0] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_053_));
 sky130_fd_sc_hd__mux2_1 _453_ (.A0(_334_),
    .A1(_053_),
    .S(_312_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_054_));
 sky130_fd_sc_hd__and3_2 _454_ (.A(_311_),
    .B(_336_),
    .C(_054_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_055_));
 sky130_fd_sc_hd__and3_2 _455_ (.A(_311_),
    .B(_337_),
    .C(_054_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_056_));
 sky130_fd_sc_hd__or4b_2 _456_ (.A(_046_),
    .B(_056_),
    .C(_051_),
    .D_N(_052_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_057_));
 sky130_fd_sc_hd__o21a_2 _457_ (.A1(_325_),
    .A2(_041_),
    .B1(_057_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(\result_comb[2] ));
 sky130_fd_sc_hd__xnor2_2 _458_ (.A(\B_reg[3] ),
    .B(_005_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_058_));
 sky130_fd_sc_hd__nand2_2 _459_ (.A(\A_reg[3] ),
    .B(_058_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_059_));
 sky130_fd_sc_hd__xnor2_2 _460_ (.A(\A_reg[3] ),
    .B(_058_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_060_));
 sky130_fd_sc_hd__a21o_2 _461_ (.A1(_038_),
    .A2(_040_),
    .B1(_037_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_061_));
 sky130_fd_sc_hd__xnor2_2 _462_ (.A(_060_),
    .B(_061_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_062_));
 sky130_fd_sc_hd__mux2_1 _463_ (.A0(\A_reg[3] ),
    .A1(\A_reg[2] ),
    .S(\B_reg[0] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_063_));
 sky130_fd_sc_hd__mux2_1 _464_ (.A0(_015_),
    .A1(_063_),
    .S(_312_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_064_));
 sky130_fd_sc_hd__nand2_2 _465_ (.A(_311_),
    .B(_064_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_065_));
 sky130_fd_sc_hd__o21ai_2 _466_ (.A1(\B_reg[3] ),
    .A2(\A_reg[3] ),
    .B1(_347_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_066_));
 sky130_fd_sc_hd__o221a_2 _467_ (.A1(\A_reg[3] ),
    .A2(_339_),
    .B1(_065_),
    .B2(_338_),
    .C1(_066_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_067_));
 sky130_fd_sc_hd__o21ai_2 _468_ (.A1(_343_),
    .A2(_059_),
    .B1(_067_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_068_));
 sky130_fd_sc_hd__nor2_2 _469_ (.A(_341_),
    .B(_060_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_069_));
 sky130_fd_sc_hd__mux4_2 _470_ (.A0(\A_reg[7] ),
    .A1(\A_reg[8] ),
    .A2(\A_reg[9] ),
    .A3(\A_reg[10] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_070_));
 sky130_fd_sc_hd__mux4_2 _471_ (.A0(\A_reg[3] ),
    .A1(\A_reg[4] ),
    .A2(\A_reg[5] ),
    .A3(\A_reg[6] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_071_));
 sky130_fd_sc_hd__mux2_1 _472_ (.A0(_070_),
    .A1(_071_),
    .S(_311_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_072_));
 sky130_fd_sc_hd__nor2_2 _473_ (.A(\B_reg[1] ),
    .B(_028_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_073_));
 sky130_fd_sc_hd__mux2_1 _474_ (.A0(_022_),
    .A1(_025_),
    .S(\B_reg[1] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_074_));
 sky130_fd_sc_hd__mux2_1 _475_ (.A0(_073_),
    .A1(_074_),
    .S(_311_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_075_));
 sky130_fd_sc_hd__a31o_2 _476_ (.A1(\B_reg[3] ),
    .A2(_326_),
    .A3(_075_),
    .B1(_069_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_076_));
 sky130_fd_sc_hd__a21o_2 _477_ (.A1(_349_),
    .A2(_072_),
    .B1(_076_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_077_));
 sky130_fd_sc_hd__a211o_2 _478_ (.A1(_324_),
    .A2(_062_),
    .B1(_068_),
    .C1(_077_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(\result_comb[3] ));
 sky130_fd_sc_hd__xor2_2 _479_ (.A(\B_reg[4] ),
    .B(_005_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_078_));
 sky130_fd_sc_hd__or2_2 _480_ (.A(_315_),
    .B(_078_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_079_));
 sky130_fd_sc_hd__xnor2_2 _481_ (.A(_315_),
    .B(_078_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_080_));
 sky130_fd_sc_hd__or2_2 _482_ (.A(_323_),
    .B(_005_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_081_));
 sky130_fd_sc_hd__or4_2 _483_ (.A(_009_),
    .B(_039_),
    .C(_060_),
    .D(_081_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_082_));
 sky130_fd_sc_hd__xnor2_2 _484_ (.A(\B_reg[0] ),
    .B(_005_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_083_));
 sky130_fd_sc_hd__nand2_2 _485_ (.A(\A_reg[0] ),
    .B(_083_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_084_));
 sky130_fd_sc_hd__or4_2 _486_ (.A(_009_),
    .B(_039_),
    .C(_060_),
    .D(_084_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_085_));
 sky130_fd_sc_hd__o221ai_2 _487_ (.A1(_034_),
    .A2(_035_),
    .B1(_058_),
    .B2(\A_reg[3] ),
    .C1(\A_reg[2] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_086_));
 sky130_fd_sc_hd__o311a_2 _488_ (.A1(_007_),
    .A2(_039_),
    .A3(_060_),
    .B1(_086_),
    .C1(_059_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_087_));
 sky130_fd_sc_hd__and3_2 _489_ (.A(_082_),
    .B(_085_),
    .C(_087_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_088_));
 sky130_fd_sc_hd__a31o_2 _490_ (.A1(_082_),
    .A2(_085_),
    .A3(_087_),
    .B1(_080_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_089_));
 sky130_fd_sc_hd__xor2_2 _491_ (.A(_080_),
    .B(_088_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_090_));
 sky130_fd_sc_hd__and3_2 _492_ (.A(\A_reg[0] ),
    .B(\B_reg[2] ),
    .C(_332_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_091_));
 sky130_fd_sc_hd__mux4_2 _493_ (.A0(\A_reg[4] ),
    .A1(\A_reg[3] ),
    .A2(\A_reg[2] ),
    .A3(\A_reg[1] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_092_));
 sky130_fd_sc_hd__a21o_2 _494_ (.A1(_311_),
    .A2(_092_),
    .B1(_091_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_093_));
 sky130_fd_sc_hd__a2bb2o_2 _495_ (.A1_N(_341_),
    .A2_N(_080_),
    .B1(_093_),
    .B2(_337_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_094_));
 sky130_fd_sc_hd__nor2_2 _496_ (.A(_343_),
    .B(_079_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_095_));
 sky130_fd_sc_hd__nor2_2 _497_ (.A(\B_reg[2] ),
    .B(_327_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_096_));
 sky130_fd_sc_hd__o21ai_2 _498_ (.A1(\A_reg[4] ),
    .A2(\B_reg[4] ),
    .B1(_344_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_097_));
 sky130_fd_sc_hd__o211ai_2 _499_ (.A1(\A_reg[4] ),
    .A2(_339_),
    .B1(_097_),
    .C1(_325_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_098_));
 sky130_fd_sc_hd__a221o_2 _500_ (.A1(_351_),
    .A2(_353_),
    .B1(_002_),
    .B2(_328_),
    .C1(_098_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_099_));
 sky130_fd_sc_hd__a211o_2 _501_ (.A1(_330_),
    .A2(_096_),
    .B1(_099_),
    .C1(_095_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_100_));
 sky130_fd_sc_hd__o22a_2 _502_ (.A1(_325_),
    .A2(_090_),
    .B1(_094_),
    .B2(_100_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(\result_comb[4] ));
 sky130_fd_sc_hd__xor2_2 _503_ (.A(\B_reg[5] ),
    .B(_005_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_101_));
 sky130_fd_sc_hd__or2_2 _504_ (.A(_316_),
    .B(_101_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_102_));
 sky130_fd_sc_hd__xnor2_2 _505_ (.A(_316_),
    .B(_101_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_103_));
 sky130_fd_sc_hd__a21o_2 _506_ (.A1(_079_),
    .A2(_089_),
    .B1(_103_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_104_));
 sky130_fd_sc_hd__nand3_2 _507_ (.A(_079_),
    .B(_089_),
    .C(_103_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_105_));
 sky130_fd_sc_hd__a21oi_2 _508_ (.A1(_104_),
    .A2(_105_),
    .B1(_325_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_106_));
 sky130_fd_sc_hd__mux2_1 _509_ (.A0(\A_reg[5] ),
    .A1(\A_reg[4] ),
    .S(\B_reg[0] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_107_));
 sky130_fd_sc_hd__mux2_1 _510_ (.A0(_063_),
    .A1(_107_),
    .S(_312_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_108_));
 sky130_fd_sc_hd__mux2_1 _511_ (.A0(_016_),
    .A1(_108_),
    .S(_311_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_109_));
 sky130_fd_sc_hd__a2bb2o_2 _512_ (.A1_N(_341_),
    .A2_N(_103_),
    .B1(_109_),
    .B2(_337_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_110_));
 sky130_fd_sc_hd__nor2_2 _513_ (.A(_343_),
    .B(_102_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_111_));
 sky130_fd_sc_hd__o21ai_2 _514_ (.A1(\A_reg[5] ),
    .A2(\B_reg[5] ),
    .B1(_344_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_112_));
 sky130_fd_sc_hd__o211ai_2 _515_ (.A1(\A_reg[5] ),
    .A2(_339_),
    .B1(_112_),
    .C1(_325_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_113_));
 sky130_fd_sc_hd__a221o_2 _516_ (.A1(_351_),
    .A2(_013_),
    .B1(_024_),
    .B2(_002_),
    .C1(_110_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_114_));
 sky130_fd_sc_hd__a211o_2 _517_ (.A1(_029_),
    .A2(_096_),
    .B1(_113_),
    .C1(_114_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_115_));
 sky130_fd_sc_hd__o21ba_2 _518_ (.A1(_111_),
    .A2(_115_),
    .B1_N(_106_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(\result_comb[5] ));
 sky130_fd_sc_hd__xnor2_2 _519_ (.A(\B_reg[6] ),
    .B(_005_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_116_));
 sky130_fd_sc_hd__nand2_2 _520_ (.A(\A_reg[6] ),
    .B(_116_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_117_));
 sky130_fd_sc_hd__nor2_2 _521_ (.A(\A_reg[6] ),
    .B(_116_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_118_));
 sky130_fd_sc_hd__xnor2_2 _522_ (.A(\A_reg[6] ),
    .B(_116_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_119_));
 sky130_fd_sc_hd__a21oi_2 _523_ (.A1(_102_),
    .A2(_104_),
    .B1(_119_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_120_));
 sky130_fd_sc_hd__a31o_2 _524_ (.A1(_102_),
    .A2(_104_),
    .A3(_119_),
    .B1(_325_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_121_));
 sky130_fd_sc_hd__nor2_2 _525_ (.A(_120_),
    .B(_121_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_122_));
 sky130_fd_sc_hd__nor2_2 _526_ (.A(_343_),
    .B(_117_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_123_));
 sky130_fd_sc_hd__o21ai_2 _527_ (.A1(\A_reg[6] ),
    .A2(\B_reg[6] ),
    .B1(_347_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_124_));
 sky130_fd_sc_hd__o32a_2 _528_ (.A1(\B_reg[2] ),
    .A2(_327_),
    .A3(_042_),
    .B1(_339_),
    .B2(\A_reg[6] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_125_));
 sky130_fd_sc_hd__nand2_2 _529_ (.A(_124_),
    .B(_125_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_126_));
 sky130_fd_sc_hd__a221o_2 _530_ (.A1(_002_),
    .A2(_043_),
    .B1(_050_),
    .B2(_351_),
    .C1(_126_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_127_));
 sky130_fd_sc_hd__mux4_2 _531_ (.A0(\A_reg[6] ),
    .A1(\A_reg[5] ),
    .A2(\A_reg[4] ),
    .A3(\A_reg[3] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_128_));
 sky130_fd_sc_hd__mux2_1 _532_ (.A0(_054_),
    .A1(_128_),
    .S(_311_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_129_));
 sky130_fd_sc_hd__a2bb2o_2 _533_ (.A1_N(_341_),
    .A2_N(_119_),
    .B1(_129_),
    .B2(_337_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_130_));
 sky130_fd_sc_hd__or4_2 _534_ (.A(_122_),
    .B(_123_),
    .C(_127_),
    .D(_130_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(\result_comb[6] ));
 sky130_fd_sc_hd__xnor2_2 _535_ (.A(\B_reg[7] ),
    .B(_005_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_131_));
 sky130_fd_sc_hd__nand2_2 _536_ (.A(\A_reg[7] ),
    .B(_131_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_132_));
 sky130_fd_sc_hd__nor2_2 _537_ (.A(\A_reg[7] ),
    .B(_131_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_133_));
 sky130_fd_sc_hd__xnor2_2 _538_ (.A(\A_reg[7] ),
    .B(_131_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_134_));
 sky130_fd_sc_hd__a31o_2 _539_ (.A1(_102_),
    .A2(_104_),
    .A3(_117_),
    .B1(_118_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_135_));
 sky130_fd_sc_hd__xor2_2 _540_ (.A(_134_),
    .B(_135_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_136_));
 sky130_fd_sc_hd__o21ai_2 _541_ (.A1(\A_reg[7] ),
    .A2(\B_reg[7] ),
    .B1(_347_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_137_));
 sky130_fd_sc_hd__o221ai_2 _542_ (.A1(\A_reg[7] ),
    .A2(_339_),
    .B1(_343_),
    .B2(_132_),
    .C1(_137_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_138_));
 sky130_fd_sc_hd__a22o_2 _543_ (.A1(_351_),
    .A2(_070_),
    .B1(_074_),
    .B2(_002_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_139_));
 sky130_fd_sc_hd__a211o_2 _544_ (.A1(_073_),
    .A2(_096_),
    .B1(_138_),
    .C1(_139_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_140_));
 sky130_fd_sc_hd__mux2_1 _545_ (.A0(\A_reg[7] ),
    .A1(\A_reg[6] ),
    .S(\B_reg[0] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_141_));
 sky130_fd_sc_hd__mux2_1 _546_ (.A0(_107_),
    .A1(_141_),
    .S(_312_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_142_));
 sky130_fd_sc_hd__mux2_1 _547_ (.A0(_064_),
    .A1(_142_),
    .S(_311_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_143_));
 sky130_fd_sc_hd__a2bb2o_2 _548_ (.A1_N(_341_),
    .A2_N(_134_),
    .B1(_143_),
    .B2(_337_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_144_));
 sky130_fd_sc_hd__a211o_2 _549_ (.A1(_324_),
    .A2(_136_),
    .B1(_140_),
    .C1(_144_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(\result_comb[7] ));
 sky130_fd_sc_hd__xnor2_2 _550_ (.A(\B_reg[8] ),
    .B(_005_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_145_));
 sky130_fd_sc_hd__nand2_2 _551_ (.A(\A_reg[8] ),
    .B(_145_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_146_));
 sky130_fd_sc_hd__xnor2_2 _552_ (.A(\A_reg[8] ),
    .B(_145_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_147_));
 sky130_fd_sc_hd__or4_2 _553_ (.A(_079_),
    .B(_103_),
    .C(_119_),
    .D(_134_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_148_));
 sky130_fd_sc_hd__o211a_2 _554_ (.A1(_102_),
    .A2(_119_),
    .B1(_132_),
    .C1(_117_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_149_));
 sky130_fd_sc_hd__o21a_2 _555_ (.A1(_133_),
    .A2(_149_),
    .B1(_148_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_150_));
 sky130_fd_sc_hd__or4_2 _556_ (.A(_080_),
    .B(_103_),
    .C(_119_),
    .D(_134_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_151_));
 sky130_fd_sc_hd__a31o_2 _557_ (.A1(_082_),
    .A2(_085_),
    .A3(_087_),
    .B1(_151_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_152_));
 sky130_fd_sc_hd__a21o_2 _558_ (.A1(_150_),
    .A2(_152_),
    .B1(_147_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_153_));
 sky130_fd_sc_hd__nand3_2 _559_ (.A(_147_),
    .B(_150_),
    .C(_152_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_154_));
 sky130_fd_sc_hd__a21o_2 _560_ (.A1(_153_),
    .A2(_154_),
    .B1(_325_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_155_));
 sky130_fd_sc_hd__mux4_2 _561_ (.A0(\A_reg[8] ),
    .A1(\A_reg[7] ),
    .A2(\A_reg[6] ),
    .A3(\A_reg[5] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_156_));
 sky130_fd_sc_hd__or2_2 _562_ (.A(\B_reg[2] ),
    .B(_156_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_157_));
 sky130_fd_sc_hd__o21a_2 _563_ (.A1(_311_),
    .A2(_092_),
    .B1(_337_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_158_));
 sky130_fd_sc_hd__a22o_2 _564_ (.A1(_331_),
    .A2(_349_),
    .B1(_157_),
    .B2(_158_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_159_));
 sky130_fd_sc_hd__o21ai_2 _565_ (.A1(\A_reg[8] ),
    .A2(\B_reg[8] ),
    .B1(_344_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_160_));
 sky130_fd_sc_hd__o211a_2 _566_ (.A1(\A_reg[8] ),
    .A2(_339_),
    .B1(_160_),
    .C1(_325_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_161_));
 sky130_fd_sc_hd__and2_2 _567_ (.A(\B_reg[3] ),
    .B(_336_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_162_));
 sky130_fd_sc_hd__nand2_2 _568_ (.A(\B_reg[3] ),
    .B(_336_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_163_));
 sky130_fd_sc_hd__o221a_2 _569_ (.A1(_343_),
    .A2(_146_),
    .B1(_163_),
    .B2(_335_),
    .C1(_161_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_164_));
 sky130_fd_sc_hd__o21ai_2 _570_ (.A1(_341_),
    .A2(_147_),
    .B1(_164_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_165_));
 sky130_fd_sc_hd__o21a_2 _571_ (.A1(_159_),
    .A2(_165_),
    .B1(_155_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(\result_comb[8] ));
 sky130_fd_sc_hd__xnor2_2 _572_ (.A(\B_reg[9] ),
    .B(_005_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_166_));
 sky130_fd_sc_hd__nand2_2 _573_ (.A(\A_reg[9] ),
    .B(_166_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_167_));
 sky130_fd_sc_hd__nor2_2 _574_ (.A(\A_reg[9] ),
    .B(_166_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_168_));
 sky130_fd_sc_hd__xnor2_2 _575_ (.A(\A_reg[9] ),
    .B(_166_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_169_));
 sky130_fd_sc_hd__nand3_2 _576_ (.A(_146_),
    .B(_153_),
    .C(_169_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_170_));
 sky130_fd_sc_hd__a21o_2 _577_ (.A1(_146_),
    .A2(_153_),
    .B1(_169_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_171_));
 sky130_fd_sc_hd__or3b_2 _578_ (.A(_163_),
    .B(\B_reg[2] ),
    .C_N(_016_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_172_));
 sky130_fd_sc_hd__o21ai_2 _579_ (.A1(\A_reg[9] ),
    .A2(\B_reg[9] ),
    .B1(_347_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_173_));
 sky130_fd_sc_hd__o211a_2 _580_ (.A1(\A_reg[9] ),
    .A2(_339_),
    .B1(_172_),
    .C1(_173_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_174_));
 sky130_fd_sc_hd__mux2_1 _581_ (.A0(\A_reg[9] ),
    .A1(\A_reg[8] ),
    .S(\B_reg[0] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_175_));
 sky130_fd_sc_hd__mux4_2 _582_ (.A0(_063_),
    .A1(_107_),
    .A2(_141_),
    .A3(_175_),
    .S0(_312_),
    .S1(_311_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_176_));
 sky130_fd_sc_hd__o221a_2 _583_ (.A1(_343_),
    .A2(_167_),
    .B1(_169_),
    .B2(_341_),
    .C1(_174_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_177_));
 sky130_fd_sc_hd__o21ai_2 _584_ (.A1(_350_),
    .A2(_030_),
    .B1(_177_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_178_));
 sky130_fd_sc_hd__a21o_2 _585_ (.A1(_337_),
    .A2(_176_),
    .B1(_178_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_179_));
 sky130_fd_sc_hd__a31o_2 _586_ (.A1(_324_),
    .A2(_170_),
    .A3(_171_),
    .B1(_179_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(\result_comb[9] ));
 sky130_fd_sc_hd__xnor2_2 _587_ (.A(\B_reg[10] ),
    .B(_005_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_180_));
 sky130_fd_sc_hd__nand2_2 _588_ (.A(\A_reg[10] ),
    .B(_180_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_181_));
 sky130_fd_sc_hd__nor2_2 _589_ (.A(\A_reg[10] ),
    .B(_180_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_182_));
 sky130_fd_sc_hd__xnor2_2 _590_ (.A(\A_reg[10] ),
    .B(_180_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_183_));
 sky130_fd_sc_hd__a31o_2 _591_ (.A1(_146_),
    .A2(_153_),
    .A3(_167_),
    .B1(_168_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_184_));
 sky130_fd_sc_hd__xor2_2 _592_ (.A(_183_),
    .B(_184_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_185_));
 sky130_fd_sc_hd__o21ai_2 _593_ (.A1(\A_reg[10] ),
    .A2(\B_reg[10] ),
    .B1(_347_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_186_));
 sky130_fd_sc_hd__o221a_2 _594_ (.A1(\A_reg[10] ),
    .A2(_339_),
    .B1(_343_),
    .B2(_181_),
    .C1(_186_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_187_));
 sky130_fd_sc_hd__a211o_2 _595_ (.A1(\B_reg[2] ),
    .A2(_042_),
    .B1(_044_),
    .C1(_350_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_188_));
 sky130_fd_sc_hd__o211ai_2 _596_ (.A1(_341_),
    .A2(_183_),
    .B1(_187_),
    .C1(_188_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_189_));
 sky130_fd_sc_hd__mux4_2 _597_ (.A0(\A_reg[10] ),
    .A1(\A_reg[9] ),
    .A2(\A_reg[8] ),
    .A3(\A_reg[7] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_190_));
 sky130_fd_sc_hd__mux2_1 _598_ (.A0(_128_),
    .A1(_190_),
    .S(_311_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_191_));
 sky130_fd_sc_hd__o22a_2 _599_ (.A1(_337_),
    .A2(_055_),
    .B1(_191_),
    .B2(\B_reg[3] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_192_));
 sky130_fd_sc_hd__a211o_2 _600_ (.A1(_324_),
    .A2(_185_),
    .B1(_189_),
    .C1(_192_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(\result_comb[10] ));
 sky130_fd_sc_hd__xnor2_2 _601_ (.A(\B_reg[11] ),
    .B(_005_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_193_));
 sky130_fd_sc_hd__nand2_2 _602_ (.A(\A_reg[11] ),
    .B(_193_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_194_));
 sky130_fd_sc_hd__nor2_2 _603_ (.A(\A_reg[11] ),
    .B(_193_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_195_));
 sky130_fd_sc_hd__xnor2_2 _604_ (.A(\A_reg[11] ),
    .B(_193_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_196_));
 sky130_fd_sc_hd__a21o_2 _605_ (.A1(_167_),
    .A2(_181_),
    .B1(_182_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_197_));
 sky130_fd_sc_hd__a31o_2 _606_ (.A1(_167_),
    .A2(_169_),
    .A3(_181_),
    .B1(_182_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_198_));
 sky130_fd_sc_hd__a31o_2 _607_ (.A1(_146_),
    .A2(_153_),
    .A3(_197_),
    .B1(_198_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_199_));
 sky130_fd_sc_hd__xor2_2 _608_ (.A(_196_),
    .B(_199_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_200_));
 sky130_fd_sc_hd__o21ai_2 _609_ (.A1(\A_reg[11] ),
    .A2(\B_reg[11] ),
    .B1(_347_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_201_));
 sky130_fd_sc_hd__o221a_2 _610_ (.A1(\A_reg[11] ),
    .A2(_339_),
    .B1(_065_),
    .B2(_163_),
    .C1(_201_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_202_));
 sky130_fd_sc_hd__o21ai_2 _611_ (.A1(_343_),
    .A2(_194_),
    .B1(_202_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_203_));
 sky130_fd_sc_hd__mux2_1 _612_ (.A0(\A_reg[11] ),
    .A1(\A_reg[10] ),
    .S(\B_reg[0] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_204_));
 sky130_fd_sc_hd__mux2_1 _613_ (.A0(_175_),
    .A1(_204_),
    .S(_312_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_205_));
 sky130_fd_sc_hd__mux2_1 _614_ (.A0(_142_),
    .A1(_205_),
    .S(_311_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_206_));
 sky130_fd_sc_hd__a2bb2o_2 _615_ (.A1_N(_341_),
    .A2_N(_196_),
    .B1(_206_),
    .B2(_337_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_207_));
 sky130_fd_sc_hd__a211o_2 _616_ (.A1(_349_),
    .A2(_075_),
    .B1(_203_),
    .C1(_207_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_208_));
 sky130_fd_sc_hd__a21o_2 _617_ (.A1(_324_),
    .A2(_200_),
    .B1(_208_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(\result_comb[11] ));
 sky130_fd_sc_hd__xor2_2 _618_ (.A(\B_reg[12] ),
    .B(_005_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_209_));
 sky130_fd_sc_hd__or2_2 _619_ (.A(_317_),
    .B(_209_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_210_));
 sky130_fd_sc_hd__nand2_2 _620_ (.A(_317_),
    .B(_209_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_211_));
 sky130_fd_sc_hd__nand2_2 _621_ (.A(_210_),
    .B(_211_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_212_));
 sky130_fd_sc_hd__or4_2 _622_ (.A(_147_),
    .B(_169_),
    .C(_183_),
    .D(_196_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_213_));
 sky130_fd_sc_hd__or4_2 _623_ (.A(_146_),
    .B(_169_),
    .C(_183_),
    .D(_196_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_214_));
 sky130_fd_sc_hd__o31a_2 _624_ (.A1(_082_),
    .A2(_151_),
    .A3(_213_),
    .B1(_214_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_215_));
 sky130_fd_sc_hd__o211a_2 _625_ (.A1(_195_),
    .A2(_197_),
    .B1(_215_),
    .C1(_194_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_216_));
 sky130_fd_sc_hd__or2_2 _626_ (.A(_150_),
    .B(_213_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_217_));
 sky130_fd_sc_hd__a211o_2 _627_ (.A1(_085_),
    .A2(_087_),
    .B1(_151_),
    .C1(_213_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_218_));
 sky130_fd_sc_hd__a31o_2 _628_ (.A1(_216_),
    .A2(_217_),
    .A3(_218_),
    .B1(_212_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_219_));
 sky130_fd_sc_hd__nand4_2 _629_ (.A(_212_),
    .B(_216_),
    .C(_217_),
    .D(_218_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_220_));
 sky130_fd_sc_hd__a21o_2 _630_ (.A1(_219_),
    .A2(_220_),
    .B1(_325_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_221_));
 sky130_fd_sc_hd__nor2_2 _631_ (.A(_343_),
    .B(_210_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_222_));
 sky130_fd_sc_hd__o21ai_2 _632_ (.A1(\A_reg[12] ),
    .A2(\B_reg[12] ),
    .B1(_344_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_223_));
 sky130_fd_sc_hd__o211ai_2 _633_ (.A1(\A_reg[12] ),
    .A2(_339_),
    .B1(_223_),
    .C1(_325_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_224_));
 sky130_fd_sc_hd__mux4_2 _634_ (.A0(\A_reg[12] ),
    .A1(\A_reg[11] ),
    .A2(\A_reg[10] ),
    .A3(\A_reg[9] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_225_));
 sky130_fd_sc_hd__mux2_1 _635_ (.A0(_156_),
    .A1(_225_),
    .S(_311_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_226_));
 sky130_fd_sc_hd__a2bb2o_2 _636_ (.A1_N(_341_),
    .A2_N(_212_),
    .B1(_162_),
    .B2(_093_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_227_));
 sky130_fd_sc_hd__a2111o_2 _637_ (.A1(_330_),
    .A2(_351_),
    .B1(_222_),
    .C1(_224_),
    .D1(_227_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_228_));
 sky130_fd_sc_hd__a21o_2 _638_ (.A1(_337_),
    .A2(_226_),
    .B1(_228_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_229_));
 sky130_fd_sc_hd__and2_2 _639_ (.A(_221_),
    .B(_229_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(\result_comb[12] ));
 sky130_fd_sc_hd__xor2_2 _640_ (.A(\B_reg[13] ),
    .B(_005_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_230_));
 sky130_fd_sc_hd__nor2_2 _641_ (.A(_318_),
    .B(_230_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_231_));
 sky130_fd_sc_hd__or2_2 _642_ (.A(_318_),
    .B(_230_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_232_));
 sky130_fd_sc_hd__and2_2 _643_ (.A(_318_),
    .B(_230_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_233_));
 sky130_fd_sc_hd__nor2_2 _644_ (.A(_231_),
    .B(_233_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_234_));
 sky130_fd_sc_hd__a22o_2 _645_ (.A1(_109_),
    .A2(_162_),
    .B1(_234_),
    .B2(_340_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_235_));
 sky130_fd_sc_hd__mux2_1 _646_ (.A0(\A_reg[13] ),
    .A1(\A_reg[12] ),
    .S(\B_reg[0] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_236_));
 sky130_fd_sc_hd__mux4_2 _647_ (.A0(_141_),
    .A1(_175_),
    .A2(_204_),
    .A3(_236_),
    .S0(_312_),
    .S1(_311_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_237_));
 sky130_fd_sc_hd__nor2_2 _648_ (.A(_343_),
    .B(_232_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_238_));
 sky130_fd_sc_hd__or2_2 _649_ (.A(\A_reg[13] ),
    .B(\B_reg[13] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_239_));
 sky130_fd_sc_hd__a2bb2o_2 _650_ (.A1_N(\A_reg[13] ),
    .A2_N(_339_),
    .B1(_347_),
    .B2(_239_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_240_));
 sky130_fd_sc_hd__a211o_2 _651_ (.A1(_351_),
    .A2(_029_),
    .B1(_240_),
    .C1(_324_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_241_));
 sky130_fd_sc_hd__a211o_2 _652_ (.A1(_337_),
    .A2(_237_),
    .B1(_241_),
    .C1(_235_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_242_));
 sky130_fd_sc_hd__a21oi_2 _653_ (.A1(_210_),
    .A2(_219_),
    .B1(_234_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_243_));
 sky130_fd_sc_hd__a31o_2 _654_ (.A1(_210_),
    .A2(_219_),
    .A3(_234_),
    .B1(_325_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_244_));
 sky130_fd_sc_hd__o22a_2 _655_ (.A1(_238_),
    .A2(_242_),
    .B1(_243_),
    .B2(_244_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(\result_comb[13] ));
 sky130_fd_sc_hd__xor2_2 _656_ (.A(\B_reg[14] ),
    .B(_005_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_245_));
 sky130_fd_sc_hd__or2_2 _657_ (.A(_319_),
    .B(_245_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_246_));
 sky130_fd_sc_hd__nand2_2 _658_ (.A(_319_),
    .B(_245_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_247_));
 sky130_fd_sc_hd__nand2_2 _659_ (.A(_246_),
    .B(_247_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_248_));
 sky130_fd_sc_hd__a31o_2 _660_ (.A1(_210_),
    .A2(_219_),
    .A3(_232_),
    .B1(_233_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_249_));
 sky130_fd_sc_hd__xor2_2 _661_ (.A(_248_),
    .B(_249_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_250_));
 sky130_fd_sc_hd__o21ai_2 _662_ (.A1(\A_reg[14] ),
    .A2(\B_reg[14] ),
    .B1(_347_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_251_));
 sky130_fd_sc_hd__o32a_2 _663_ (.A1(\B_reg[2] ),
    .A2(_350_),
    .A3(_042_),
    .B1(\A_reg[14] ),
    .B2(_339_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_252_));
 sky130_fd_sc_hd__o211a_2 _664_ (.A1(_343_),
    .A2(_246_),
    .B1(_251_),
    .C1(_252_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_253_));
 sky130_fd_sc_hd__o21ai_2 _665_ (.A1(_341_),
    .A2(_248_),
    .B1(_253_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_254_));
 sky130_fd_sc_hd__mux4_2 _666_ (.A0(\A_reg[14] ),
    .A1(\A_reg[13] ),
    .A2(\A_reg[12] ),
    .A3(\A_reg[11] ),
    .S0(\B_reg[0] ),
    .S1(\B_reg[1] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_255_));
 sky130_fd_sc_hd__mux2_1 _667_ (.A0(_190_),
    .A1(_255_),
    .S(_311_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_256_));
 sky130_fd_sc_hd__a22o_2 _668_ (.A1(_129_),
    .A2(_162_),
    .B1(_256_),
    .B2(_337_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_257_));
 sky130_fd_sc_hd__a211o_2 _669_ (.A1(_324_),
    .A2(_250_),
    .B1(_254_),
    .C1(_257_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(\result_comb[14] ));
 sky130_fd_sc_hd__xor2_2 _670_ (.A(\B_reg[15] ),
    .B(_005_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_258_));
 sky130_fd_sc_hd__nand2_2 _671_ (.A(_320_),
    .B(_258_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_259_));
 sky130_fd_sc_hd__or2_2 _672_ (.A(_320_),
    .B(_258_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_260_));
 sky130_fd_sc_hd__nand2_2 _673_ (.A(_259_),
    .B(_260_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_261_));
 sky130_fd_sc_hd__a2111o_2 _674_ (.A1(_210_),
    .A2(_219_),
    .B1(_231_),
    .C1(_233_),
    .D1(_248_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_262_));
 sky130_fd_sc_hd__a21boi_2 _675_ (.A1(_231_),
    .A2(_247_),
    .B1_N(_246_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_263_));
 sky130_fd_sc_hd__and2_2 _676_ (.A(_262_),
    .B(_263_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_264_));
 sky130_fd_sc_hd__a21oi_2 _677_ (.A1(_262_),
    .A2(_263_),
    .B1(_261_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_265_));
 sky130_fd_sc_hd__a31o_2 _678_ (.A1(_261_),
    .A2(_262_),
    .A3(_263_),
    .B1(_325_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_266_));
 sky130_fd_sc_hd__and2_2 _679_ (.A(\B_reg[1] ),
    .B(_236_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_267_));
 sky130_fd_sc_hd__a31o_2 _680_ (.A1(\B_reg[0] ),
    .A2(_312_),
    .A3(\A_reg[14] ),
    .B1(\B_reg[2] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_268_));
 sky130_fd_sc_hd__o32a_2 _681_ (.A1(_073_),
    .A2(_267_),
    .A3(_268_),
    .B1(_205_),
    .B2(_311_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_269_));
 sky130_fd_sc_hd__a21o_2 _682_ (.A1(_310_),
    .A2(\opcode_reg[2] ),
    .B1(_347_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_270_));
 sky130_fd_sc_hd__a21bo_2 _683_ (.A1(\B_reg[15] ),
    .A2(_270_),
    .B1_N(_339_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_271_));
 sky130_fd_sc_hd__o21a_2 _684_ (.A1(_333_),
    .A2(_350_),
    .B1(\A_reg[15] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_272_));
 sky130_fd_sc_hd__mux2_1 _685_ (.A0(_341_),
    .A1(_343_),
    .S(\B_reg[15] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_273_));
 sky130_fd_sc_hd__nand2_2 _686_ (.A(_272_),
    .B(_273_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_274_));
 sky130_fd_sc_hd__o22a_2 _687_ (.A1(\A_reg[15] ),
    .A2(_271_),
    .B1(_274_),
    .B2(_347_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_275_));
 sky130_fd_sc_hd__a22o_2 _688_ (.A1(_143_),
    .A2(_162_),
    .B1(_269_),
    .B2(_337_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_276_));
 sky130_fd_sc_hd__nor2_2 _689_ (.A(_275_),
    .B(_276_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_277_));
 sky130_fd_sc_hd__o21ai_2 _690_ (.A1(_265_),
    .A2(_266_),
    .B1(_277_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(\result_comb[15] ));
 sky130_fd_sc_hd__or3_2 _691_ (.A(\result_comb[0] ),
    .B(\result_comb[1] ),
    .C(\result_comb[2] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_278_));
 sky130_fd_sc_hd__or3_2 _692_ (.A(\result_comb[3] ),
    .B(\result_comb[4] ),
    .C(_278_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_279_));
 sky130_fd_sc_hd__a2111o_2 _693_ (.A1(_221_),
    .A2(_229_),
    .B1(_279_),
    .C1(\result_comb[8] ),
    .D1(\result_comb[5] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_280_));
 sky130_fd_sc_hd__or4_2 _694_ (.A(\result_comb[6] ),
    .B(\result_comb[9] ),
    .C(\result_comb[13] ),
    .D(_280_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_281_));
 sky130_fd_sc_hd__or3_2 _695_ (.A(\result_comb[7] ),
    .B(\result_comb[10] ),
    .C(\result_comb[11] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_282_));
 sky130_fd_sc_hd__nor4_2 _696_ (.A(\result_comb[14] ),
    .B(\result_comb[15] ),
    .C(_281_),
    .D(_282_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_000_));
 sky130_fd_sc_hd__nand2_2 _697_ (.A(_260_),
    .B(_264_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_283_));
 sky130_fd_sc_hd__xnor2_2 _698_ (.A(\B_reg[0] ),
    .B(_326_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_284_));
 sky130_fd_sc_hd__nor2_2 _699_ (.A(\B_reg[1] ),
    .B(_284_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_285_));
 sky130_fd_sc_hd__o21a_2 _700_ (.A1(\A_reg[0] ),
    .A2(\B_reg[1] ),
    .B1(_284_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_286_));
 sky130_fd_sc_hd__a221o_2 _701_ (.A1(\B_reg[1] ),
    .A2(\A_reg[1] ),
    .B1(\A_reg[3] ),
    .B2(_285_),
    .C1(_286_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_287_));
 sky130_fd_sc_hd__nand2_2 _702_ (.A(\B_reg[1] ),
    .B(_284_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_288_));
 sky130_fd_sc_hd__xnor2_2 _703_ (.A(\B_reg[2] ),
    .B(_332_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_289_));
 sky130_fd_sc_hd__xnor2_2 _704_ (.A(_326_),
    .B(_289_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_290_));
 sky130_fd_sc_hd__xor2_2 _705_ (.A(_326_),
    .B(_289_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_291_));
 sky130_fd_sc_hd__o211a_2 _706_ (.A1(\A_reg[2] ),
    .A2(_288_),
    .B1(_290_),
    .C1(_287_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_292_));
 sky130_fd_sc_hd__nand2b_2 _707_ (.A_N(_326_),
    .B(\B_reg[3] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_293_));
 sky130_fd_sc_hd__and3_2 _708_ (.A(_333_),
    .B(_350_),
    .C(_293_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_294_));
 sky130_fd_sc_hd__a21oi_2 _709_ (.A1(_350_),
    .A2(_293_),
    .B1(_333_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_295_));
 sky130_fd_sc_hd__or2_2 _710_ (.A(_294_),
    .B(_295_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_296_));
 sky130_fd_sc_hd__nor2_2 _711_ (.A(_312_),
    .B(_316_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_297_));
 sky130_fd_sc_hd__o22a_2 _712_ (.A1(\B_reg[1] ),
    .A2(\A_reg[4] ),
    .B1(_284_),
    .B2(_297_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_298_));
 sky130_fd_sc_hd__o211a_2 _713_ (.A1(_333_),
    .A2(_350_),
    .B1(_285_),
    .C1(\A_reg[7] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_299_));
 sky130_fd_sc_hd__o221a_2 _714_ (.A1(\A_reg[6] ),
    .A2(_288_),
    .B1(_298_),
    .B2(_299_),
    .C1(_291_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_300_));
 sky130_fd_sc_hd__o22a_2 _715_ (.A1(\B_reg[1] ),
    .A2(\A_reg[8] ),
    .B1(\A_reg[9] ),
    .B2(_284_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_301_));
 sky130_fd_sc_hd__mux2_1 _716_ (.A0(_301_),
    .A1(\A_reg[11] ),
    .S(_285_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_302_));
 sky130_fd_sc_hd__o211a_2 _717_ (.A1(\A_reg[10] ),
    .A2(_288_),
    .B1(_290_),
    .C1(_302_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_303_));
 sky130_fd_sc_hd__mux4_2 _718_ (.A0(\A_reg[13] ),
    .A1(\A_reg[14] ),
    .A2(_272_),
    .A3(\A_reg[12] ),
    .S0(_284_),
    .S1(_312_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_304_));
 sky130_fd_sc_hd__a21bo_2 _719_ (.A1(_291_),
    .A2(_304_),
    .B1_N(_296_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_305_));
 sky130_fd_sc_hd__o32a_2 _720_ (.A1(_292_),
    .A2(_296_),
    .A3(_300_),
    .B1(_303_),
    .B2(_305_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_306_));
 sky130_fd_sc_hd__o2111a_2 _721_ (.A1(\B_reg[3] ),
    .A2(_333_),
    .B1(_306_),
    .C1(\opcode_reg[2] ),
    .D1(\opcode_reg[1] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_307_));
 sky130_fd_sc_hd__a31o_2 _722_ (.A1(_324_),
    .A2(_259_),
    .A3(_283_),
    .B1(_307_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(carry_comb));
 sky130_fd_sc_hd__mux2_1 _723_ (.A0(_259_),
    .A1(_260_),
    .S(_264_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(_308_));
 sky130_fd_sc_hd__nor2_2 _724_ (.A(_325_),
    .B(_308_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Y(_001_));
 sky130_fd_sc_hd__dfxtp_2 _725_ (.CLK(clk),
    .D(_001_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(V));
 sky130_fd_sc_hd__dfxtp_2 _726_ (.CLK(clk),
    .D(carry_comb),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(C));
 sky130_fd_sc_hd__dfxtp_2 _727_ (.CLK(clk),
    .D(\result_comb[15] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(N));
 sky130_fd_sc_hd__dfxtp_2 _728_ (.CLK(clk),
    .D(\result_comb[0] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(Y[0]));
 sky130_fd_sc_hd__dfxtp_2 _729_ (.CLK(clk),
    .D(\result_comb[1] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(Y[1]));
 sky130_fd_sc_hd__dfxtp_2 _730_ (.CLK(clk),
    .D(\result_comb[2] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(Y[2]));
 sky130_fd_sc_hd__dfxtp_2 _731_ (.CLK(clk),
    .D(\result_comb[3] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(Y[3]));
 sky130_fd_sc_hd__dfxtp_2 _732_ (.CLK(clk),
    .D(\result_comb[4] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(Y[4]));
 sky130_fd_sc_hd__dfxtp_2 _733_ (.CLK(clk),
    .D(\result_comb[5] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(Y[5]));
 sky130_fd_sc_hd__dfxtp_2 _734_ (.CLK(clk),
    .D(\result_comb[6] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(Y[6]));
 sky130_fd_sc_hd__dfxtp_2 _735_ (.CLK(clk),
    .D(\result_comb[7] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(Y[7]));
 sky130_fd_sc_hd__dfxtp_2 _736_ (.CLK(clk),
    .D(\result_comb[8] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(Y[8]));
 sky130_fd_sc_hd__dfxtp_2 _737_ (.CLK(clk),
    .D(\result_comb[9] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(Y[9]));
 sky130_fd_sc_hd__dfxtp_2 _738_ (.CLK(clk),
    .D(\result_comb[10] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(Y[10]));
 sky130_fd_sc_hd__dfxtp_2 _739_ (.CLK(clk),
    .D(\result_comb[11] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(Y[11]));
 sky130_fd_sc_hd__dfxtp_2 _740_ (.CLK(clk),
    .D(\result_comb[12] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(Y[12]));
 sky130_fd_sc_hd__dfxtp_2 _741_ (.CLK(clk),
    .D(\result_comb[13] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(Y[13]));
 sky130_fd_sc_hd__dfxtp_2 _742_ (.CLK(clk),
    .D(\result_comb[14] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(Y[14]));
 sky130_fd_sc_hd__dfxtp_2 _743_ (.CLK(clk),
    .D(_000_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(Z));
 sky130_fd_sc_hd__dfxtp_2 _744_ (.CLK(clk),
    .D(A[0]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\A_reg[0] ));
 sky130_fd_sc_hd__dfxtp_2 _745_ (.CLK(clk),
    .D(A[1]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\A_reg[1] ));
 sky130_fd_sc_hd__dfxtp_2 _746_ (.CLK(clk),
    .D(A[2]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\A_reg[2] ));
 sky130_fd_sc_hd__dfxtp_2 _747_ (.CLK(clk),
    .D(A[3]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\A_reg[3] ));
 sky130_fd_sc_hd__dfxtp_2 _748_ (.CLK(clk),
    .D(A[4]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\A_reg[4] ));
 sky130_fd_sc_hd__dfxtp_2 _749_ (.CLK(clk),
    .D(A[5]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\A_reg[5] ));
 sky130_fd_sc_hd__dfxtp_2 _750_ (.CLK(clk),
    .D(A[6]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\A_reg[6] ));
 sky130_fd_sc_hd__dfxtp_2 _751_ (.CLK(clk),
    .D(A[7]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\A_reg[7] ));
 sky130_fd_sc_hd__dfxtp_2 _752_ (.CLK(clk),
    .D(A[8]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\A_reg[8] ));
 sky130_fd_sc_hd__dfxtp_2 _753_ (.CLK(clk),
    .D(A[9]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\A_reg[9] ));
 sky130_fd_sc_hd__dfxtp_2 _754_ (.CLK(clk),
    .D(A[10]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\A_reg[10] ));
 sky130_fd_sc_hd__dfxtp_2 _755_ (.CLK(clk),
    .D(A[11]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\A_reg[11] ));
 sky130_fd_sc_hd__dfxtp_2 _756_ (.CLK(clk),
    .D(A[12]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\A_reg[12] ));
 sky130_fd_sc_hd__dfxtp_2 _757_ (.CLK(clk),
    .D(A[13]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\A_reg[13] ));
 sky130_fd_sc_hd__dfxtp_2 _758_ (.CLK(clk),
    .D(A[14]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\A_reg[14] ));
 sky130_fd_sc_hd__dfxtp_2 _759_ (.CLK(clk),
    .D(A[15]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\A_reg[15] ));
 sky130_fd_sc_hd__dfxtp_2 _760_ (.CLK(clk),
    .D(B[0]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\B_reg[0] ));
 sky130_fd_sc_hd__dfxtp_2 _761_ (.CLK(clk),
    .D(B[1]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\B_reg[1] ));
 sky130_fd_sc_hd__dfxtp_2 _762_ (.CLK(clk),
    .D(B[2]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\B_reg[2] ));
 sky130_fd_sc_hd__dfxtp_2 _763_ (.CLK(clk),
    .D(B[3]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\B_reg[3] ));
 sky130_fd_sc_hd__dfxtp_2 _764_ (.CLK(clk),
    .D(B[4]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\B_reg[4] ));
 sky130_fd_sc_hd__dfxtp_2 _765_ (.CLK(clk),
    .D(B[5]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\B_reg[5] ));
 sky130_fd_sc_hd__dfxtp_2 _766_ (.CLK(clk),
    .D(B[6]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\B_reg[6] ));
 sky130_fd_sc_hd__dfxtp_2 _767_ (.CLK(clk),
    .D(B[7]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\B_reg[7] ));
 sky130_fd_sc_hd__dfxtp_2 _768_ (.CLK(clk),
    .D(B[8]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\B_reg[8] ));
 sky130_fd_sc_hd__dfxtp_2 _769_ (.CLK(clk),
    .D(B[9]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\B_reg[9] ));
 sky130_fd_sc_hd__dfxtp_2 _770_ (.CLK(clk),
    .D(B[10]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\B_reg[10] ));
 sky130_fd_sc_hd__dfxtp_2 _771_ (.CLK(clk),
    .D(B[11]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\B_reg[11] ));
 sky130_fd_sc_hd__dfxtp_2 _772_ (.CLK(clk),
    .D(B[12]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\B_reg[12] ));
 sky130_fd_sc_hd__dfxtp_2 _773_ (.CLK(clk),
    .D(B[13]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\B_reg[13] ));
 sky130_fd_sc_hd__dfxtp_2 _774_ (.CLK(clk),
    .D(B[14]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\B_reg[14] ));
 sky130_fd_sc_hd__dfxtp_2 _775_ (.CLK(clk),
    .D(B[15]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\B_reg[15] ));
 sky130_fd_sc_hd__dfxtp_2 _776_ (.CLK(clk),
    .D(opcode[0]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\opcode_reg[0] ));
 sky130_fd_sc_hd__dfxtp_2 _777_ (.CLK(clk),
    .D(opcode[1]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\opcode_reg[1] ));
 sky130_fd_sc_hd__dfxtp_2 _778_ (.CLK(clk),
    .D(opcode[2]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .Q(\opcode_reg[2] ));
 sky130_fd_sc_hd__buf_2 _779_ (.A(N),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(Y[15]));
endmodule
